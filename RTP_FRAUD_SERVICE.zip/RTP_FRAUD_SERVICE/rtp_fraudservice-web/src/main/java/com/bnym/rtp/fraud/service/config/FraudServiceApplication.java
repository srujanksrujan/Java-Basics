package com.bnym.rtp.fraud.service.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = "com.bnym.rtp.fraud.service")
@Configuration
@EnableAutoConfiguration
@EnableJpaRepositories(basePackages = "com.bnym.rtp.fraud.service.dao.repository")
@EntityScan(basePackages="com.bnym.rtp.fraud.service.dao.entity")
public class FraudServiceApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(FraudServiceApplication.class, args);
	}

}
