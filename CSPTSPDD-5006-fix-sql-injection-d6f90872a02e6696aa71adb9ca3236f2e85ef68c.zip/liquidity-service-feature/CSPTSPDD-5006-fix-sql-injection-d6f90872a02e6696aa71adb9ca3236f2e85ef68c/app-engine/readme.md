## Pre-requisites
1. [Install command line Interface](https://confluence.bnymellon.net/display/BCS/CLI+Download).
2. Copy the file into a directory on your execution path and rename it to 'bxp' 
    -  Windows Version - It comes as executable (.exe) and you have to run it which will extract the file (E.g. "c:\data\tools") and you can rename it to bxp.exe
    -  Mac OSX: It comes as .bin, just rename it to bxp and make it as executable
3. Create a soft link named 'bxp' on your execution path pointing to the downloaded file.
    -  Set Windows Environment Variable. set PATH=%PATH%;C:\data\tools; if your bxp.exe is in the path "C:\data\tools"
4. Change the permissions of the file so that it is executable [only for MAC/Unix].
5. Run bxp --version to confirm that it is working :+1:

6. For liquidity-service:
	a. since there is a limitation from OIDC of session sharing across clusters, all the applications running under liquidity-service (TCH-Switch-UI, Throttler-UI, and its respective APIs)
		needs to be in the same cluster. Hence the following commands are for all the all the application (2 UIs, 2 APIs).
	b. These same commands will be present in all the other 3 repositories.

## Common Commands
```sh
bxp context clear 
bxp target dev1
bxp app validate --file assembly.yml 
bxp app register rpx-throttler.liquidity-service --org-id rpx 
bxp image build rpx-throttler.liquidity-service.api:v1.0.0-SNAPSHOT --file DockerFile

```

## Development
bxp target dev1
App Engine Dash board page : https://appengine-ui-nonprod.bnymellon.net/#/dashboard
```sh
bxp context set rpx-throttler.liquidity-service --family rpx-throttler --app-name "liquidity-service" --file assembly.yaml  --dockerfile DockerFile --app-env dev  --deployment dev
bxp app run rpx-throttler.liquidity-service --file assembly.yml --deployment dev --app-env dev
bxp app update rpx-throttler.liquidity-service --file assembly.yml --deployment dev --app-env dev
bxp app status --verbose rpx-throttler.liquidity-service --app-env dev 
bxp app delete rpx-throttler.liquidity-service --app-env dev 
bxp app show rpx-throttler.liquidity-service --app-env dev 
bxp route create rpx-throttler.liquidity-service.api --cluster dev1 --app-env dev --deployment dev --contact contact.yaml --file assembly.yml
bxp route create rpx-throttler.liquidity-service --cluster nonprod2 --app-env dev --deployment dev --contact contact.yaml --file assembly.yml
bxp route create rpx-throttler.liquidity-service.api --cluster nonprod1 --app-env dev --deployment dev --contact contact.yaml --file assembly.yml
bxp app scale rpx-throttler.liquidity-service.api --instances 2 --app-env dev
bxp app scale rpx-throttler.liquidity-service.api --instances 1 --app-env dev
```
### Test - Alpha
bxp target nonprod1
App Engine Dash board page : https://appengine-ui-nonprod.bnymellon.net/#/dashboard
```sh
bxp context set rpx-throttler.liquidity-service --family rpx-throttler --app-name "liquidity-service" --file assembly.yaml  --dockerfile DockerFile --app-env test --space alpha
bxp app run rpx-throttler.liquidity-service --file assembly.yml --deployment alpha --app-env test --space alpha
bxp app status --verbose rpx-throttler.liquidity-service --app-env test --space alpha
bxp app status rpx-throttler.liquidity-service --app-env test --space alpha
bxp app delete rpx-throttler.liquidity-service --app-env test --space alpha 
bxp route status --url rpx-throttler.bnymellon.net --app-env test --space alpha
bxp route create rpx-throttler.liquidity-service.api --cluster nonprod1 --app-env test --space alpha --deployment test --contact contact.yaml --file assembly.yml
bxp app scale rpx-throttler.liquidity-service.api --instances 2 --app-env test --space alpha
bxp app scale rpx-throttler.liquidity-service.api --instances 1 --app-env test --space alpha
```
### Test - UAT
bxp target nonprod2
App Engine Dash board page : https://appengine-ui-nonprod.bnymellon.net/#/dashboard
```sh
bxp context set rpx-throttler.liquidity-service --family rpx-throttler --app-name "liquidity-service" --file assembly.yaml  --dockerfile DockerFile --app-env test --space uat
bxp app run rpx-throttler.liquidity-service --file assembly.yml --deployment uat --app-env test --space uat
bxp app delete rpx-throttler.liquidity-service --app-env test --space uat 
bxp app status --verbose rpx-throttler.liquidity-service --app-env test --space uat
bxp app status rpx-throttler.liquidity-service --app-env test --space uat
bxp route status --url rpx-throttler.bnymellon.net --app-env test --space uat
bxp route create rpx-throttler.liquidity-service.api --cluster nonprod2 --app-env test --space uat --deployment test --contact contact.yaml --file assembly.yml
bxp app scale rpx-throttler.liquidity-service.api --instances 2 --app-env test --space uat
bxp app scale rpx-throttler.liquidity-service.api --instances 1 --app-env test --space uat
```
```
### QA
bxp target preprod1
App Engine Dash board page : https://appengine-ui-nonprod.bnymellon.net/#/dashboard
```sh
bxp context set rpx-throttler.liquidity-service --family rpx-throttler --app-name "liquidity-service" --file assembly.yaml  --dockerfile DockerFile --app-env qa
bxp app run rpx-throttler.liquidity-service --file assembly.yml --deployment qa --app-env qa
bxp app update rpx-throttler.liquidity-service --file assembly.yml --deployment qa --app-env qa
bxp app status --verbose rpx-throttler.liquidity-service --app-env qa 
bxp app delete rpx-throttler.liquidity-service --app-env qa 
bxp app show rpx-throttler.liquidity-service --app-env qa 
bxp route create rpx-throttler.liquidity-service.api --cluster dev1 --app-env qa --deployment qa --contact contact.yaml --file assembly.yml
bxp route create rpx-throttler.liquidity-service --cluster nonprod2 --app-env qa --deployment qa --contact contact.yaml --file assembly.yml
bxp route create rpx-throttler.liquidity-service.api --cluster nonprod1 --app-env qa --deployment qa --contact contact.yaml --file assembly.yml
bxp app scale rpx-throttler.liquidity-service.api --instances 2 --app-env test --space uat
bxp app scale rpx-throttler.liquidity-service.api --instances 1 --app-env test --space uat
```

### Production
bxp target prod1
App Engine Dash board page : https://appengine-ui-prod.bnymellon.net/#/dashboard
```sh
bxp change create rpx-throttler.liquidity-service --file manifest.yaml
bxp change status rpx-throttler.liquidity-service --start 2018-07-03:0300
bxp change start rpx-throttler.liquidity-service --start 2018-07-03:0300

bxp app run rpx-throttler.liquidity-service --file assembly.yml --deployment prod --app-env prod
bxp app update rpx-throttler.liquidity-service --file assembly.yml --deployment prod --app-env prod
bxp app status --verbose rpx-throttler.liquidity-service --app-env prod 
bxp app delete rpx-throttler.liquidity-service --app-env prod 
```
## [Tailing Logs from the CLI](https://confluence.bnymellon.net/display/BCS/Tailing+Logs+from+the+CLI)
```sh
bxp logs --app-env dev rpx-throttler.liquidity-service.api
bxp logs --follow --app-env dev rpx-throttler.liquidity-service.api
```
## - Scalability
The below command displays two additional web  containers. BXP load-balances (round-robin) between them when going through the cluster's route
```sh
bxp app scale rpx-throttler.liquidity-service.api --instances 3 --app-env dev
```
## [F5 URL Routing](https://confluence.bnymellon.net/display/BCS/F5+URL+Quickstart)
 ```sh
bxp route create rpx-throttler.liquidity-service.api --cluster nonprod2 --app-env dev --deployment dev --contact contact.yaml --file assembly.yml
bxp route status --url rpx-throttler.bnymellon.net --app-env dev
bxp route create rpx-throttler.liquidity-service.api --cluster nonprod2 --app-env test --deployment alpha --space alpha --contact contact.yaml --file assembly.yaml
bxp route status --url rpx-throttler-alpha.bnymellon.net --app-env dev
```
Verify Route Exist : curl https://rpx-throttler.dev.bnymellon.net/status.txt
## - Enable the Route (for a cluster)
```sh
bxp route enable rpx-throttler.liquidity-service.api --cluster dev1 --url rpx-throttler.bnymellon.net --file assembly.yml --deployment dev --app-env dev
bxp route delete rpx-throttler.liquidity-service.api --url rpx-throttler.bnymellon.net --org-id rpx
bxp route create rpx-throttler.liquidity-service.api --cluster nonprod1 --contact contact.yaml
bxp route status --url rpx-throttler.bnymellon.net
bxp route enable rpx-throttler.liquidity-service.api --cluster nonprod1 --url rpx-throttler.bnymellon.net --file assembly.yml --deployment dev --app-env dev