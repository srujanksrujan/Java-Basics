package com.bnym.gvp.throttler.service.client;

import java.math.BigDecimal;
import java.net.URI;
import java.util.List;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.bnym.rpx.throttler.service.entity.Adjustment;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.AccountLiquidity;
import com.bnym.rpx.throttler.service.model.AdjustmentRequest;
import com.bnym.rpx.throttler.service.model.Page;
import com.bnym.rpx.throttler.service.model.Transaction;
import com.bnym.rpx.throttler.service.model.TransactionDetails;
import com.bnym.rpx.throttler.service.util.DateUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class PaymentThrottlerTestClient {

	private static final String REST_PTS_ADJ_URI = "http://localhost:8080/PaymentThrottlerService/adjustments";
	private static final String REST_PTS_TRAN_URI = "http://localhost:8080/PaymentThrottlerService/transactions";
	private static final String REST_PTS_TRAND_URI = "http://localhost:8080/PaymentThrottlerService/transactionDetails";
	private static final String REST_PTS_ACCT_URI = "http://localhost:8080/PaymentThrottlerService/reference/accounts";
	private static ObjectMapper mapper = new ObjectMapper();


	/* GET */
	private static Adjustment getAdjustmentById(String adjId){
		try {
			System.out.println("Testing readAdjustment API-----------");
			RestTemplate restTemplate = new RestTemplate();
			APIResponse response = restTemplate.getForObject(REST_PTS_ADJ_URI+"/"+adjId, APIResponse.class);
			System.out.println("Response:-->" + response);

			Object obj =  response.getResult().getResultList().get(0);			
			Adjustment adj = mapper.convertValue(obj, Adjustment.class);
			return  adj;

		} catch (RestClientException e) {
			System.out.println("Bad Request!!");
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			System.out.println("Exception!!");
			e.printStackTrace();
			return null;
		}


	}



	/* POST */
	private static String createAdjustments() {
		try {
			System.out.println("Testing create Adjustment API----------");
			RestTemplate restTemplate = new RestTemplate();
			AdjustmentRequest req = new AdjustmentRequest();
			req.setAccountNo("1111111111");
			req.setAmount(new BigDecimal(5000));
			req.setAprvDcsnCd("UNAPPRVD");
			req.setSign("I");
			req.setValueDate("18-JAN-17");
			req.setUserId("SWATI");
			req.setAdjustmentResason("Testing Create API");
			req.setComment("Java Test Client");

			ResponseEntity<APIResponse> response = restTemplate.postForEntity(REST_PTS_ADJ_URI, req, APIResponse.class);
			HttpStatus status = response.getStatusCode();
			APIResponse apiResponse = response.getBody();
			System.out.println("HTTP status:-->" + status + "API Response: -->" + apiResponse);			
			Object obj =  apiResponse.getResult().getResultList().get(0);			
			Adjustment adj = mapper.convertValue(obj, Adjustment.class);

			return (adj !=null)?adj.getAdjId():null;

		} catch (RestClientException e) {
			System.out.println("Bad Request!!");
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			System.out.println("Exception!!");
			e.printStackTrace();
			return null;
		}
	}

	/* PUT */
	private static Adjustment updateAdjustment(String adjId) {

		try {
			System.out.println("Testing update Adjustment API----------");

			String uri = REST_PTS_ADJ_URI+"/"+adjId;
			RestTemplate restTemplate = new RestTemplate();
			AdjustmentRequest req = new AdjustmentRequest();
			req.setAccountNo("1111111111");
			req.setAmount(new BigDecimal(9999));
			req.setAprvDcsnCd("UNAPPRVD");
			req.setSign("I");
			req.setValueDate("18-JAN-17");
			req.setUserId("SWATI_UPD");
			req.setAdjustmentResason("Testing Create API");
			req.setComment("Java Test Client");

			System.out.println("URI:-->"+uri);
			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Type", "application/json");
			HttpEntity<AdjustmentRequest> requestEntity = new HttpEntity<AdjustmentRequest>(req, headers);

			ResponseEntity<APIResponse> response = 	restTemplate.exchange(uri, HttpMethod.PUT,requestEntity ,APIResponse.class);

			HttpStatus status = response.getStatusCode();
			APIResponse apiResponse = response.getBody();
			System.out.println("HTTP status:-->" + status + "API Response: -->" + apiResponse);
			Object obj =  apiResponse.getResult().getResultList().get(0);			
			Adjustment adj = mapper.convertValue(obj, Adjustment.class);

			return adj;

		} catch (RestClientException e) {
			System.out.println("Bad Request!!");
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			System.out.println("Exception!!");
			e.printStackTrace();
			return null;
		}
	}


	/* PUT */
	private static String approveAdjustment(String adjId, String dcsnCode, String action) {
		try {
			System.out.println("Testing approve Adjustment API----------");
			RestTemplate restTemplate = new RestTemplate();
			AdjustmentRequest req = new AdjustmentRequest();
			req.setAprvDcsnCd(dcsnCode);
			req.setAdjustmentResason("Testing Create API");
			req.setComment("Java Test Client");

			String uri = REST_PTS_ADJ_URI+"/decision/"+adjId+"?action="+action;

			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Type", "application/json");
			HttpEntity<AdjustmentRequest> requestEntity = new HttpEntity<AdjustmentRequest>(req, headers);

			ResponseEntity<APIResponse> response;

			response = restTemplate.exchange(uri, HttpMethod.PUT,requestEntity ,APIResponse.class);


			HttpStatus status = response.getStatusCode();
			APIResponse apiResponse = response.getBody();
			System.out.println("HTTP status:-->" + status + "API Response: -->" + apiResponse);

			Object obj =  apiResponse.getResult().getResultList().get(0);			
			Adjustment adj = mapper.convertValue(obj, Adjustment.class);

			return  (adj == null) ? null : adj.getAprvDcsnCd();

		} catch (RestClientException e) {
			System.out.println("Bad Request!!!");
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			System.out.println("Exception!!");
			e.printStackTrace();
			return null;
		}
	}


	/* GET */
	private static void getAllAccounts(){
		try {
			System.out.println("Testing getAllAccounts API-----------");
			RestTemplate restTemplate = new RestTemplate();
			APIResponse response = restTemplate.getForObject(REST_PTS_ACCT_URI, APIResponse.class);
			System.out.println("Response:-->" + response);

			List <AccountLiquidity> acctList = mapper.convertValue(response.getResult().getResultList(), new TypeReference<List<AccountLiquidity>>() { });

			for(AccountLiquidity acct:acctList){				
				System.out.println("ACCOUNT:--->"+acct);				
			}

		} catch (RestClientException e) {
			System.out.println("Bad Request!!");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception!!");
			e.printStackTrace();
		}

	}


	/* GET */
	private static void getAllAdjustments(){

		try {
			System.out.println("Testing getAllAdjustment API-----------");

			RestTemplate restTemplate = new RestTemplate();

			//Query parameters
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(REST_PTS_ADJ_URI)
					.queryParam("accountNo", "acc001")
					.queryParam("valueDate", "06-JAN-17")
					.queryParam("pageNo", 1)
					.queryParam("pageSize", 5)
					.queryParam("sortKey", "ADJ_ID")
					.queryParam("sortOrder", "ASC");


			System.out.println(builder.build().encode().toUri());
			HttpHeaders headers = new HttpHeaders();
			HttpEntity<?> entity = new HttpEntity<Object>(headers);

			URI uri =builder.build().encode().toUri();

			System.out.println("URI:-->"+uri);

			ResponseEntity<APIResponse> response = restTemplate.exchange(
					uri, 
					HttpMethod.GET, 
					entity, 
					APIResponse.class);

			HttpStatus status = response.getStatusCode();
			APIResponse apiResponse = response.getBody();
			System.out.println("HTTP status:-->" + status + "API Response: -->" + apiResponse);

			List<Page<Adjustment>> adjPageList = mapper.convertValue(apiResponse.getResult().getResultList(), new TypeReference<List<Page<Adjustment>>>() { });

			for(Page<Adjustment> adjPage:adjPageList){
				for(Adjustment adj:adjPage.getPageItems()){
					System.out.println("ADJUSTMENT:--->"+adj);
				}
			}

		} catch (RestClientException e) {
			System.out.println("Bad Request!!");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception!!");
			e.printStackTrace();
		}


	}


	/* GET */

	private static void getAllTransactions(String tranType){

		try {
			System.out.println("Testing getAllTransactions API-----------");

			RestTemplate restTemplate = new RestTemplate();

			//Query parameters
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(REST_PTS_TRAN_URI)
					.queryParam("tranType", tranType)
					.queryParam("srcReferenceNo", "RTP1811161100001")
					.queryParam("accountNo", "1111111111")
					.queryParam("fromValueDate", "22-DEC-2010")
					.queryParam("toValueDate", "22-DEC-2017")
					.queryParam("fromAmount", new BigDecimal(0))
					.queryParam("toAmount", new BigDecimal(10000))
					.queryParam("procStatus", "RELD")
					.queryParam("currencyCode", "USD")
					.queryParam("pageNo", 1)
					.queryParam("pageSize", 5)
					.queryParam("sortKey", "SRC_REF_NO")
					.queryParam("sortOrder", "ASC");


			System.out.println(builder.build().encode().toUri());
			HttpHeaders headers = new HttpHeaders();
			HttpEntity<?> entity = new HttpEntity<Object>(headers);

			URI uri =builder.build().encode().toUri();

			System.out.println("URI:-->"+uri);

			ResponseEntity<APIResponse> response = restTemplate.exchange(
					uri, 
					HttpMethod.GET, 
					entity, 
					APIResponse.class);

			HttpStatus status = response.getStatusCode();
			APIResponse apiResponse = response.getBody();
			System.out.println("HTTP status:-->" + status + "API Response: -->" + apiResponse);


			List<Page<Transaction>> tranPageList = mapper.convertValue(apiResponse.getResult().getResultList(), new TypeReference<List<Page<Transaction>>>() { });

			for(Page<Transaction> tranPage:tranPageList){
				for(Transaction tran:tranPage.getPageItems()){
					System.out.println("TRANSACTION:--->"+tran);
				}
			}

		} catch (RestClientException e) {
			System.out.println("Bad Request!!");
			e.printStackTrace();
		} catch (Exception e) {
			System.out.println("Exception!!");
			e.printStackTrace();
		}



	}

	/* GET */

	private static TransactionDetails getTransactionDetails(){

		try {
			System.out.println("Testing getAllTransactions API-----------");

			RestTemplate restTemplate = new RestTemplate();

			//Query parameters
			UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(REST_PTS_TRAND_URI)
					.queryParam("tranType", "PY")
					.queryParam("srcRefNo", "RTP1811161100001")
					.queryParam("srcSysCd", "1")
					.queryParam("adtVrsnNo", "1");
					

			System.out.println(builder.build().encode().toUri());
			HttpHeaders headers = new HttpHeaders();
			HttpEntity<?> entity = new HttpEntity<Object>(headers);

			URI uri = builder.build().encode().toUri();

			System.out.println("URI:-->"+uri);

			ResponseEntity<APIResponse> response = restTemplate.exchange(
					uri, 
					HttpMethod.GET, 
					entity, 
					APIResponse.class);

			HttpStatus status = response.getStatusCode();
			APIResponse apiResponse = response.getBody();
			System.out.println("HTTP status:-->" + status + "API Response: -->" + apiResponse);

			Object obj =  apiResponse.getResult().getResultList().get(0);			
			TransactionDetails tran = mapper.convertValue(obj, TransactionDetails.class);
			return  tran;
		
		} catch (RestClientException e) {
			System.out.println("Bad Request!!");
			e.printStackTrace();
			return null;
		} catch (Exception e) {
			System.out.println("Exception!!");
			e.printStackTrace();
			return null;
		}



	}


	public static void main(String args[]){
		System.out.println("**********Create new Adjustment************");
		String adjId=createAdjustments();	
		System.out.println("New Adjustment created:--> ADJ_ID:"+adjId);

		System.out.println("**********Get Adjustment By Id************");
		Adjustment adj=getAdjustmentById(adjId);
		System.out.println("Retrieved Adjustment:"+ adj);

		System.out.println("**********Update Adjustment************");
		adj=updateAdjustment(adjId);
		System.out.println("Updated Adjustment:"+ adj);
		System.out.println("**********Reject Adjustment************");
		String decision=approveAdjustment(adjId,"REJECTED", "reject");
		System.out.println("Status of Adjustment with ADJ_ID="+ adjId +":-->"+decision);
		
		System.out.println("**********Approve Adjustment************");
		decision=approveAdjustment(adjId,"APPRVD", "approve");
		System.out.println("Status of Adjustment with ADJ_ID="+ adjId +":-->"+decision);
		
		
		System.out.println("**********Get Transaction Details************");
		TransactionDetails tran= getTransactionDetails();
		System.out.println("Transaction Details="+ tran);
		
		System.out.println("**********Get All Adjustments************");
		getAllAdjustments();	

		System.out.println("**********Get All Accounts************");
		getAllAccounts();

		System.out.println("**********Get All Transactions************");
		getAllTransactions(null);

		System.out.println("**********Get All PAYMENT Transactions************");
		getAllTransactions("PY");

		System.out.println("**********Get All CREDIT Transactions************");
		getAllTransactions("CR");
	} 
}