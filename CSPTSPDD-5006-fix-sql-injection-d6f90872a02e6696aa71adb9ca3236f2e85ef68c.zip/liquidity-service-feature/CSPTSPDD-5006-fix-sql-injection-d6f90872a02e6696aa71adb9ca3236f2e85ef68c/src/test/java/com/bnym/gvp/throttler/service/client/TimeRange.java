package com.bnym.gvp.throttler.service.client;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.joda.time.DateTime;

public class TimeRange {
	public static void main(String[] args) throws ParseException {
		Date startTime =   new DateTime().withTimeAtStartOfDay().toDate();  
		Date endTime = new Date();
		System.out.println("Start Time:"+startTime + " End Time:"+endTime);
		ArrayList<String> times = new ArrayList<String>();
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm");
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(startTime);
		while (calendar.getTime().before(endTime)) {
			calendar.add(Calendar.MINUTE, 1);
			times.add(sdf.format(calendar.getTime()));
		}
		System.out.println(times);
	}
}
