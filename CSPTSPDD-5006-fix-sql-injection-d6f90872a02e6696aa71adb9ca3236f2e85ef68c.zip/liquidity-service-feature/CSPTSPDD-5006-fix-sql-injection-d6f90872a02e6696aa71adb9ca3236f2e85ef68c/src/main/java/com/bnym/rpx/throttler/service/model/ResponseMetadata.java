/**
* Description
*
* @author  Swati Rashmi
* @version 1.0
* @since   Dec 19, 2016
*/
package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;

/**
* Description
*
* @author  Swati Rashmi
* @version 1.0
* @since   Dec 19, 2016
*/
public class ResponseMetadata implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int responseCode;
	private String responseDesc;
	/**
	 * @return the responseCode
	 */
	public int getResponseCode() {
		return responseCode;
	}
	/**
	 * @param responseCode the responseCode to set
	 */
	public void setResponseCode(int responseCode) {
		this.responseCode = responseCode;
	}
	/**
	 * @return the responseDesc
	 */
	public String getResponseDesc() {
		return responseDesc;
	}
	/**
	 * @param responseDesc the responseDesc to set
	 */
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	/**
	 * 
	 */
	public ResponseMetadata() {
		super();
	}
	/**
	 * @param responseCode
	 * @param responseDesc
	 */
	public ResponseMetadata(int responseCode, String responseDesc) {
		super();
		this.responseCode = responseCode;
		this.responseDesc = responseDesc;
	}
	@Override
	public String toString() {
		return "ResponseMetadata [responseCode=" + responseCode + ", responseDesc=" + responseDesc + "]";
	}
	
	

}
