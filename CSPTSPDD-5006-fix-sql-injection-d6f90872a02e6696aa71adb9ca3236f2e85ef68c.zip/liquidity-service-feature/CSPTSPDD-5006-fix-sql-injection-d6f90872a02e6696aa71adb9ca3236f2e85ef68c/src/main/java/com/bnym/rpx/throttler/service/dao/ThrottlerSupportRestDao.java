package com.bnym.rpx.throttler.service.dao;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import com.bnym.rpx.throttler.service.exception.DAOException;

public interface ThrottlerSupportRestDao {

	public int configureCalculatorHost(String hostName, String accountNumber, String throttlerGroupId, String activeFlag,
			Timestamp currentTimestamp) throws DAOException;

	public int configCalcHostFlag(String hostName, String accountNumber, String throttlerGroupId,
			String activeFlag, Timestamp currentTimestamp) throws DAOException;

	public int configureSchedulerHost(String hostName, String activeFlag, String comments, Timestamp currentTimestamp)
			throws DAOException;

	public int configureSchedulerHostFlag(String hostName, String activeFlag, Timestamp currentTimestamp)
			throws DAOException;

	public int configureHazelCastConfig(String dataCentre, String hazlecastConfig, String activeFlag, String comments,
			Timestamp currentTimestamp) throws DAOException;

	public int configHazlecastIPAddress(String dataCentre, String hazlecastConfig,
			Timestamp currentTimestamp) throws DAOException;

	public int configureHazelcastConfigFlag(String dataCentre, String activeFlag, Timestamp currentTimestamp)
			throws DAOException;

	
	

}
