package com.bnym.rpx.throttler.service.client;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import bxp.security.spring.BXPSecurityConfig;
@Configuration
@EnableWebSecurity
public class SecurityConfig extends BXPSecurityConfig {
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		super.configure(http);
		http.csrf().disable();
		http.cors().and();
		http.requestMatchers().anyRequest();
	}
	@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().antMatchers("/health/status");
	} 
}