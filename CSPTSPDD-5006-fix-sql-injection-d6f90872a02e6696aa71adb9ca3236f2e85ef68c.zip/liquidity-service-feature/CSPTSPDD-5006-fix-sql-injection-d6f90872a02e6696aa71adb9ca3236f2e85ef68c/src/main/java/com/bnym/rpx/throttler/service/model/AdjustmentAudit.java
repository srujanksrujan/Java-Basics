package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the T_GVP_THRTL_ADJ_ADT database table.
 * 
 */

public class AdjustmentAudit implements Serializable {
	private static final long serialVersionUID = 1L;


	private String adjId;
	private long adtVrsnNo;
	private String acctBrCd;
	private String acctNo;
	private String acctSrcSysCd;
	private String adjInOutCd;
	private String adjRsnTx;
	private String aprvDcsnCd;
	private Timestamp aprvTs;
	private String aprvUsrId;
	private String cmntTx;
	private Timestamp crtTs;
	private String crtUsrId;
	private String procStat;
	private BigDecimal pyAmt;
	private String thrtlGrpId;
	private Timestamp updTs;
	private String updUsrId;
	private Date valDt;


	public String getAdjId() {
		return adjId;
	}


	public void setAdjId(String adjId) {
		this.adjId = adjId;
	}


	public long getAdtVrsnNo() {
		return adtVrsnNo;
	}


	public void setAdtVrsnNo(long adtVrsnNo) {
		this.adtVrsnNo = adtVrsnNo;
	}


	public String getAcctBrCd() {
		return this.acctBrCd;
	}

	public void setAcctBrCd(String acctBrCd) {
		this.acctBrCd = acctBrCd;
	}

	public String getAcctNo() {
		return this.acctNo;
	}

	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	public String getAcctSrcSysCd() {
		return this.acctSrcSysCd;
	}

	public void setAcctSrcSysCd(String acctSrcSysCd) {
		this.acctSrcSysCd = acctSrcSysCd;
	}

	public String getAdjInOutCd() {
		return this.adjInOutCd;
	}

	public void setAdjInOutCd(String adjInOutCd) {
		this.adjInOutCd = adjInOutCd;
	}

	public String getAdjRsnTx() {
		return this.adjRsnTx;
	}

	public void setAdjRsnTx(String adjRsnTx) {
		this.adjRsnTx = adjRsnTx;
	}

	public String getAprvDcsnCd() {
		return this.aprvDcsnCd;
	}

	public void setAprvDcsnCd(String aprvDcsnCd) {
		this.aprvDcsnCd = aprvDcsnCd;
	}

	public Timestamp getAprvTs() {
		return this.aprvTs;
	}

	public void setAprvTs(Timestamp aprvTs) {
		this.aprvTs = aprvTs;
	}

	public String getAprvUsrId() {
		return this.aprvUsrId;
	}

	public void setAprvUsrId(String aprvUsrId) {
		this.aprvUsrId = aprvUsrId;
	}

	public String getCmntTx() {
		return this.cmntTx;
	}

	public void setCmntTx(String cmntTx) {
		this.cmntTx = cmntTx;
	}

	public Timestamp getCrtTs() {
		return this.crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getCrtUsrId() {
		return this.crtUsrId;
	}

	public void setCrtUsrId(String crtUsrId) {
		this.crtUsrId = crtUsrId;
	}

	public String getProcStat() {
		return this.procStat;
	}

	public void setProcStat(String procStat) {
		this.procStat = procStat;
	}

	public BigDecimal getPyAmt() {
		return this.pyAmt;
	}

	public void setPyAmt(BigDecimal pyAmt) {
		this.pyAmt = pyAmt;
	}

	public String getThrtlGrpId() {
		return this.thrtlGrpId;
	}

	public void setThrtlGrpId(String thrtlGrpId) {
		this.thrtlGrpId = thrtlGrpId;
	}

	public Timestamp getUpdTs() {
		return this.updTs;
	}

	public void setUpdTs(Timestamp updTs) {
		this.updTs = updTs;
	}

	public String getUpdUsrId() {
		return this.updUsrId;
	}

	public void setUpdUsrId(String updUsrId) {
		this.updUsrId = updUsrId;
	}

	public Date getValDt() {
		return this.valDt;
	}

	public void setValDt(Date valDt) {
		this.valDt = valDt;
	}

}