/**
* Description
*
* @author  Swati Rashmi
* @version 1.0
* @since   Dec 19, 2016
*/
package com.bnym.rpx.throttler.service.model;

import java.util.List;

/**
* Description
*
* @author  Swati Rashmi
* @version 1.0
 * @param <T>
* @since   Dec 19, 2016
*/
public class Result<T> {
	
	List<T> resultList;

	

	public List<T> getResultList() {
		return resultList;
	}

	public void setResultList(List<T> resultList) {
		this.resultList = resultList;
	}
	
	

	/**
	 * 
	 */
	public Result() {
		super();
	}

	/**
	 * @param resultList
	 */
	public Result(List<T> resultList) {
		super();
		this.resultList = resultList;
	}

	@Override
	public String toString() {
		return "Result [resultList=" + resultList + "]";
	}

	
	
	

}
