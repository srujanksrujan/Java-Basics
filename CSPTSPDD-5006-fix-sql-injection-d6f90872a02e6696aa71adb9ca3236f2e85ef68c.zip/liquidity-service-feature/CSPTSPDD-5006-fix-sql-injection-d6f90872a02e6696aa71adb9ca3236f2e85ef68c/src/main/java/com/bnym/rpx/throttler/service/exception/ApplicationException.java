/**
* File: ApplicationException.java 
* Project - Liquidity Management (LQM)
* 
* Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
* 
* This software is the confidential and proprietary information of BNY Melon
* Corporation ("Confidential Information").
* 
*/

package com.bnym.rpx.throttler.service.exception;

/**
 * 
 * The LQM Application Exception class to log the exception details with stack trace in Log file or Console
 * 
 * @author Liquidity Management Team
 *
 */
public class ApplicationException extends Exception {
	/**
	 * The serialVersionUID is used as a version control in a Serializable
	 * class.If you do not explicitly declare a serialVersionUID, JVM will did
	 * it for you automatically, based on various aspects of your Serializable
	 * class, as describe in the Java(TM) Object Serialization Specification.
	 */
	private static final long serialVersionUID = -1545351779297769157L;

	/** The Constant ERROR_MESSAGE. */
	public static final String ERROR_MESSAGE = "Liquidity Management (LQM) Application Exception";


	public static String getErrorMessage() {
		return ERROR_MESSAGE;
	}

	public ApplicationException() {
		super(ERROR_MESSAGE);
	}

	public ApplicationException(final String message) {
		super(message);
	}

	public ApplicationException(final String message,
			final Throwable throwable) {
		super(message, throwable);
	}

	public ApplicationException(final Throwable throwable) {
		super(throwable);
	}
}
