/**
* Description
*
* @author  Swati Rashmi
* @version 1.0
* @since   Dec 19, 2016
*/
package com.bnym.rpx.throttler.service.model;

/**
* Description
*
* @author  Swati Rashmi
* @version 1.0
* @since   Dec 19, 2016
*/
public class APIError {
	private String errorCode;
	private String errorDesc;

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}
	/**
	 * @param errorCode the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	/**
	 * @return the errorDesc
	 */
	public String getErrorDesc() {
		return errorDesc;
	}
	/**
	 * @param errorDesc the errorDesc to set
	 */
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}

	/**
	 * @param errorCode
	 * @param errorDesc
	 */
	public APIError(String errorCode, String errorDesc) {
		super();
		this.errorCode = errorCode;
		this.errorDesc = errorDesc;
	}
	/**
	 * 
	 */
	public APIError() {
		super();
	}
	
	@Override
	public String toString() {
		return "APIError [errorCode=" + errorCode + ", errorDesc=" + errorDesc + "]";
	}
	
	

}
