package com.bnym.rpx.throttler.service.model;

public class ThrottlerHostProcTable {

	private String sequenceNumber;
	private String hostName;
	private String port;
	private String applicationJVM;
	private String accountNumber;
	private String throttlerGroupId;
	private String activeFlag;
	private String comments;
	private String currentUserId;
	private String currentTimestamp;
	private String updatedUserID;
	private String updatedTimestamp;
	public String getSequenceNumber() {
		return sequenceNumber;
	}
	public void setSequenceNumber(String sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}
	public String getHostName() {
		return hostName;
	}
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	public String getApplicationJVM() {
		return applicationJVM;
	}
	public void setApplicationJVM(String applicationJVM) {
		this.applicationJVM = applicationJVM;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getThrottlerGroupId() {
		return throttlerGroupId;
	}
	public void setThrottlerGroupId(String throttlerGroupId) {
		this.throttlerGroupId = throttlerGroupId;
	}
	public String getActiveFlag() {
		return activeFlag;
	}
	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comment) {
		this.comments = comment;
	}
	public String getCurrentUserId() {
		return currentUserId;
	}
	public void setCurrentUserId(String currentUserId) {
		this.currentUserId = currentUserId;
	}
	public String getCurrentTimestamp() {
		return currentTimestamp;
	}
	public void setCurrentTimestamp(String currentTimestamp) {
		this.currentTimestamp = currentTimestamp;
	}
	public String getUpdatedUserID() {
		return updatedUserID;
	}
	public void setUpdatedUserID(String updatedUserID) {
		this.updatedUserID = updatedUserID;
	}
	public String getUpdatedTimestamp() {
		return updatedTimestamp;
	}
	@Override
	public String toString() {
		return "ThrottlerHostProcTable [sequenceNumber=" + sequenceNumber + ", hostName=" + hostName + ", port=" + port
				+ ", applicationJVM=" + applicationJVM + ", accountNumber=" + accountNumber + ", throttlerGroupId="
				+ throttlerGroupId + ", activeFlag=" + activeFlag + ", comments=" + comments + ", currentUserId="
				+ currentUserId + ", currentTimestamp=" + currentTimestamp + ", updatedUserID=" + updatedUserID
				+ ", updatedTimestamp=" + updatedTimestamp + "]";
	}
	public void setUpdatedTimestamp(String updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}
	

}
