package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TransactionsInputRequest implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String tranType; 
	private String refNo; 
	private String acctNo; 
	private String fromValueDate;
	private String toValueDate;
	private BigDecimal fromAmount;
	private BigDecimal toAmount;
	private String status;
	private String ccyCode;
	private int pageNo;
	private int pageSize;
	private String sortKeys;
	private String sortKey;
	private String sortOrder;
	public String getTranType() {
		return tranType;
	}
	public void setTranType(String tranType) {
		this.tranType = tranType;
	}
	public String getRefNo() {
		return refNo;
	}
	public void setRefNo(String refNo) {
		this.refNo = refNo;
	}
	public String getAcctNo() {
		return acctNo;
	}
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	public String getFromValueDate() {
		return fromValueDate;
	}
	public void setFromValueDate(String fromValueDate) {
		this.fromValueDate = fromValueDate;
	}
	public String getToValueDate() {
		return toValueDate;
	}
	public void setToValueDate(String toValueDate) {
		this.toValueDate = toValueDate;
	}
	public BigDecimal getFromAmount() {
		return fromAmount;
	}
	public void setFromAmount(BigDecimal fromAmount) {
		this.fromAmount = fromAmount;
	}
	public BigDecimal getToAmount() {
		return toAmount;
	}
	public void setToAmount(BigDecimal toAmount) {
		this.toAmount = toAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCcyCode() {
		return ccyCode;
	}
	public void setCcyCode(String ccyCode) {
		this.ccyCode = ccyCode;
	}
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	public String getSortKey() {
		return sortKey;
	}
	public void setSortKey(String sortKey) {
		this.sortKey = sortKey;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getSortKeys() {
		return sortKeys;
	}
	public void setSortKeys(String sortKeys) {
		this.sortKeys = sortKeys;
	}
	@Override
	public String toString() {
		return "TransactionsInputRequest [tranType=" + tranType + ", refNo=" + refNo + ", acctNo=" + acctNo + ", fromValueDate=" + fromValueDate
				+ ", toValueDate=" + toValueDate + ", fromAmount=" + fromAmount + ", toAmount=" + toAmount + ", status=" + status + ", ccyCode="
				+ ccyCode + ", pageNo=" + pageNo + ", pageSize=" + pageSize + ", sortKeys=" + sortKeys + ", sortKey=" + sortKey + ", sortOrder="
				+ sortOrder + "]";
	}
}
