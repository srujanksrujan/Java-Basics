/**
 * File: RefDataBuilder.java
 * Description: Fetches Reference data like account details
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 5, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.builder;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnym.rpx.throttler.service.dao.impl.AccountLiquidityDAOImpl;
import com.bnym.rpx.throttler.service.dao.impl.ConfigDAOImpl;
import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.exception.NoDataFoundException;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.AccountLiquidity;
import com.bnym.rpx.throttler.service.model.BusinessDate;
import com.bnym.rpx.throttler.service.model.Config;
import com.bnym.rpx.throttler.service.model.Result;

@Component
public class RefDataBuilder {

	private static final Logger LOGGER = Logger.getLogger(RefDataBuilder.class);

	private AccountLiquidityDAOImpl accountDAOImpl;

	public AccountLiquidityDAOImpl getAccountDAOImpl() {
		return accountDAOImpl;
	}

	@Autowired
	public void setAccountDAOImpl(AccountLiquidityDAOImpl accountDAOImpl) {
		this.accountDAOImpl = accountDAOImpl;
	}

	private ConfigDAOImpl configDAOImpl;

	public ConfigDAOImpl getConfigDAOImpl() {
		return configDAOImpl;
	}

	@Autowired
	public void setConfigDAOImpl(ConfigDAOImpl configDAOImpl) {
		this.configDAOImpl = configDAOImpl;
	}

	public APIResponse buildGetAllAccountsResponse() throws ApplicationException {
		APIResponse apiResponse = new APIResponse();
		List<AccountLiquidity> responseList = null;
		try {
			LOGGER.info("buildGetAllAccountsResponse() called in RefDataBuilder");
			responseList = accountDAOImpl.getAllAccounts();
			apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return apiResponse;
	}

	public APIResponse buildGetAdjReasonsResponse() throws ApplicationException {
		APIResponse apiResponse = new APIResponse();
		List<Config> responseList = null;
		try {
			LOGGER.info("buildGetAdjReasonsResponse() called in RefDataBuilder");
			responseList = configDAOImpl.getAdjustmentReasons();
			apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return apiResponse;
	}

	public APIResponse getBusinessDate() throws ApplicationException {
		APIResponse apiResponse = new APIResponse();
		List<BusinessDate> responseList = new ArrayList<BusinessDate>();
		try {
			LOGGER.info("getBusinessDate() called in RefDataBuilder");
			responseList = configDAOImpl.getBusinessDate();
			apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return apiResponse;
	}

	public APIResponse buildGetAdjStatusResponse() throws ApplicationException {
		APIResponse apiResponse = new APIResponse();
		List<Config> responseList = null;
		try {
			LOGGER.info("buildGetAdjStatusResponse() called in RefDataBuilder");
			responseList = configDAOImpl.getAdjustmentStatus();
			apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return apiResponse;
	}

	/**
	 * Gets the list of configs which are active for the given configName
	 * 
	 * @param configName
	 * @return APIResponse which contains the result list
	 * @throws ApplicationException
	 *             if any exception occurs
	 * @throws NoDataFoundException
	 *             if no data found
	 */
	public APIResponse getActiveConfigs(String configName) throws ApplicationException, NoDataFoundException {
		APIResponse apiResponse = new APIResponse();
		List<Config> responseList = null;
		try {

			responseList = configDAOImpl.getActiveConfigs(configName);
			apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
			return apiResponse;
		} catch (DAOException e) {
			throw new ApplicationException(e);
		}

	}

}
