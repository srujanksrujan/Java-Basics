package com.bnym.rpx.throttler.service.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.bnym.rpx.throttler.service.dao.TransactionMessageDAO;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.TransactionMessageDetails;

@Repository("transactionMessageDAOImpl")
public class TransactionMessageDAOImpl extends GenericDAO implements TransactionMessageDAO {

	private static final Logger LOGGER = Logger.getLogger(TransactionMessageDAOImpl.class);

	private static final class MessageDetailRowMapper implements RowMapper<TransactionMessageDetails> {
		public TransactionMessageDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			TransactionMessageDetails message = new TransactionMessageDetails();
			message.setToDefaultValue();
			message.setMessageQueueName(rs.getString("MSG_QUE_NM"));
			message.setMessageReferenNumber(rs.getString("MSG_REF_NO"));
			message.setMessageProcessStatusCode(rs.getString("MSG_PROC_STAT_CD"));
			message.setMessageProcessReasonText(rs.getString("PROC_RSN_TX"));
			message.setRawMessage(rs.getString("message"));
			return message;
		}
	}

	@Override
	public List<TransactionMessageDetails> getTranactionMessageDetails(String referenceNumber, String paymentStatus)
			throws DAOException {
		try {
			String sql = "SELECT MSG_QUE_NM, MSG_REF_NO, MSG_PROC_STAT_CD,  PROC_RSN_TX, to_char(MSG_OBJ_TX) as message FROM t_gvp_thrtl_msg  "
					+ "  WHERE MSG_REF_NO =:referenceNumber AND MSG_PROC_STAT_CD =:paymentStatus ORDER BY UPD_TS DESC";
			SqlParameterSource namedParameters = new MapSqlParameterSource("referenceNumber", referenceNumber)
					.addValue("paymentStatus", paymentStatus);
			return getNamedParameterJdbcTemplate().query(sql, namedParameters, new MessageDetailRowMapper());
		} catch (Exception ex) {
			LOGGER.info("Exception while getting getTranactionMessageDetails : " + ex.getMessage());
			throw new DAOException(ex);
		}
	}
}
