package com.bnym.rpx.throttler.service.handler;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.model.DomainUrl;
import com.bnym.rpx.throttler.service.util.ApplicationType;

@Service
public class PropertyFileHandler {

	private static final Logger LOGGER = Logger.getLogger(PropertyFileHandler.class);

	public List<DomainUrl> buildGetDomainUrlResponse(String region) throws ApplicationException {
		List<DomainUrl> domainUrlList = new ArrayList<DomainUrl>();
		Properties properties = null;
		try {
			String propertyFilePath = "config/" + region + ".domainurl.properties";
			properties = getPropertyFileHandle(propertyFilePath);
			
			if (properties != null) {
				DomainUrl domainUrl = new DomainUrl();
				DomainUrl domainUrlClone = new DomainUrl();
				for (ApplicationType appType : ApplicationType.values()) {
					String domainUrlStr = properties.getProperty(appType.code());
					if(domainUrlStr!=null){
						domainUrl = (DomainUrl) domainUrlClone.clone();
						domainUrl.setRegion(region);
						domainUrl.setApplicationCode(appType.code());
						domainUrl.setApplicationDomainUrl(properties.getProperty(appType.code()));
						domainUrlList.add(domainUrl);	
					}
				}
			}
		} catch (Exception ex) {
			LOGGER.info("Exception while getting buildGetDomainUrlResponse : " + ex.getMessage());
			throw new ApplicationException(ex);
		}
		return domainUrlList;
	}

	public Properties getPropertyFileHandle(String propertyFilePath) throws ApplicationException, IOException {
		Properties properties = new Properties();
		InputStream is = null;
		try {
			is = PropertyFileHandler.class.getClassLoader().getResourceAsStream(propertyFilePath);
			properties.load(is);
		} catch (IOException ex) {
			throw new ApplicationException("Exception while getting property file handle : " + ex.getMessage());
		} finally {
			if (is != null) {
				is.close();
			}
		}
		return properties;
	}
}
