package com.bnym.rpx.throttler.service.model;

import java.util.Date;

public class ThrottlerConfigTable {

	private Number sequenceNumber;
	private String functionName;
	private String keyName;
	private String valueName;
	private String descTx;
	private String activeFlag;
	private String createUserId;
	private String createTimestamp;
	private String updatedUserId;
	private String updatedTimestamp;

	public Number getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(Number sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public String getKeyName() {
		return keyName;
	}

	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}

	public String getValueName() {
		return valueName;
	}

	public void setValueName(String valueName) {
		this.valueName = valueName;
	}

	public String getDescTx() {
		return descTx;
	}

	public void setDescTx(String descTx) {
		this.descTx = descTx;
	}

	public String getActiveFlag() {
		return activeFlag;
	}

	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}

	public String getCreateUserId() {
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(String createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public String getUpdatedUserId() {
		return updatedUserId;
	}

	public void setUpdatedUserId(String updatedUserId) {
		this.updatedUserId = updatedUserId;
	}

	public String getUpdatedTimestamp() {
		return updatedTimestamp;
	}

	public void setUpdatedTimestamp(String updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}

	@Override
	public String toString() {
		return "ThrottlerConfigTable [sequenceNumber=" + sequenceNumber + ", functionName=" + functionName
				+ ", keyName=" + keyName + ", valueName=" + valueName + ", descTx=" + descTx + ", activeFlag="
				+ activeFlag + ", createUserId=" + createUserId + ", createTimestamp=" + createTimestamp
				+ ", updatedUserId=" + updatedUserId + ", updatedTimestamp=" + updatedTimestamp + "]";
	}

}
