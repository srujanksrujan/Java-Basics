/**
 * File: TransactionDAO.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 6, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.dao;

import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.Page;
import com.bnym.rpx.throttler.service.model.Transaction;
import com.bnym.rpx.throttler.service.model.TransactionDetails;
import com.bnym.rpx.throttler.service.model.TransactionsInputRequest;

public interface TransactionDAO {
	
	TransactionDetails getTranactionDetails (String type, String srcRefNo, String srcSysCd,	String adtVrsnNo)throws DAOException ;
	
	Page<Transaction> getAllTransactions(TransactionsInputRequest transactionsInputRequest) throws DAOException;

}
