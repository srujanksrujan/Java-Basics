package com.bnym.rpx.throttler.service.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CreditRequestAuditPk implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "SRC_REF_NO")
	private String srcRefNo;

	@Column(name = "SRC_SYS_CD")
	private String srcSysCode;

	@Column(name = "ADT_VRSN_NO")
	private String adtVersionNo;

	public String getSrcRefNo() {
		return srcRefNo;
	}

	public void setSrcRefNo(String srcRefNo) {
		this.srcRefNo = srcRefNo;
	}

	public String getSrcSysCode() {
		return srcSysCode;
	}

	public void setSrcSysCode(String srcSysCode) {
		this.srcSysCode = srcSysCode;
	}

	public String getAdtVersionNo() {
		return adtVersionNo;
	}

	public void setAdtVersionNo(String adtVersionNo) {
		this.adtVersionNo = adtVersionNo;
	}

	@Override
	public String toString() {
		return "CreditRequestAuditPk [srcRefNo=" + srcRefNo + ", srcSysCode=" + srcSysCode + ", adtVersionNo="
				+ adtVersionNo + "]";
	}

}
