package com.bnym.rpx.throttler.service.dao.impl;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;

import com.bnym.rpx.throttler.service.dao.ThrottlerAccountDao;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.ThrottlerAccountLiquidityTable;
import com.bnym.rpx.throttler.service.model.ThrottlerConfigTable;
import com.bnym.rpx.throttler.service.model.ThrottlerGroupModelTable;
import com.bnym.rpx.throttler.service.model.ThrottlerHostProcTable;

@Repository
public class ThrottlerAccountDaoImpl extends GenericDAO implements ThrottlerAccountDao {

	private static final Logger LOGGER = Logger.getLogger(ThrottlerSupportRestDaoImpl.class);
	private static final String EXCEPTION = "Exception:";
	private static final String USER_ID = "rtp_app";
	private static final String X = "X";
	private static final String CMNT_TX = "Throttler Group 1";
	private static final String TCH = "TCH";
	
	public int getSeqNo() throws DAOException {
		try {
			LOGGER.info("getSeqNo() called in ThrottlerHostProcDao");
			String sql = "select (MAX(SEQ_NO)+1) FROM T_GVP_THRTL_HOST_PROC";
			return getJdbcTemplate().queryForObject(sql, Integer.class);
		} catch (Exception e) {
			LOGGER.error("Exception while updating the sequence number  :" + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public int addThrottlerAccountLiquidity(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, Number availableAmt, Timestamp currentTimestamp, Date date)
			throws DAOException {
		try {
			LOGGER.info("addThrottlerAccountLiquidity() called in ThrottlerAccountLiquidity");
			String sql = "Insert into GVP_INTSRV_MGMT.T_GVP_THRTL_ACCT_LQDY (ACCT_NO,ACCT_BR_CD,ACCT_SRC_SYS_CD,THRTL_GRP_ID,ACTL_BAL_EFF_TS,AVL_AM,BULK_ID,VAL_DT,UPD_USR_ID,UPD_TS) VALUES (?,?,?,?,?,?,?,?,?,?)";
			return getJdbcTemplate().update(sql, accountNumber, accountBranchCode, accountSourceSysCode, groupId,
					currentTimestamp, availableAmt, null, date, USER_ID, currentTimestamp);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while calling addThrottlerAccountLiquidity()  in ThrottlerAccountLiquidity "
					+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public int addThrottlerAccountLiquidityAudit(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, Number availableAmt, Timestamp currentTimestamp, Date date)
			throws DAOException {
		try {
			LOGGER.info("addThrottlerAccountLiquidityAudit() called in ThrottlerAccountLiquidityAudit table");
			String sql = "Insert into T_GVP_THRTL_ACCT_LQDY_ADT (ACCT_NO,ACCT_BR_CD,ACCT_SRC_SYS_CD,THRTL_GRP_ID,BULK_ID,ACTL_BAL_EFF_TS,AVL_AM,VAL_DT,CRT_USR_ID,CRT_TS,PY_CR_CD) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
			return getJdbcTemplate().update(sql, accountNumber, accountBranchCode, accountSourceSysCode, groupId, X,
					currentTimestamp, availableAmt, date, USER_ID, currentTimestamp, X);
		} catch (DataAccessException e) {
			LOGGER.error(
					"Exception while calling addThrottlerAccountLiquidityAudit() in ThrottlerAccountLiquidityAudit "
							+ e.getMessage(),
					e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public int addGroupAccount(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, Number availableAmt, String displayFlag, Timestamp currentTimestamp,
			String dcsnCode, String fundingAgent) throws DAOException {
		try {
			LOGGER.info("addGroupAccount() called in ThrotllerGroupAccount table");
			String sql = "Insert into GVP_INTSRV_MGMT.T_GVP_THRTL_GRP_ACCT (THRTL_GRP_ID,ACCT_SRC_SYS_CD,ACCT_BR_CD,ACCT_NO,LQM_CRT_USR_ID,CRT_TS,UPD_USR_ID,UPD_TS,DSPL_FL,STAT_CD,CMNT_TX,SET_UP_USR_ID,SET_UP_TS,APRV_USR_ID,APRV_TS,APRV_DCSN_CD,IS_FUND_AGENT) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			return getJdbcTemplate().update(sql, groupId, accountSourceSysCode, accountBranchCode, accountNumber,
					USER_ID, currentTimestamp, USER_ID, currentTimestamp, displayFlag, null, CMNT_TX, USER_ID,
					currentTimestamp, USER_ID, currentTimestamp, dcsnCode, fundingAgent);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while calling addGroupAccount() in ThrotllerGroupAccount table " + e.getMessage(),
					e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public int configureThrottlerGroup(String groupId, String groupName, String currency, Timestamp currentTimestamp)
			throws DAOException {
		try {
			LOGGER.info("insertThrottlerGroup() called in Throtller Group table");
			String sql = "Insert into GVP_INTSRV_MGMT.T_GVP_THRTL_GRP (THRTL_GRP_ID,THRTL_GRP_NM,CCY_CD,CLR_CHNL_CD,TZ_CD,CRT_USR_ID,CRT_TS,UPD_USR_ID,UPD_TS) VALUES (?,?,?,?,?,?,?,?,?)";
			return getJdbcTemplate().update(sql, groupId, groupName, currency, TCH, null, USER_ID, currentTimestamp,
					USER_ID, currentTimestamp);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while calling configureThrottlerGroup() in ThrotllerGroup: " + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public List<ThrottlerGroupModelTable> getThrottlerGroups() throws DAOException {
		try {
			LOGGER.info("getThrottlerGroups() called in Throttler Group Table ");
			String sql = "Select THRTL_GRP_ID as throttlerGroupId, THRTL_GRP_NM as throttlerGroupName, CCY_CD as currencyCode, CLR_CHNL_CD as clearingChannelCode, TZ_CD as timezoneCode, CRT_USR_ID as currentUserId, TO_CHAR(CRT_TS,  'DD-MON-YYYY HH12:MI:SS AM') as currentTimestamp, UPD_USR_ID as updatedUserId, TO_CHAR(UPD_TS,  'DD-MON-YYYY HH12:MI:SS AM') as updatedTimestamp from GVP_INTSRV_MGMT.T_GVP_THRTL_GRP";
			return getJdbcTemplate().query(sql,
					new BeanPropertyRowMapper<ThrottlerGroupModelTable>(ThrottlerGroupModelTable.class));
		} catch (DataAccessException e) {
			LOGGER.error("Exception while  calling getThrottlerGroups() in Throttler Group Table" + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public List<ThrottlerHostProcTable> getCalculatorHosts() throws DAOException {
		try {
			LOGGER.info("getThrottlerHostProc() called in Throtller Host Proc Table ");
			String sql = "Select SEQ_NO as sequenceNumber, HOST_NM as hostName, PORT as port, APP_JVM as applicationJVM, ACCT_NO as accountNumber, THRTL_GRP_ID as throttlerGroupId, ACTV_FL as activeFlag, COM_NM as comments, CRT_USR_ID as currentUserId , TO_CHAR(CRT_TS,  'DD-MON-YYYY HH12:MI:SS AM') as currentTimestamp , UPD_USR_ID as updatedUserID , TO_CHAR(UPD_TS,  'DD-MON-YYYY HH12:MI:SS AM') as updatedTimestamp from GVP_INTSRV_MGMT.T_GVP_THRTL_HOST_PROC order by HOST_NM, SEQ_NO ASC";
			return getJdbcTemplate().query(sql,
					new BeanPropertyRowMapper<ThrottlerHostProcTable>(ThrottlerHostProcTable.class));
		} catch (DataAccessException e) {
			LOGGER.error("Exception while calling getThrottlerHostProc() in Throtller Host Proc Table" + e.getMessage(),
					e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public List<ThrottlerAccountLiquidityTable> getThrottlerAccounts() throws DAOException {
		try {
			LOGGER.info("getThrottlerAccounts() called in ThrottlerAccountLiquidityTable ");
			String sql = "Select ACCT_NO as accountNumber, ACCT_BR_CD as accountBranchCode, ACCT_SRC_SYS_CD as accountSourceSystemCode, THRTL_GRP_ID as throttlerGroupId, TO_CHAR(ACTL_BAL_EFF_TS,  'DD-MON-YYYY HH12:MI:SS AM') as actlBalanceEffectiveTimestamp, AVL_AM as availableAmount, BULK_ID as bulkId, VAL_DT as valDate, UPD_USR_ID as updatedUserId, TO_CHAR(UPD_TS,  'DD-MON-YYYY HH12:MI:SS AM') as updatedTimestamp from GVP_INTSRV_MGMT.T_GVP_THRTL_ACCT_LQDY";
			return getJdbcTemplate().query(sql,
					new BeanPropertyRowMapper<ThrottlerAccountLiquidityTable>(ThrottlerAccountLiquidityTable.class));
		} catch (DataAccessException e) {
			LOGGER.error("Exception while  calling getThrottlerAccounts() in ThrottlerAccountLiquidityTable"
					+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public List<ThrottlerConfigTable> getHazelcastConfig() throws DAOException {
		try {
			LOGGER.info("getHazelcastConfig() called in ThrottlerConfigTable ");
			String sql = "Select SEQ_NO as sequenceNumber, FUN_NM as functionName, KEY_NM as keyName, VAL_NM as valueName, DESC_TX as descTx, ACTV_FL as activeFlag, CRT_USR_ID as createUserId, TO_CHAR(CRT_TS,  'DD-MON-YYYY HH12:MI:SS AM') as createTimestamp, UPD_USR_ID as updatedUserId, TO_CHAR(UPD_TS,  'DD-MON-YYYY HH12:MI:SS AM') as updatedTimestamp from GVP_INTSRV_MGMT.T_GVP_THRTL_CONFIG WHERE FUN_NM = 'HZL_CONFIG' ORDER BY SEQ_NO ASC";
			return getJdbcTemplate().query(sql,
					new BeanPropertyRowMapper<ThrottlerConfigTable>(ThrottlerConfigTable.class));
		} catch (DataAccessException e) {
			LOGGER.error("Exception while  calling getHazelcastConfig() in ThrottlerConfigTable" + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public List<ThrottlerConfigTable> getSchedulerHosts() throws DAOException {
		try {
			LOGGER.info("getSchedulerHosts() called in ThrottlerConfigTable ");
			String sql = "Select SEQ_NO as sequenceNumber, FUN_NM as functionName, KEY_NM as keyName, VAL_NM as valueName, DESC_TX as descTx, ACTV_FL as activeFlag, CRT_USR_ID as createUserId, TO_CHAR(CRT_TS,  'DD-MON-YYYY HH12:MI:SS AM') as createTimestamp, UPD_USR_ID as updatedUserId, TO_CHAR(UPD_TS,  'DD-MON-YYYY HH12:MI:SS AM') as updatedTimestamp from GVP_INTSRV_MGMT.T_GVP_THRTL_CONFIG WHERE FUN_NM = 'SCH_HOSTNM' ORDER BY SEQ_NO ASC";
			return getJdbcTemplate().query(sql,
					new BeanPropertyRowMapper<ThrottlerConfigTable>(ThrottlerConfigTable.class));
		} catch (DataAccessException e) {
			LOGGER.error("Exception while  calling getSchedulerHosts() in ThrottlerConfigTable" + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
	
	@Override
	public int configureThrottlerAccntDispFlag(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, String displayFlag, Timestamp currentTimestamp)
			throws DAOException {
		try {
			LOGGER.info("configureThrottlerAccntDispFlag() called in Throtller Group Account table ");
			String sql = "UPDATE T_GVP_THRTL_GRP_ACCT SET DSPL_FL = ? , UPD_TS = ? WHERE THRTL_GRP_ID = ? AND ACCT_SRC_SYS_CD = ? AND ACCT_BR_CD = ? AND ACCT_NO = ? ";
			return getJdbcTemplate().update(sql, displayFlag, currentTimestamp, groupId, accountSourceSysCode, accountBranchCode, accountNumber);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while  calling configureThrottlerAccntDispFlag() in Throtller Group Account table:"
					+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
	
	@Override
	public int configureThrottlerAccntFundingAgentFlag(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, String isFundAgent, Timestamp currentTimestamp)
			throws DAOException {
		try {
			LOGGER.info("configureThrottlerAccntFundingAgentFlag() called in Throtller Group Account table ");
			String sql = "UPDATE T_GVP_THRTL_GRP_ACCT SET IS_FUND_AGENT = ? , UPD_TS = ? WHERE THRTL_GRP_ID = ? AND ACCT_SRC_SYS_CD = ? AND ACCT_BR_CD = ? AND ACCT_NO = ? ";
			return getJdbcTemplate().update(sql, isFundAgent, currentTimestamp, groupId, accountSourceSysCode, accountBranchCode, accountNumber);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while  calling configureThrottlerAccntFundingAgentFlag() in Throtller Group Account table:"
					+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

}
