package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;

public class DomainUrl implements Serializable, Cloneable {

	private static final long serialVersionUID = -3915270338389167965L;

	private String region;
	private String applicationCode;
	private String applicationDomainUrl;

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getApplicationCode() {
		return applicationCode;
	}

	public void setApplicationCode(String applicationCode) {
		this.applicationCode = applicationCode;
	}

	public String getApplicationDomainUrl() {
		return applicationDomainUrl;
	}

	public void setApplicationDomainUrl(String applicationDomainUrl) {
		this.applicationDomainUrl = applicationDomainUrl;
	}

	public void setToDefaultValue() {
		this.setApplicationCode("");
		this.setApplicationDomainUrl("");
		this.setRegion("");
	}
	
	 public Object clone() throws CloneNotSupportedException {
	        return super.clone();
	 }

	@Override
	public String toString() {
		return "DomainUrlResponse [region=" + region + ", applicationCode=" + applicationCode
				+ ", applicationDomainUrl=" + applicationDomainUrl + "]";
	}
}