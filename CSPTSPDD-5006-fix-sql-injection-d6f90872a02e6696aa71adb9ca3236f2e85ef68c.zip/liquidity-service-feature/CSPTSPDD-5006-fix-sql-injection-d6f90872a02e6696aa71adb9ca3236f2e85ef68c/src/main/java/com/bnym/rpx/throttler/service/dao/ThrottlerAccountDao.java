package com.bnym.rpx.throttler.service.dao;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.ThrottlerAccountLiquidityTable;
import com.bnym.rpx.throttler.service.model.ThrottlerConfigTable;
import com.bnym.rpx.throttler.service.model.ThrottlerGroupModelTable;
import com.bnym.rpx.throttler.service.model.ThrottlerHostProcTable;

public interface ThrottlerAccountDao {

	public int addThrottlerAccountLiquidity(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, Number availableAmt, Timestamp currentTimestamp, Date date)
			throws DAOException;

	public int addThrottlerAccountLiquidityAudit(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, Number availableAmt, Timestamp currentTimestamp, Date date)
			throws DAOException;

	public int addGroupAccount(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, Number availableAmt, String displayFlag, Timestamp currentTimestamp,
			String dcsnCode, String fundingAgent) throws DAOException;

	public int configureThrottlerGroup(String groupId, String groupName, String currency, Timestamp currentTimestamp)
			throws DAOException;

	public List<ThrottlerGroupModelTable> getThrottlerGroups() throws DAOException;

	public List<ThrottlerHostProcTable> getCalculatorHosts() throws DAOException;

	public List<ThrottlerAccountLiquidityTable> getThrottlerAccounts() throws DAOException;

	public List<ThrottlerConfigTable> getHazelcastConfig() throws DAOException;

	public List<ThrottlerConfigTable> getSchedulerHosts() throws DAOException;
	
	public int configureThrottlerAccntDispFlag(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, String displayFlag, Timestamp currentTimestamp)
			throws DAOException;
	
	public int configureThrottlerAccntFundingAgentFlag(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, String isFundAgent, Timestamp currentTimestamp)
			throws DAOException;
}
