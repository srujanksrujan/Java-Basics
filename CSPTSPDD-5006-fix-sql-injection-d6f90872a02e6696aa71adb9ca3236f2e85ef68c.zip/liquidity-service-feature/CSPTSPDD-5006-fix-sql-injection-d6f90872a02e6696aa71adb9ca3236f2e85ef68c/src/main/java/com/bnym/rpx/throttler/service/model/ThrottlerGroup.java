package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.util.List;

public class ThrottlerGroup implements Serializable, Cloneable {

	private static final long serialVersionUID = -3915270338389167965L;
	
	String throttlerGroupId;
	String throttlerGroupName;
	
	private List<AccountBalanceDetails> accountBalance;
	

	public List<AccountBalanceDetails> getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(List<AccountBalanceDetails> accountBalance) {
		this.accountBalance = accountBalance;
	}

	public String getThrottlerGroupId() {
		return throttlerGroupId;
	}

	public void setThrottlerGroupId(String throttlerGroupId) {
		this.throttlerGroupId = throttlerGroupId;
	}

	public String getThrottlerGroupName() {
		return throttlerGroupName;
	}

	public void setThrottlerGroupName(String throttlerGroupName) {
		this.throttlerGroupName = throttlerGroupName;
	}

	 public Object clone() throws CloneNotSupportedException {
	        return super.clone();
	 }

	@Override
	public String toString() {
		return "ThrottlerGroup [throttlerGroupId=" + throttlerGroupId + ", throttlerGroupName=" + throttlerGroupName
				+ ", accountBalance=" + accountBalance + "]";
	}
}
