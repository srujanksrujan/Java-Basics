/**
 * File: GroupAccountDAOImpl.java
 * Description:
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").
 * 
 * @author  Swati Rashmi
 * @Since: Dec 20, 2016
 * @Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.dao.impl;

import org.apache.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.stereotype.Repository;

import com.bnym.rpx.throttler.service.dao.GroupAccountDAO;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.GroupAccount;

@Repository
public class GroupAccountDAOImpl extends GenericDAO implements GroupAccountDAO {

	private static final Logger LOGGER = Logger.getLogger(GroupAccountDAOImpl.class);

	@Override
	public GroupAccount getGrpAcctInfo(String accountNo) throws DAOException {
		try {
			LOGGER.info("GroupAccountDAOImpl() called *************** ");
			String sql = "SELECT THRTL_GRP_ID,ACCT_BR_CD,ACCT_SRC_SYS_CD FROM t_gvp_thrtl_grp_acct WHERE ACCT_NO = ?" ;
			GroupAccount grpAccount= getJdbcTemplate().queryForObject(sql, new Object[] {accountNo}, new BeanPropertyRowMapper<GroupAccount>(GroupAccount.class));
			LOGGER.info("GroupAccountDAOImpl() called  in GroupAccountDAOImpl returning GroupAccount:" + grpAccount);
			return grpAccount;		

		} catch (EmptyResultDataAccessException e){
			return new GroupAccount();
		} catch(Exception e){
			LOGGER.error("Exception whlie calling getGrpAcctInfo() for accountNo:"+ accountNo +" in GroupAccountDAOImpl :"+ e.getMessage(), e);
			throw new DAOException("Exception:" + e.getMessage(), e);
		}
	}
}