package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class AnalyticAccountBalance implements Serializable, Cloneable {

	private static final long serialVersionUID = 1L;
	
	private String acctNo;
	private String openingTime;
	private BigDecimal openingBalance;
	private String closingTime;
	private BigDecimal closingBalance;
	
	public String getAcctNo() {
		return acctNo;
	}
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	public String getOpeningTime() {
		return openingTime;
	}
	public void setOpeningTime(String openingTime) {
		this.openingTime = openingTime;
	}
	public BigDecimal getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(BigDecimal openingBalance) {
		this.openingBalance = openingBalance;
	}
	public String getClosingTime() {
		return closingTime;
	}
	public void setClosingTime(String closingTime) {
		this.closingTime = closingTime;
	}
	public BigDecimal getClosingBalance() {
		return closingBalance;
	}
	public void setClosingBalance(BigDecimal closingBalance) {
		this.closingBalance = closingBalance;
	}
	
	public void setToDefaultValue(){
		this.setAcctNo("");
		this.setClosingBalance(BigDecimal.ZERO);
		this.setClosingTime("");
		this.setOpeningBalance(BigDecimal.ZERO);
		this.setOpeningTime("");
	}
	
	@Override
	public String toString() {
		return "AnalyticAccountBalance [acctNo=" + acctNo + ", openingTime=" + openingTime + ", openingBalance=" + openingBalance + ", closingTime="
				+ closingTime + ", closingBalance=" + closingBalance + "]";
	}
	
	 public Object clone() throws CloneNotSupportedException {
	        return super.clone();
	 }
}