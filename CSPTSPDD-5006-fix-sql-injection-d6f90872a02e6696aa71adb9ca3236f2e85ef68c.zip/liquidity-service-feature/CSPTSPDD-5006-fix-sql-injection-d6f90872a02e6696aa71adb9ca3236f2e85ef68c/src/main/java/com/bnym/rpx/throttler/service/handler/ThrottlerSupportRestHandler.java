package com.bnym.rpx.throttler.service.handler;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnym.rpx.throttler.service.dao.impl.ThrottlerAccountDaoImpl;
import com.bnym.rpx.throttler.service.dao.impl.ThrottlerSupportRestDaoImpl;
import com.bnym.rpx.throttler.service.enums.ActiveFlagStatus;
import com.bnym.rpx.throttler.service.enums.DecisionCode;
import com.bnym.rpx.throttler.service.enums.DisplayFlag;
import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.ResponseMetadata;
import com.bnym.rpx.throttler.service.model.Result;
import com.bnym.rpx.throttler.service.model.ThrottlerAccountLiquidityTable;
import com.bnym.rpx.throttler.service.model.ThrottlerConfigTable;
import com.bnym.rpx.throttler.service.model.ThrottlerGroupModelTable;
import com.bnym.rpx.throttler.service.model.ThrottlerHostProcTable;
import com.bnym.rpx.throttler.service.util.PaymentEnricher;

@Service
public class ThrottlerSupportRestHandler {

	private static final Logger LOGGER = Logger.getLogger(ThrottlerSupportRestHandler.class);
	private static final String EXCEPTION = "Exception :";
	@Autowired
	private PaymentEnricher enricher;
	@Autowired
	private ThrottlerSupportRestDaoImpl throttlerSupportRestDaoImpl;
	@Autowired
	private ThrottlerAccountDaoImpl throttlerAccountDaoImpl;

	public APIResponse configureCalculatorHost(String hostName, String accountNumber, String throttlerGroupId,
			String activeFlag) throws ApplicationException {
		Integer count;
		APIResponse apiResponse = new APIResponse();
		try {
			ActiveFlagStatus activeFlagStatusEnum = ActiveFlagStatus.value(activeFlag);
			count = throttlerSupportRestDaoImpl.configureCalculatorHost(hostName, accountNumber, throttlerGroupId,
					activeFlagStatusEnum.getCode(), enricher.getSystemTimestamp());

			if (count != null && count > 0) {
				List<String> responseList = new ArrayList<>();
				responseList.add("Data Inserted Succesfully into Throttler Host Proc!!");
				apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
				ResponseMetadata responseMetadata = new ResponseMetadata(200, "Data Inserted Sucessfully!!");
				apiResponse.setMetadata(responseMetadata);
			} else {
				apiResponse.setResult(null);
				ResponseMetadata responseMetadata = new ResponseMetadata(200,
						"No record Inserted into into Throttler Host Proc!!");
				apiResponse.setMetadata(responseMetadata);
			}
		} catch (DAOException ex) {
			LOGGER.info("Exception while calling  insertCalculatorHost() : " + ex.getMessage());
			throw new ApplicationException(EXCEPTION + ex.getMessage(), ex);
		}
		return apiResponse;
	}

	public APIResponse configCalcHostFlag(String hostName, String accountNumber, String throttlerGroupId,
			String activeFlag) throws ApplicationException {
		Integer count;
		APIResponse apiResponse = new APIResponse();
		try {
			ActiveFlagStatus activeFlagStatusEnum = ActiveFlagStatus.value(activeFlag);
			count = throttlerSupportRestDaoImpl.configCalcHostFlag(hostName, accountNumber, throttlerGroupId,
					activeFlagStatusEnum.getCode(), enricher.getSystemTimestamp());
			if (count != null && count > 0) {
				List<String> responseList = new ArrayList<>();
				responseList.add("Data updated Succesfully into Throttler Host Proc!!");
				apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
				ResponseMetadata responseMetadata = new ResponseMetadata(200,
						"Data updated Sucessfully into Throttler Host Proc!!");
				apiResponse.setMetadata(responseMetadata);
			} else {
				apiResponse.setResult(null);
				ResponseMetadata responseMetadata = new ResponseMetadata(200,
						"No record updated into Throttler Host Proc !!");
				apiResponse.setMetadata(responseMetadata);
			}
		} catch (DAOException ex) {
			LOGGER.info("Exception while calling  configCalcHostFlag()  : " + ex.getMessage());
			throw new ApplicationException(EXCEPTION + ex.getMessage(), ex);
		}
		return apiResponse;
	}

	public APIResponse configureSchedulerHost(String hostName, String activeFlag, String comments)
			throws ApplicationException {
		Integer count;
		APIResponse apiResponse = new APIResponse();
		try {
			ActiveFlagStatus activeFlagStatusEnum = ActiveFlagStatus.value(activeFlag);
			count = throttlerSupportRestDaoImpl.configureSchedulerHost(hostName, activeFlagStatusEnum.getCode(), comments,
					enricher.getSystemTimestamp());
			if (count != null && count > 0) {
				List<String> responseList = new ArrayList<>();
				responseList.add("Data Inserted Succesfully into Throttler Configuration table!!");
				apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
				ResponseMetadata responseMetadata = new ResponseMetadata(200, "Data Inserted Sucessfully!!");
				apiResponse.setMetadata(responseMetadata);
			} else {
				apiResponse.setResult(null);
				ResponseMetadata responseMetadata = new ResponseMetadata(200,
						"No record Inserted into Throttler Configuration table !!");
				apiResponse.setMetadata(responseMetadata);
			}
		} catch (DAOException ex) {
			LOGGER.info("Exception while calling configureSchedulerHost() : " + ex.getMessage());
			throw new ApplicationException(EXCEPTION + ex.getMessage(), ex);
		}
		return apiResponse;
	}

	public APIResponse configureSchedulerHostFlag(String hostName, String activeFlag) throws ApplicationException {
		Integer count;
		APIResponse apiResponse = new APIResponse();
		try {
			ActiveFlagStatus activeFlagStatusEnum = ActiveFlagStatus.value(activeFlag);
			count = throttlerSupportRestDaoImpl.configureSchedulerHostFlag(hostName, activeFlagStatusEnum.getCode(),
					enricher.getSystemTimestamp());
			if (count != null && count > 0) {
				List<String> responseList = new ArrayList<>();
				responseList.add("Data updated Succesfully into Throttler Configuation Table");
				apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
				ResponseMetadata responseMetadata = new ResponseMetadata(200,
						"Data updated Succesfully into Throttler Configuation Table");
				apiResponse.setMetadata(responseMetadata);
			} else {
				apiResponse.setResult(null);
				ResponseMetadata responseMetadata = new ResponseMetadata(200,
						"No record Updated into Throttler Configuation Table !!");
				apiResponse.setMetadata(responseMetadata);
			}
		} catch (Exception ex) {
			LOGGER.info("Exception while calling configureSchedulerHostFlag() : " + ex.getMessage());
			throw new ApplicationException(EXCEPTION + ex.getMessage(), ex);
		}
		return apiResponse;
	}
 

	public Date currentDate() {
		/*
		 * SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		 * Date date = new Date();
		 */
		java.util.Date date = new java.util.Date();
		// date.getDate();
		// SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
		return date;
	}

	public APIResponse configureThrottlerAccount(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, Number availableAmt, String activeFlag, String dcsnCode, String isFundAgent)
			throws ApplicationException {
		Integer count;
		APIResponse apiResponse = new APIResponse();
		try {
			ActiveFlagStatus activeFlagStatusEnum = ActiveFlagStatus.value(activeFlag);
			// DisplayFlag activeFlagStatusEnum = DisplayFlag.value(activeFlag);
			DecisionCode decisionCodeEnum = DecisionCode.value(dcsnCode);
			// DisplayFlag fundingAgent = DisplayFlag.value(isFundAgent);
			count = throttlerAccountDaoImpl.addThrottlerAccountLiquidity(groupId, accountNumber, accountBranchCode,
					accountSourceSysCode, availableAmt, enricher.getSystemTimestamp(), currentDate());

			count = throttlerAccountDaoImpl.addThrottlerAccountLiquidityAudit(groupId, accountNumber, accountBranchCode,
					accountSourceSysCode, availableAmt, enricher.getSystemTimestamp(), currentDate());

			count = throttlerAccountDaoImpl.addGroupAccount(groupId, accountNumber, accountBranchCode,
					accountSourceSysCode, availableAmt, activeFlagStatusEnum.getCode(), enricher.getSystemTimestamp(),
					decisionCodeEnum.getCode(), activeFlagStatusEnum.getCode());

			if (count != null && count > 0) {
				List<String> responseList = new ArrayList<>();
				responseList.add("Data Inserted Succesfully");
				apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
				ResponseMetadata responseMetadata = new ResponseMetadata(200, "Data Inserted Sucessfully!!");
				apiResponse.setMetadata(responseMetadata);
			} else {
				apiResponse.setResult(null);
				ResponseMetadata responseMetadata = new ResponseMetadata(200, "No record Inserted");
				apiResponse.setMetadata(responseMetadata);
			}
		} catch (DAOException ex) {
			LOGGER.info("Exception while calling  configureThrottlerAccount() : " + ex.getMessage());
			throw new ApplicationException(EXCEPTION + ex.getMessage(), ex);
		}
		return apiResponse;
	}

	public APIResponse configureThrottlerGroup(String groupId, String groupName, String currency)
			throws ApplicationException {
		Integer count;
		APIResponse apiResponse = new APIResponse();
		try {
			count = throttlerAccountDaoImpl.configureThrottlerGroup(groupId, groupName, currency,
					enricher.getSystemTimestamp());

			if (count != null && count > 0) {
				List<String> responseList = new ArrayList<>();
				responseList.add("Data Inserted Succesfully");
				apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
				ResponseMetadata responseMetadata = new ResponseMetadata(200, "Data Inserted Sucessfully!!");
				apiResponse.setMetadata(responseMetadata);
			} else {
				apiResponse.setResult(null);
				ResponseMetadata responseMetadata = new ResponseMetadata(200, "No record Inserted");
				apiResponse.setMetadata(responseMetadata);
			}
		} catch (DAOException ex) {
			LOGGER.info("Exception while calling  configureThrottlerGroup() : " + ex.getMessage());
			throw new ApplicationException(EXCEPTION + ex.getMessage(), ex);
		}
		return apiResponse;
	}

	public APIResponse getThrottlerGroups() throws ApplicationException {
		APIResponse apiResponse = new APIResponse();
		try {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("getThrottlerGroups() called in ThrottlerSupportRestHandler");
			}
			List<ThrottlerGroupModelTable> responseList = throttlerAccountDaoImpl.getThrottlerGroups();
			apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
			return apiResponse;
		} catch (DAOException e) {
			throw new ApplicationException(e);
		}
	}

	public APIResponse getCalculatorHosts() throws ApplicationException {
		APIResponse apiResponse = new APIResponse();
		try {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("getThrottlerHostProc() called in ThrottlerhostProcTable");
			}
			List<ThrottlerHostProcTable> responseList = throttlerAccountDaoImpl.getCalculatorHosts();
			apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
			return apiResponse;
		} catch (DAOException e) {
			throw new ApplicationException(e);
		}
	}
	
	public APIResponse getThrottlerAccounts() throws ApplicationException {
		APIResponse apiResponse = new APIResponse();
		try {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("getThrottlerAccounts() called in ThrottlerAccountLiquidityTable");
			}
			List<ThrottlerAccountLiquidityTable> responseList = throttlerAccountDaoImpl.getThrottlerAccounts();
			apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
			return apiResponse;
		} catch (DAOException e) {
			throw new ApplicationException(e);
		}
	}
 
	
	public APIResponse getSchedulerHosts() throws ApplicationException {
		APIResponse apiResponse = new APIResponse();
		try {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("getThrottlerGroup() called in ThrottlerConfigTable");
			}
			List<ThrottlerConfigTable> responseList = throttlerAccountDaoImpl.getSchedulerHosts();
			apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
			return apiResponse;
		} catch (DAOException e) {
			throw new ApplicationException(e);
		}
	}

	public APIResponse configureThrottlerAccntDispFlag(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, String displayFlag) throws ApplicationException {
		Integer count;
		APIResponse apiResponse = new APIResponse();
		try {
			ActiveFlagStatus dispFlagEnum = ActiveFlagStatus.value(displayFlag);
			count = throttlerAccountDaoImpl.configureThrottlerAccntDispFlag(groupId, accountNumber, accountBranchCode,
					accountSourceSysCode,dispFlagEnum.getCode(), enricher.getSystemTimestamp());

			if (count != null && count > 0) {
				List<String> responseList = new ArrayList<>();
				responseList.add("Display Flag updated Succesfully into Throttler Group Account Table");
				apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
				ResponseMetadata responseMetadata = new ResponseMetadata(200,
						"Display Flag updated Succesfully into Throttler Group Account Table");
				apiResponse.setMetadata(responseMetadata);
			} else {
				apiResponse.setResult(null);
				ResponseMetadata responseMetadata = new ResponseMetadata(200,
						"No Display Flag Updated into Throttler Group Account Table !!");
				apiResponse.setMetadata(responseMetadata);
			}
		} catch (DAOException ex) {
			LOGGER.info("Exception while calling configureThrottlerAccntDispFlag() : " + ex.getMessage());
			throw new ApplicationException(EXCEPTION + ex.getMessage(), ex);
		}
		return apiResponse;
	}
	
	public APIResponse configureThrottlerAccntFundingAgentFlag(String groupId, String accountNumber, String accountBranchCode,
			String accountSourceSysCode, String isFundAgent) throws ApplicationException {
		Integer count;
		APIResponse apiResponse = new APIResponse();
		try {
			ActiveFlagStatus fundAgentEnum = ActiveFlagStatus.value(isFundAgent);
			count = throttlerAccountDaoImpl.configureThrottlerAccntFundingAgentFlag(groupId, accountNumber, accountBranchCode,
					accountSourceSysCode,fundAgentEnum.getCode(), enricher.getSystemTimestamp());

			if (count != null && count > 0) {
				List<String> responseList = new ArrayList<>();
				responseList.add("Fund Agent Flag updated Succesfully into Throttler Group Account Table");
				apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
				ResponseMetadata responseMetadata = new ResponseMetadata(200,
						"Fund Agent Flag updated Succesfully into Throttler Group Account Table");
				apiResponse.setMetadata(responseMetadata);
			} else {
				apiResponse.setResult(null);
				ResponseMetadata responseMetadata = new ResponseMetadata(200,
						"No Fund Agent Flag Updated into Throttler Group Account Table !!");
				apiResponse.setMetadata(responseMetadata);
			}
		} catch (DAOException ex) {
			LOGGER.info("Exception while calling configureThrottlerAccntFundingAgentFlag() : " + ex.getMessage());
			throw new ApplicationException(EXCEPTION + ex.getMessage(), ex);
		}
		return apiResponse;
	}

}