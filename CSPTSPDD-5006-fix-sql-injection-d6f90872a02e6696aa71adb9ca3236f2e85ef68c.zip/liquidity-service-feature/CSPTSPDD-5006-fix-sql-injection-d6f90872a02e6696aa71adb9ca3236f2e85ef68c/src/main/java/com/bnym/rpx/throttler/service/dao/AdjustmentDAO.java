/**
 * 
 */
package com.bnym.rpx.throttler.service.dao;

import java.sql.Timestamp;

import com.bnym.rpx.throttler.service.entity.Adjustment;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.AdjustmentInputRequest;
import com.bnym.rpx.throttler.service.model.Page;

/**
 * @author adcb3hn
 *
 */
public interface AdjustmentDAO {

	Adjustment getAdjustmentById(String adjustmentId) throws  DAOException;

	int insertAdjustment(Adjustment adjustment) throws DAOException;	

	int updateAdjustment(Adjustment adjustment)throws DAOException;

	String getAdjustmentId()throws DAOException;

	Timestamp getSystemTimestamp()throws DAOException;


}
