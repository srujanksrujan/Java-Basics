package com.bnym.rpx.throttler.service.builder;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnym.rpx.throttler.service.dao.impl.ThrottlerGroupAccountBalanceDAOImpl;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.AccountBalance;
import com.bnym.rpx.throttler.service.model.AccountBalanceDetails;
import com.bnym.rpx.throttler.service.model.ThrottlerGroup;
import com.bnym.rpx.throttler.service.model.ThrottlerGroupBalanceResponse;
import com.bnym.rpx.throttler.service.util.DateUtil;

@Component
public class ThrottlerGroupBalanceBuilder {

	private static final Logger LOGGER = Logger.getLogger(ThrottlerGroupBalanceBuilder.class);

	
	private ThrottlerGroupAccountBalanceDAOImpl throttlerGroupAccountBalanceDAOImpl;
	
	public ThrottlerGroupAccountBalanceDAOImpl getThrottlerGroupAccountBalanceDAOImpl() {
		return throttlerGroupAccountBalanceDAOImpl;
	}

	@Autowired
	public void setThrottlerGroupAccountBalanceDAOImpl(
			ThrottlerGroupAccountBalanceDAOImpl throttlerGroupAccountBalanceDAOImpl) {
		this.throttlerGroupAccountBalanceDAOImpl = throttlerGroupAccountBalanceDAOImpl;
	}

	public ThrottlerGroupBalanceResponse getAnalyticsAccountLiquidity(String valueDate) throws DAOException {
		List<ThrottlerGroup> throttlerGroupList = new ArrayList<>();
		ThrottlerGroupBalanceResponse throttlerGroupBalanceResponse = new ThrottlerGroupBalanceResponse();
		try {
			List<Map<String, Object>> resultList = throttlerGroupAccountBalanceDAOImpl.getAnalyticsAccountLiquidity(valueDate);
			if (resultList != null && !resultList.isEmpty()) {
				List<AccountBalance> accountBalanceList = new ArrayList<>();
				AccountBalance accountBalanceObj = new AccountBalance();
				AccountBalance defaultAccountBalanceObj = new AccountBalance();
				for (Map<String, Object> row : resultList) {
					accountBalanceObj = (AccountBalance) defaultAccountBalanceObj.clone();
					accountBalanceObj.setThrottlerGroupId((String) row.get("thrtl_grp_id"));
					accountBalanceObj.setThrottlerGroupName((String) row.get("thrtl_grp_name"));
					accountBalanceObj.setAccountNumber((String) row.get("acct_no"));
					accountBalanceObj.setCashIn((BigDecimal) row.get("cash_credit"));
					accountBalanceObj.setAdjIn((BigDecimal) row.get("misc_adj_in"));
					accountBalanceObj.setTotalsIn((BigDecimal) row.get("total_credit_adj_in"));
					accountBalanceObj.setCashOut((BigDecimal) row.get("cash_payment"));
					accountBalanceObj.setAdjOut((BigDecimal) row.get("misc_adj_out"));
					accountBalanceObj.setTotalsOut((BigDecimal) row.get("total_payment_adj_out"));
					accountBalanceObj.setAvailableAmount((BigDecimal) row.get("available_amount"));
					accountBalanceObj.setCurrencyCode((String) row.get("currency_code"));
					accountBalanceObj.setUpdatedTime((Timestamp) row.get("update_timestamp"));
					accountBalanceObj.setPendingPaymentCount((BigDecimal) row.get("pending_pymnt_count"));
					accountBalanceObj.setPendingCreditCount((BigDecimal) row.get("pending_crdt_count"));
					accountBalanceObj.setIsFundingAgentFlag((String) row.get("is_fund_agent"));
					accountBalanceList.add(accountBalanceObj);
				}

				Map<String, List<AccountBalance>> throttlerGroupAccountBalanceMap = new HashMap<>();

				updateThrottlerGroupAccountBalanceMap(accountBalanceList, throttlerGroupAccountBalanceMap);
				ThrottlerGroup throttlerGroupObj = new ThrottlerGroup();
				ThrottlerGroup defaultThrottlerGroupObj = new ThrottlerGroup();
				
				ArrayList<AccountBalanceDetails> accountBalanceDetailsList = new ArrayList<>();
				ArrayList<AccountBalanceDetails> defaultAccountBalanceDetailsList = new ArrayList<>();
				for (Map.Entry<String, List<AccountBalance>> entry : throttlerGroupAccountBalanceMap
						.entrySet()) {
					if (entry.getKey() != null && entry.getValue() != null) {
					    throttlerGroupObj = (ThrottlerGroup) defaultThrottlerGroupObj.clone();
						throttlerGroupObj.setThrottlerGroupId(entry.getKey());
						accountBalanceDetailsList = (ArrayList<AccountBalanceDetails>) defaultAccountBalanceDetailsList.clone();
					    for (AccountBalance accountBalance :entry.getValue()){
					    	if(accountBalance!=null){
					    		throttlerGroupObj.setThrottlerGroupName(accountBalance.getThrottlerGroupName());
						    	
					    		AccountBalanceDetails accountBalanceDetails = newAccountBalanceDetails();
					    		accountBalanceDetails.setAccountNumber(accountBalance.getAccountNumber()==null ? "" : accountBalance.getAccountNumber());
					    		accountBalanceDetails.setCashIn(accountBalance.getCashIn()==null ? "" : accountBalance.getCashIn().toString());
					    		accountBalanceDetails.setAdjIn(accountBalance.getAdjIn()==null ? "" : accountBalance.getAdjIn().toString());
					    		accountBalanceDetails.setTotalsIn(accountBalance.getTotalsIn()==null ? "" : accountBalance.getTotalsIn().toString());
					    		accountBalanceDetails.setCashOut(accountBalance.getCashOut()==null ? "" : accountBalance.getCashOut().toString());
					    		accountBalanceDetails.setAdjOut(accountBalance.getAdjOut()==null ? "" : accountBalance.getAdjOut().toString());
					    		accountBalanceDetails.setTotalsOut(accountBalance.getTotalsOut()==null ? "" : accountBalance.getTotalsOut().toString());
					    		accountBalanceDetails.setAvailableAmount(accountBalance.getAvailableAmount()==null ? "" : accountBalance.getAvailableAmount().toString());
					    		accountBalanceDetails.setCurrencyCode(accountBalance.getCurrencyCode()==null ? "" : accountBalance.getCurrencyCode());
					    		accountBalanceDetails.setUpdatedTime(accountBalance.getUpdatedTime()== null ? "" : DateUtil.getFormattedDate(accountBalance.getUpdatedTime()));
					    		accountBalanceDetails.setPendingPaymentCount(accountBalance.getPendingPaymentCount()==null ? "" : accountBalance.getPendingPaymentCount().toString());
					    		accountBalanceDetails.setPendingCreditCount(accountBalance.getPendingCreditCount()==null ? "" : accountBalance.getPendingCreditCount().toString());
					    		accountBalanceDetails.setIsFundingAgentFlag(accountBalance.getIsFundingAgentFlag() == null ? "" : accountBalance.getIsFundingAgentFlag());
					    		accountBalanceDetailsList.add(accountBalanceDetails);
					    	}
					    }
						throttlerGroupObj.setAccountBalance(accountBalanceDetailsList);
						throttlerGroupList.add(throttlerGroupObj);
					}
				}
			}

			throttlerGroupBalanceResponse.setThrottlerGroups(throttlerGroupList);
		} catch (Exception ex) {
			throw new DAOException(ex);
		}
		return throttlerGroupBalanceResponse;
	}
	
	private static AccountBalanceDetails newAccountBalanceDetails(){
		return new AccountBalanceDetails();
	}
	
	private void updateThrottlerGroupAccountBalanceMap(List<AccountBalance> accountBalanceList,
			Map<String, List<AccountBalance>> throttlerGroupAccountBalanceMap) {
		
		ArrayList<AccountBalance> accountBalListCloneOne = new ArrayList<>();
		ArrayList<AccountBalance> accountBalListCloneTwo = new ArrayList<>();
		
		for (AccountBalance accountBalanceObj : accountBalanceList) {
			if (accountBalanceObj != null) {
				String thottlerGroupId = accountBalanceObj.getThrottlerGroupId();
				if (throttlerGroupAccountBalanceMap.containsKey(thottlerGroupId)) {
					List<AccountBalance> accountBalList = throttlerGroupAccountBalanceMap.get(thottlerGroupId);
					accountBalList.add(accountBalanceObj);
					throttlerGroupAccountBalanceMap.put(thottlerGroupId, accountBalList);
				} else {
					accountBalListCloneTwo = (ArrayList<AccountBalance>) accountBalListCloneOne.clone();
					accountBalListCloneTwo.add(accountBalanceObj);
					throttlerGroupAccountBalanceMap.put(thottlerGroupId, accountBalListCloneTwo);
				}
			}
		}
	}
}
