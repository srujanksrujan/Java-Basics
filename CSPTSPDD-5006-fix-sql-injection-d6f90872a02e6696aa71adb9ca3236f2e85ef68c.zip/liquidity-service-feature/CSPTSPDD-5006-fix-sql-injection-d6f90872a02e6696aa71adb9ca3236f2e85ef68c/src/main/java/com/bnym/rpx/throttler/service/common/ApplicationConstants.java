/**
 * File: ApplicationConstants.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 4, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.common;

public final class ApplicationConstants {

	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
	public static final String ADJ_USER_ID= "THRTL-AD";
	public static final String REQ_TYPE_CODE = "Adjustment";

	//API Response status 
	public enum ResponseStatus {
		SUCCESS ("SUCCESS"), 
		FAILURE ("FAILURE");

		private String status;
		ResponseStatus (String status) {
			this.status = status;
		}

		public String getStatus () {
			return this.status;
		}
	}
	
	
	//Adjustment Decision Codes 
	public enum AdjustmentDecisionCodes {
		PENDING_APPROVAL("P"), 
		APPROVED("A"),
		REJECTED("R");

		private String code;
		AdjustmentDecisionCodes(String code) {
			this.code = code;
		}

		public String getCode () {
			return this.code;
		}
	}

	public enum AdjInOutCd {
		IN ("I"),
		OUT ("O");

		private String code;

		private AdjInOutCd(String code) {
			this.code = code;
		}

		public String getCode() {
			return code;
		}


	}

	public enum ProcessStatus {
		NOTIFY ("NOTIFY"),
		WAIT ("WAIT"),
		RELEASED("RELD"),
		CANCELLED("CAN"),
		DUPLICATE ("DUP"),
		ARELD("ARELD"),
		EXCEPTION("EXCP");

		private String status;


		private ProcessStatus(String status) {
			this.status = status;
		}


		public String getStatus() {
			return status;
		}

	}
	
	public enum PyCrCode {
		PAYMENT ("P"),
		CREDIT ("C"),
		ADJUSTMENT("A");

		private String code;


		private PyCrCode(String code) {
			this.code = code;
		}


		public String getCode() {
			return code;
		}


	}


}
