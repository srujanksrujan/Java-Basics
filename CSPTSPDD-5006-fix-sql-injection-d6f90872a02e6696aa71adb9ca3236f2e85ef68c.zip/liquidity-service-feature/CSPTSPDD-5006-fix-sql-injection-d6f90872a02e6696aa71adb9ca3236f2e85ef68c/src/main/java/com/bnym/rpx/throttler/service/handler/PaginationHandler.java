/**
 * File: PaginationHandler.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 3, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.handler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;

import com.bnym.rpx.throttler.service.model.Page;

public class PaginationHandler<E> {
	private static final Logger LOGGER = Logger.getLogger(PaginationHandler.class);

	@SuppressWarnings("unchecked")
	public Page<E> fetchPage(final JdbcTemplate jdbcTemplate, final String sqlCountRows, final String sqlFetchRows,
			final int pageNo, final int pageSize, final RowMapper<E> rowMapper) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("fetchPage() of PaginationHandler called ");
		}

		// determine how many rows are available
		final int rowCount = jdbcTemplate.queryForObject(sqlCountRows, Integer.class);

		LOGGER.info("rowCount:" + rowCount);

		// calculate the number of pages
		int pageCount = rowCount / pageSize;
		if (rowCount > pageSize * pageCount) {
			pageCount++;
		}

		// create the page object
		final Page<E> page = new Page<>();
		page.setPageNumber(pageNo);
		page.setPagesAvailable(pageCount);
		page.setTotalCount(rowCount);
		// fetch a single page of results
		final int startRow = (pageNo - 1) * pageSize;
		jdbcTemplate.query(sqlFetchRows, new ResultSetExtractor() {
			public Object extractData(ResultSet rs) throws SQLException {
				final List pageItems = page.getPageItems();
				int currentRow = 0;
				while (rs.next() && currentRow < startRow + pageSize) {
					if (currentRow >= startRow) {
						pageItems.add(rowMapper.mapRow(rs, currentRow));
					}
					currentRow++;
				}
				return page;
			}
		});
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Page:" + page);
		}
		return page;
	}

}
