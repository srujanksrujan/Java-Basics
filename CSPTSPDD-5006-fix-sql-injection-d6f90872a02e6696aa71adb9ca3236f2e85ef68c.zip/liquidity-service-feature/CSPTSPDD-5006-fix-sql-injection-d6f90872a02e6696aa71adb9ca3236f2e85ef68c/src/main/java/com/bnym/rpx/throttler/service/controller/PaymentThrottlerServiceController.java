/**
 * File: PaymentThrottlerServiceController.java
 * Description:
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").
 * 
 * @author  Swati Rashmi
 * @version 1.0
 * @since   Dec 20, 2016
 */

package com.bnym.rpx.throttler.service.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Date;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bnym.rpx.throttler.service.common.ApplicationConstants;
import com.bnym.rpx.throttler.service.entity.Adjustment;
import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.exception.NoDataFoundException;
import com.bnym.rpx.throttler.service.handler.AdjustmentHandler;
import com.bnym.rpx.throttler.service.handler.AnalyticsBalanceHandler;
import com.bnym.rpx.throttler.service.handler.RefDataHandler;
import com.bnym.rpx.throttler.service.handler.ThrottlerGroupBalanceHandler;
import com.bnym.rpx.throttler.service.handler.TransactionHandler;
import com.bnym.rpx.throttler.service.handler.TransactionMessageHandler;
import com.bnym.rpx.throttler.service.model.APIError;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.AdjustmentInputRequest;
import com.bnym.rpx.throttler.service.model.AdjustmentRequest;
import org.springframework.data.domain.Page;
import com.bnym.rpx.throttler.service.model.ResponseMetadata;
import com.bnym.rpx.throttler.service.model.TransactionsInputRequest;
import com.bnym.rpx.throttler.service.util.ExceptionUtil;

@RestController
@Api(value = "PaymentThrottlerService")
@CrossOrigin (origins = "https://rpx-throttler.dev.bnymellon.net", allowCredentials = "true")
public class PaymentThrottlerServiceController {

	private static final Logger LOGGER = Logger.getLogger(PaymentThrottlerServiceController.class);
	private static final String EXCEPTION = "EXCEPTION";
	@Autowired
	private AdjustmentHandler adjustmentHandler;

	@Autowired
	private TransactionHandler transactionHandler;

	@Autowired
	private RefDataHandler refDataHandler;

	@Autowired
	private AnalyticsBalanceHandler analyticsBalanceHandler;

	@Autowired
	private ThrottlerGroupBalanceHandler throttlerGroupBalanceHandler;

	@Autowired
	private TransactionMessageHandler transactionMessageHandler;

	public static Logger getLogger() {
		return LOGGER;
	}

	public static String getException() {
		return EXCEPTION;
	}

	@RequestMapping(value = "/adjustments/{adjustmentId}", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Fetches the adjustment corresponding to the adjustmentId passed as parameter", notes = "Fetches the adjustment corresponding to the adjustmentId passed as parameter", response = APIResponse.class)

	public @ResponseBody APIResponse readAdjustment(@PathVariable String adjustmentId)
			throws ApplicationException, IOException {
		getLogger().info("readAdjustment Request Received :" + " AdjustmentId:" + adjustmentId);
		APIResponse response = new APIResponse();
		try {
			response = adjustmentHandler.readAdjustment(adjustmentId);
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/adjustments", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Fetches the list all Adjustments according to criteria", notes = "List all Adjustments according to criteria. Account no can be a specific accountNo or ALL", response = APIResponse.class)
	public @ResponseBody ResponseEntity<?> readAllAdjustment(
			@RequestParam(value = "accountNo", required = false) String accountNo,
			@RequestParam(value = "fromValueDate", required = false)  @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date frmValueDate,
			@RequestParam(value = "toValueDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date toValueDate,
			@RequestParam(value = "fromAmount", required = false) BigDecimal frmAmount,
			@RequestParam(value = "toAmount", required = false) BigDecimal toAmount,
			@RequestParam(value = "inAdjusted", required = false) String inAdjusted,
			@RequestParam(value = "outAdjusted", required = false) String outAdjusted,
			@RequestParam(value = "status", required = false) String status,
			@RequestParam(value = "pageNo", required = false, defaultValue = "0") int pageNo,
			@RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize,
			@RequestParam(value = "sortKey", required = false, defaultValue = "updTs") String sortKey,
			@RequestParam(value = "sortOrder", required = false, defaultValue = "DESC") Sort.Direction sortOrder)
			throws ApplicationException, IOException {

		getLogger().info("readAllAdjustment Request Received :" + " Account No:" + accountNo + " From ValueDate:"
				+ frmValueDate + " To ValueDate:" + toValueDate + " From Amount:" + frmAmount + " To Amount:" + toAmount
				+ " IN Adjusted:" + inAdjusted + "OUT Adjusted:" + outAdjusted + " Status:" + status + " pageNo:"
				+ pageNo + " PageSize:" + pageSize + " sortKey:" + sortKey + " sortOrder:" + sortOrder);
		try {
			AdjustmentInputRequest adjustmentInputRequest = new AdjustmentInputRequest();
			adjustmentInputRequest.setAccountNo(accountNo);
			adjustmentInputRequest.setFrmValueDate(frmValueDate);
			adjustmentInputRequest.setToValueDate(toValueDate);
			adjustmentInputRequest.setFrmAmount(frmAmount);
			adjustmentInputRequest.setToAmount(toAmount);
			adjustmentInputRequest.setInAdjusted(inAdjusted);
			adjustmentInputRequest.setOutAdjusted(outAdjusted);
			adjustmentInputRequest.setStatus(status);
			Pageable pageRequest = PageRequest.of(pageNo, pageSize, sortOrder, sortKey); 
			return  new ResponseEntity<Page<Adjustment>>(adjustmentHandler.readAllAdjustment(adjustmentInputRequest, pageRequest), HttpStatus.OK) ;
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			LOGGER.error("Error in fetching Adjustments" + e.getMessage());
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@RequestMapping(value = "/adjustments", method = RequestMethod.POST)
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Creates a new Adjustment", notes = "Creates a new Adjustment", response = APIResponse.class)
	public @ResponseBody APIResponse createAdjustment(@Validated @RequestBody AdjustmentRequest adjustmentReq)
			throws ApplicationException, IOException {
		getLogger().info("createAdjustment Request Received :" + adjustmentReq);
		APIResponse response = new APIResponse();
		try {
			response = adjustmentHandler.createAdjustment(adjustmentReq);
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));

		}
		return response;
	}

	@RequestMapping(value = "/adjustments/{adjustmentId}", method = RequestMethod.PUT)
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Updates an existing Adjustment else creates a new one", notes = "updates Adjustment", response = APIResponse.class)
	public @ResponseBody APIResponse updateAdjustment(@Validated @RequestBody AdjustmentRequest adjustmentReq,
			@PathVariable String adjustmentId) throws ApplicationException, IOException {
		getLogger().info("updateAdjustment Request Received :" + adjustmentId);
		APIResponse response = new APIResponse();
		try {
			response = adjustmentHandler.updateAdjustment(adjustmentId, adjustmentReq);
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/adjustments/decision", method = RequestMethod.PUT)
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)

	@ApiOperation(value = "Approves or Rejects an Adjustment. action = approve/reject", notes = "action = APVRD/REJECTED", response = APIResponse.class)
	public @ResponseBody APIResponse approveAdjustment(@RequestBody AdjustmentRequest adjustmentReq,
			@RequestParam("adjustmentId") String adjustmentId,
			@RequestParam(value = "action", required = true) String action) throws ApplicationException, IOException {
		getLogger()
				.info("ApproveAdjustment Request Received :" + " Adjustment Id:" + adjustmentId + " Action:" + action);
		APIResponse response = new APIResponse();
		try {
			response = adjustmentHandler.approveAdjustment(adjustmentReq, adjustmentId, action);
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));

		}
		return response;
	}

	@RequestMapping(value = "/transactions", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Get Payment screen With Payment/ Credit Type Transactions", notes = "filter criteria and pagination based on parameters", response = APIResponse.class)
	public @ResponseBody APIResponse readAllTransactions(
			@RequestParam(value = "tranType", required = false) String tranType,
			@RequestParam(value = "srcReferenceNo", required = false) String srcReferenceNo,
			@RequestParam(value = "accountNo", required = false) String accountNo,
			@RequestParam(value = "fromValueDate", required = false) String fromValueDate,
			@RequestParam(value = "toValueDate", required = false) String toValueDate,
			@RequestParam(value = "fromAmount", required = false) BigDecimal fromAmount,
			@RequestParam(value = "toAmount", required = false) BigDecimal toAmount,
			@RequestParam(value = "procStatus", required = false) String procStatus,
			@RequestParam(value = "currencyCode", required = false) String currencyCode,
			@RequestParam(value = "pageNo", required = false, defaultValue = "1") int pageNo,
			@RequestParam(value = "pageSize", required = false, defaultValue = "10") int pageSize,
			@ApiParam(name = "sortKeys") @RequestParam(required = false, defaultValue = "SRC_REF_NO ASC, UPD_TS DESC") String sortKeys)
			throws ApplicationException, IOException {
		getLogger().info("readAllTransactions Request Received :" + " Transaction Type:" + tranType
				+ " Source Reference No:" + srcReferenceNo + " Account No:" + accountNo + " From Value Date:"
				+ fromValueDate + " To Value Date:" + toValueDate + " From Payment Amount:" + fromAmount
				+ " To Payment Amount:" + toAmount + " procStatus:" + procStatus + " currencyCode:" + currencyCode
				+ " pageNo:" + pageNo + " PageSize:" + pageSize + " sortKeys:" + sortKeys);

		APIResponse response = new APIResponse();
		try {
			TransactionsInputRequest transactionsInputRequest = new TransactionsInputRequest();
			transactionsInputRequest.setTranType(tranType);
			transactionsInputRequest.setRefNo(srcReferenceNo);
			transactionsInputRequest.setAcctNo(accountNo);
			transactionsInputRequest.setFromValueDate(fromValueDate);
			transactionsInputRequest.setToValueDate(toValueDate);
			transactionsInputRequest.setFromAmount(fromAmount);
			transactionsInputRequest.setToAmount(toAmount);
			transactionsInputRequest.setStatus(procStatus);
			transactionsInputRequest.setCcyCode(currencyCode);
			transactionsInputRequest.setPageNo(pageNo);
			transactionsInputRequest.setPageSize(pageSize);
			transactionsInputRequest.setSortKeys(sortKeys);
			response = transactionHandler.readAllTransactions(transactionsInputRequest);
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));

		}
		return response;
	}

	@RequestMapping(value = "/transactionDetails", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Fetches the transaction details corresponding to the tranType (P/C),srcRefNo,srcSysCd,adtVrsnNo passed as parameter", notes = "tranType = P/C", response = APIResponse.class)

	public @ResponseBody APIResponse readTransactionDetails(
			@RequestParam(value = "tranType", required = true) String tranType,
			@RequestParam(value = "srcRefNo", required = true) String srcRefNo,
			@RequestParam(value = "srcSysCd", required = true) String srcSysCd,
			@RequestParam(value = "adtVrsnNo", required = true) String adtVrsnNo)
			throws ApplicationException, IOException {

		getLogger().info("readTransactionDetails Request Received :" + " tranType:" + tranType + " srcRefNo:" + srcRefNo
				+ " srcSysCd:" + srcSysCd + " adtVrsnNo:" + adtVrsnNo);
		APIResponse response = new APIResponse();
		try {
			response = transactionHandler.readTransactionDetails(tranType, srcRefNo, srcSysCd, adtVrsnNo);
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/transactions/messagedetails", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Fetches the message details like raw message, queue name etc. for given Reference Number ", notes = "Fetches Transaction Message Details", response = APIResponse.class)
	public @ResponseBody APIResponse getTransactionRawMessageDetails(
			@ApiParam(required = true) @RequestParam(value = "referenceNumber", required = true) String referenceNumber,
			@ApiParam(required = true) @RequestParam(value = "paymentStatus", required = true) String paymentStatus)
			throws ApplicationException, IOException {
		getLogger().info("Reference Number & Payment Status : " + referenceNumber + " " + paymentStatus);
		APIResponse response = new APIResponse();
		try {
			response = transactionMessageHandler.getTranactionMessageDetails(referenceNumber, paymentStatus);
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/reference/accounts", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Retrives the list of all the accounts with corresponding branch-code set-up in Throttler service", notes = "Reference Data", response = APIResponse.class)
	public @ResponseBody APIResponse getAllAccounts() throws ApplicationException, IOException {

		getLogger().info("getAllAccounts Request Received ");
		APIResponse response = new APIResponse();
		try {
			response = refDataHandler.getAllAccounts();
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));

		}
		return response;
	}

	@RequestMapping(value = "/reference/adjustment/reason", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Retrives the list of reasons for adjustment set-up in Throttler service", notes = "Reference Data", response = APIResponse.class)
	public @ResponseBody APIResponse getAdjustmentReasons() throws ApplicationException, IOException {

		getLogger().info("getAdjustmentReasons Request Received ");
		APIResponse response = new APIResponse();
		try {
			response = refDataHandler.getAdjReasons();
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));

		}
		return response;
	}

	@RequestMapping(value = "/reference/adjustment/status", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Retrives the list of status for adjustment set-up in Throttler service", notes = "Reference Data", response = APIResponse.class)
	public @ResponseBody APIResponse getAdjustmentStatus() throws ApplicationException, IOException {

		getLogger().info("getAdjustmentStatus Request Received ");
		APIResponse response = new APIResponse();
		try {
			response = refDataHandler.getAdjStatus();
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));

		}
		return response;
	}

	@RequestMapping(value = "/reference/configs/{configName}", method = RequestMethod.GET, produces = {
			org.springframework.http.MediaType.APPLICATION_JSON_VALUE })
	@ApiOperation(value = "Retrives the list of configurations for a given configName in Throttler service", notes = "Reference Data", response = APIResponse.class, produces = "application/json", httpMethod = "GET"

	)
	public ResponseEntity<APIResponse> getActiveConfigs(
			@PathVariable @ApiParam(required = true, allowableValues = "ADJ_STATUS, ADJ_REASON, PROCCODES, STATCODES, STATRSNCD") String configName)
			throws ApplicationException, NoDataFoundException {
		getLogger().info("getActiveConfigs(configName) Request Received ");
		APIResponse response = refDataHandler.getActiveConfigs(configName);
		response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		return new ResponseEntity<>(response, HttpStatus.OK);
		// please note that any exception thrown will be caught and handled by
		// the common method defined in this file.
		// this approach will reduce repeated exception handling code
	}

	@RequestMapping(value = "/analytics/account/liquidity", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Gives Throttler Group Account Liquidity Analytics", notes = "Gives Throttler Group Account Liquidity Analytics", response = APIResponse.class)
	public @ResponseBody APIResponse getAnalyticsAccountLiquidity(
			@ApiParam(name = "valueDate", value = "Value Date Format : 02-NOV-17", required = true) @RequestParam String valueDate)
			throws ApplicationException, IOException {
		getLogger().info("getAnalyticsAccountLiquidity Request Received ");
		APIResponse response = new APIResponse();
		try {
			response = throttlerGroupBalanceHandler.getAnalyticsAccountLiquidity(valueDate);
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/analytics/account/liquidity/position", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Gives Throttler Group Account Liquidity Position Analytics", notes = "Gives Throttler Group Account Liquidity Position Analytics", response = APIResponse.class)
	public @ResponseBody APIResponse getAnalyticsAccountLiquidityPosition(
			@ApiParam(name = "accountNumber", value = "Account Number", required = true) @RequestParam String accountNumber,
			@ApiParam(name = "accountBranchCode", value = "Account Branch Code", required = true) @RequestParam String accountBranchCode,
			@ApiParam(name = "accountSourceSystemCode", value = "Account SourceSystem Code", required = true) @RequestParam String accountSourceSystemCode,
			@ApiParam(name = "valueDate", value = "Value Date Format : 20-MAR-2018", required = true) @RequestParam String valueDate)
			throws ApplicationException, IOException {
		getLogger().info("getAnalyticsAccountLiquidityPosition Request Received ");
		APIResponse response = new APIResponse();
		try {
			response = throttlerGroupBalanceHandler.getAnalyticsAccountLiquidityPosition(accountNumber,
					accountBranchCode, accountSourceSystemCode, valueDate);
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/analytics/balance", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Gives Analytics Balance", notes = "Gives Analytics Balance", response = APIResponse.class)
	public @ResponseBody APIResponse getAnalyticsBalance(
			@ApiParam(name = "valueDate", value = "date format : 28-Mar-2018", required = true) @RequestParam String valueDate,
			@ApiParam(name = "accountNumber", value = "Enter All or Account Number", required = true, defaultValue = "All") @RequestParam String accountNumber)
			throws ApplicationException, IOException {
		getLogger().info("getAnalyticsBalance Request Received ");
		APIResponse response = null;
		try {
			response = analyticsBalanceHandler.getAnalyticsBalance(valueDate, accountNumber);
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response = new APIResponse();
			response.setError(new APIError(getException(), e.getMessage()));
		}
		return response;
	}

	@RequestMapping(value = "/allServiceDomainUrls", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Retrives the list of Domain URL's for All Interfaces", notes = "Reference Data", response = APIResponse.class)
	public @ResponseBody APIResponse getAllServiceDomainUrls() throws ApplicationException, IOException {
		getLogger().info("allServiceDomainUrls Request Received ");
		APIResponse response = new APIResponse();
		try {
			response = refDataHandler.getAllServiceDomainUrls();
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/businessdate", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Retrives Current Business Date in the Format : 13-NOV-17", notes = "Reference Data", response = APIResponse.class)
	public @ResponseBody APIResponse getBusinessDate() throws ApplicationException, IOException {
		getLogger().info("businessdate Request Received ");
		APIResponse response = new APIResponse();
		try {
			response = refDataHandler.getBusinessDate();
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			getLogger().error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<APIResponse> errorResponse(Exception ex) {
		APIResponse response = new APIResponse();
		response.setError(new APIError(getException(), ex.getMessage()));
		response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(NoDataFoundException.class)
	public ResponseEntity<APIResponse> errorResponse(NoDataFoundException ne) {
		APIResponse response = new APIResponse();
		String errorMessage = "No data found for the given criteria";
		response.setError(new APIError(errorMessage, errorMessage));
		response.setMetadata(new ResponseMetadata(404, errorMessage));
		return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
	}

}
