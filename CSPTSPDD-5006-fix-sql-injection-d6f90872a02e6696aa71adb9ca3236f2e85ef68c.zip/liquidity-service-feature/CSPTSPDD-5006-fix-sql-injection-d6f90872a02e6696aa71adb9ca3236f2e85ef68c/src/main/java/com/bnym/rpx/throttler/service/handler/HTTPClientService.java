package com.bnym.rpx.throttler.service.handler;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

import com.bnym.rpx.throttler.service.exception.ApplicationException;

@Configuration
@Service(value = "httpClientService")
public class HTTPClientService {

	private static final Logger LOGGER = Logger.getLogger(HTTPClientService.class);

	public String getHttpUrlResponse(String url) throws ApplicationException {
		HttpResponse response;
		String result = null;
		try {
			LOGGER.info("\nSending 'GET' request to URL : " + url);
			HttpClient client = HttpClientBuilder.create().build();
			response = client.execute(new HttpGet(url));
			if (response == null) {
				result = "No Response received from URL :" + url;
			} else {
				LOGGER.info("Response Code : " + response.getStatusLine().getStatusCode());
				if (response.getEntity() != null) {
					result = IOUtils.toString(response.getEntity().getContent(), StandardCharsets.UTF_8);
				}
			}
		} catch (ClientProtocolException ex) {
			if (ex.getMessage().contains("Connection refused: connect")) {
				return "";
			}
			throw new ApplicationException("Exception While getting getHttpUrlResponse : ", ex);
		} catch (IOException ex) {
			if (ex.getMessage().contains("Connection refused: connect")) {
				return "";
			}
			throw new ApplicationException("Exception While getting getHttpUrlResponse : ", ex);
		}
		return result;
	}
}
