/**
 * File: TransactionBuilder.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 5, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.builder;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnym.rpx.throttler.service.dao.impl.TransactionDAOImpl;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.Page;
import com.bnym.rpx.throttler.service.model.Result;
import com.bnym.rpx.throttler.service.model.Transaction;
import com.bnym.rpx.throttler.service.model.TransactionDetails;
import com.bnym.rpx.throttler.service.model.TransactionsInputRequest;
import com.bnym.rpx.throttler.service.util.TransactionProcessStatusType;

@Component
public class TransactionBuilder {


	private static final Logger LOGGER = Logger.getLogger(TransactionBuilder.class);

	
	private TransactionDAOImpl transactionDaoImpl;
	
	public TransactionDAOImpl getTransactionDaoImpl() {
		return transactionDaoImpl;
	}

	@Autowired
	public void setTransactionDaoImpl(TransactionDAOImpl transactionDaoImpl) {
		this.transactionDaoImpl = transactionDaoImpl;
	}

	public APIResponse buildReadTransactionDetailsResponse(String tranType, String srcRefNo, String srcSysCd,String adtVrsnNo) throws DAOException {

		LOGGER.info("buildReadTransactionResponse() called in TransactionBuilder  for Type:" + tranType+" srcRefNo:" + srcRefNo  + " srcSysCd:" + srcSysCd + " adtVrsnNo:"+ adtVrsnNo);
		TransactionDetails details = transactionDaoImpl.getTranactionDetails(tranType,srcRefNo,srcSysCd,adtVrsnNo);
		List <TransactionDetails> tranResponseList= new ArrayList<>();
		tranResponseList.add(details);
		APIResponse apiResponse = new APIResponse();
		apiResponse.setResult(new Result(new ArrayList<Object>(tranResponseList)));
		return apiResponse;

	}

	public APIResponse buildReadAllTransactionsResponse(TransactionsInputRequest transactionsInputRequest) throws DAOException {
		LOGGER.info("buildReadAllTransactiosResponse() called in TransactionBuilder" );
		Page<Transaction>  tranResponsePage = transactionDaoImpl.getAllTransactions(transactionsInputRequest);
		addTransactionProcessStatus(tranResponsePage);
		List<Page> responseList = new ArrayList<>();
		responseList.add(tranResponsePage);
		APIResponse apiResponse = new APIResponse();
		apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
		return apiResponse;
	}
	
	public void addTransactionProcessStatus(Page<Transaction> tranResponsePage)throws DAOException{
		if(tranResponsePage != null){
			if(tranResponsePage.getPageItems()!= null && tranResponsePage.getPageItems().size()>0){
				for(Transaction transaction: tranResponsePage.getPageItems()){
					if(transaction!=null && transaction.getProcStat()!=null){
						TransactionProcessStatusType transactionProcessStatusType= TransactionProcessStatusType.value(transaction.getProcStat());
						transaction.setProcStatDesc(transactionProcessStatusType.description());	
					}
				}
			}
		}
	}
	
}
