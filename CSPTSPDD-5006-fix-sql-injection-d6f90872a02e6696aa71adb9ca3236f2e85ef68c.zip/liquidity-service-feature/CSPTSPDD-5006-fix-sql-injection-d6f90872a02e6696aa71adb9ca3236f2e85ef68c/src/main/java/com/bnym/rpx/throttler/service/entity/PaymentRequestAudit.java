package com.bnym.rpx.throttler.service.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "T_GVP_THRTL_PY_RQST_ADT ")
public class PaymentRequestAudit implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "SRC_REF_NO")
	private String srcRefNo;
	@Column(name = "SRC_SYS_CD")
	private String srcSysCode;
	@Column(name = "ADT_VRSN_NO", insertable = false, updatable = false)
	private String adtVersionNo;
	@Column(name = "PROC_STAT")
	private String procStatus;
	@Column(name = "THRTL_GRP_ID")
	private String throttlerGroupId;
	@Column(name = "BULK_ID")
	private String bulkId;
	@Column(name = "INTR_DIR_CD")
	private String intrDirCd;
	@Column(name = "INTR_TYP_CD")
	private String intrTypCode;
	@Column(name = "REQ_TYP_CD")
	private String reqTypeCode;
	@Column(name = "VRSN_NO")
	private String versionNo;
	@Column(name = "GRP_OFF_ID")
	private String grpOffId;
	@Column(name = "GRP_BR_ID")
	private String grpBrId;
	@Column(name = "MSG_CNT")
	private String msgCnt;
	@Column(name = "GRP_REF_ID")
	private String grpRefId;
	@Column(name = "CRT_TM")
	private String createTime;
	@Column(name = "MSG_REF_ID")
	private String msgRefId;
	@Column(name = "ORIG_REF_ID")
	private String originalRefId;
	@Column(name = "MSG_OFF_ID")
	private String msgOffId;
	@Column(name = "MSG_BR_ID")
	private String msgBrId;
	@Column(name = "RSV_ID")
	private String rsvId;
	@Column(name = "POST_ENTR_TYP")
	private String postEntrType;
	@Column(name = "ACCT_NO")
	private String accountNo;
	@Column(name = "ACCT_BR_CD")
	private String accountBranchCode;
	@Column(name = "ACCT_SRC_SYS_CD")
	private String accountSrcSysCode;
	@Column(name = "ACCT_CAT")
	private String accountCat;
	@Column(name = "CCY_ISO_CD")
	private String ccyIsoCode;
	@Column(name = "ACCT_TYP_CD")
	private String accountTypeCode;
	@Column(name = "VAL_DT")
	private String valueDate;
	@Column(name = "DB_CR_CD")
	private String dbCrCd;
	@Column(name = "POST_OVR_CD")
	private String postOvrCode;
	@Column(name = "TRN_NARR")
	private String trnNarr;
	@Column(name = "INSTR_CCY_CD")
	private String instrCcyCode;
	@Column(name = "INSTR_AMT")
	private String instrAmt;
	@Column(name = "FX_RT")
	private String fxRt;
	@Column(name = "BASE_CCY_CD")
	private String baseCcyCode;
	@Column(name = "BASE_AMT")
	private String baseAnount;
	@Column(name = "BASE_FX_RATE")
	private String baseFxRate;
	@Column(name = "CRT_USR_ID")
	private String crtUsrId;
	@Column(name = "CRT_TS")
	private String createTimestamp;
	@Column(name = "UPD_USR_ID")
	private String updUserId;
	@Column(name = "UPD_TS")
	private String updateTimestamp;

	public String getSrcRefNo() {
		return srcRefNo;
	}

	public void setSrcRefNo(String srcRefNo) {
		this.srcRefNo = srcRefNo;
	}

	public String getSrcSysCode() {
		return srcSysCode;
	}

	public void setSrcSysCode(String srcSysCode) {
		this.srcSysCode = srcSysCode;
	}

	public String getAdtVersionNo() {
		return adtVersionNo;
	}

	public void setAdtVersionNo(String adtVersionNo) {
		this.adtVersionNo = adtVersionNo;
	}

	public String getProcStatus() {
		return procStatus;
	}

	public void setProcStatus(String procStatus) {
		this.procStatus = procStatus;
	}

	public String getThrottlerGroupId() {
		return throttlerGroupId;
	}

	public void setThrottlerGroupId(String throttlerGroupId) {
		this.throttlerGroupId = throttlerGroupId;
	}

	public String getBulkId() {
		return bulkId;
	}

	public void setBulkId(String bulkId) {
		this.bulkId = bulkId;
	}

	public String getIntrDirCd() {
		return intrDirCd;
	}

	public void setIntrDirCd(String intrDirCd) {
		this.intrDirCd = intrDirCd;
	}

	public String getIntrTypCode() {
		return intrTypCode;
	}

	public void setIntrTypCode(String intrTypCode) {
		this.intrTypCode = intrTypCode;
	}

	public String getReqTypeCode() {
		return reqTypeCode;
	}

	public void setReqTypeCode(String reqTypeCode) {
		this.reqTypeCode = reqTypeCode;
	}

	public String getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	public String getGrpOffId() {
		return grpOffId;
	}

	public void setGrpOffId(String grpOffId) {
		this.grpOffId = grpOffId;
	}

	public String getGrpBrId() {
		return grpBrId;
	}

	public void setGrpBrId(String grpBrId) {
		this.grpBrId = grpBrId;
	}

	public String getMsgCnt() {
		return msgCnt;
	}

	public void setMsgCnt(String msgCnt) {
		this.msgCnt = msgCnt;
	}

	public String getGrpRefId() {
		return grpRefId;
	}

	public void setGrpRefId(String grpRefId) {
		this.grpRefId = grpRefId;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getMsgRefId() {
		return msgRefId;
	}

	public void setMsgRefId(String msgRefId) {
		this.msgRefId = msgRefId;
	}

	public String getOriginalRefId() {
		return originalRefId;
	}

	public void setOriginalRefId(String originalRefId) {
		this.originalRefId = originalRefId;
	}

	public String getMsgOffId() {
		return msgOffId;
	}

	public void setMsgOffId(String msgOffId) {
		this.msgOffId = msgOffId;
	}

	public String getMsgBrId() {
		return msgBrId;
	}

	public void setMsgBrId(String msgBrId) {
		this.msgBrId = msgBrId;
	}

	public String getRsvId() {
		return rsvId;
	}

	public void setRsvId(String rsvId) {
		this.rsvId = rsvId;
	}

	public String getPostEntrType() {
		return postEntrType;
	}

	public void setPostEntrType(String postEntrType) {
		this.postEntrType = postEntrType;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountBranchCode() {
		return accountBranchCode;
	}

	public void setAccountBranchCode(String accountBranchCode) {
		this.accountBranchCode = accountBranchCode;
	}

	public String getAccountSrcSysCode() {
		return accountSrcSysCode;
	}

	public void setAccountSrcSysCode(String accountSrcSysCode) {
		this.accountSrcSysCode = accountSrcSysCode;
	}

	public String getAccountCat() {
		return accountCat;
	}

	public void setAccountCat(String accountCat) {
		this.accountCat = accountCat;
	}

	public String getCcyIsoCode() {
		return ccyIsoCode;
	}

	public void setCcyIsoCode(String ccyIsoCode) {
		this.ccyIsoCode = ccyIsoCode;
	}

	public String getAccountTypeCode() {
		return accountTypeCode;
	}

	public void setAccountTypeCode(String accountTypeCode) {
		this.accountTypeCode = accountTypeCode;
	}

	public String getValueDate() {
		return valueDate;
	}

	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}

	public String getDbCrCd() {
		return dbCrCd;
	}

	public void setDbCrCd(String dbCrCd) {
		this.dbCrCd = dbCrCd;
	}

	public String getPostOvrCode() {
		return postOvrCode;
	}

	public void setPostOvrCode(String postOvrCode) {
		this.postOvrCode = postOvrCode;
	}

	public String getTrnNarr() {
		return trnNarr;
	}

	public void setTrnNarr(String trnNarr) {
		this.trnNarr = trnNarr;
	}

	public String getInstrCcyCode() {
		return instrCcyCode;
	}

	public void setInstrCcyCode(String instrCcyCode) {
		this.instrCcyCode = instrCcyCode;
	}

	public String getInstrAmt() {
		return instrAmt;
	}

	public void setInstrAmt(String instrAmt) {
		this.instrAmt = instrAmt;
	}

	public String getFxRt() {
		return fxRt;
	}

	public void setFxRt(String fxRt) {
		this.fxRt = fxRt;
	}

	public String getBaseCcyCode() {
		return baseCcyCode;
	}

	public void setBaseCcyCode(String baseCcyCode) {
		this.baseCcyCode = baseCcyCode;
	}

	public String getBaseAnount() {
		return baseAnount;
	}

	public void setBaseAnount(String baseAnount) {
		this.baseAnount = baseAnount;
	}

	public String getBaseFxRate() {
		return baseFxRate;
	}

	public void setBaseFxRate(String baseFxRate) {
		this.baseFxRate = baseFxRate;
	}

	public String getCrtUsrId() {
		return crtUsrId;
	}

	public void setCrtUsrId(String crtUsrId) {
		this.crtUsrId = crtUsrId;
	}

	public String getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(String createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public String getUpdUserId() {
		return updUserId;
	}

	public void setUpdUserId(String updUserId) {
		this.updUserId = updUserId;
	}

	public String getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(String updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	@Override
	public String toString() {
		return "PaymentRequestAudit [srcRefNo=" + srcRefNo + ", srcSysCode=" + srcSysCode + ", adtVersionNo="
				+ adtVersionNo + ", procStatus=" + procStatus + ", throttlerGroupId=" + throttlerGroupId + ", bulkId="
				+ bulkId + ", intrDirCd=" + intrDirCd + ", intrTypCode=" + intrTypCode + ", reqTypeCode=" + reqTypeCode
				+ ", versionNo=" + versionNo + ", grpOffId=" + grpOffId + ", grpBrId=" + grpBrId + ", msgCnt=" + msgCnt
				+ ", grpRefId=" + grpRefId + ", createTime=" + createTime + ", msgRefId=" + msgRefId
				+ ", originalRefId=" + originalRefId + ", msgOffId=" + msgOffId + ", msgBrId=" + msgBrId + ", rsvId="
				+ rsvId + ", postEntrType=" + postEntrType + ", accountNo=" + accountNo + ", accountBranchCode="
				+ accountBranchCode + ", accountSrcSysCode=" + accountSrcSysCode + ", accountCat=" + accountCat
				+ ", ccyIsoCode=" + ccyIsoCode + ", accountTypeCode=" + accountTypeCode + ", valueDate=" + valueDate
				+ ", dbCrCd=" + dbCrCd + ", postOvrCode=" + postOvrCode + ", trnNarr=" + trnNarr + ", instrCcyCode="
				+ instrCcyCode + ", instrAmt=" + instrAmt + ", fxRt=" + fxRt + ", baseCcyCode=" + baseCcyCode
				+ ", baseAnount=" + baseAnount + ", baseFxRate=" + baseFxRate + ", crtUsrId=" + crtUsrId
				+ ", createTimestamp=" + createTimestamp + ", updUserId=" + updUserId + ", updateTimestamp="
				+ updateTimestamp + "]";
	}
 
}
