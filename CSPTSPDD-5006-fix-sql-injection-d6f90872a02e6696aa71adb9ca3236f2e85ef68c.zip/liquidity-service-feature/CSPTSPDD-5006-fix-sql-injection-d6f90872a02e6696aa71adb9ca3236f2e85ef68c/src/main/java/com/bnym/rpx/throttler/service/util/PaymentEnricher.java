/**
 * File: PaymentEnricher.java
 * Description:
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").
 * 
 * @author  Swati Rashmi
 * @Since: Dec 19, 2016
 * @Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.util;

import java.sql.Timestamp;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnym.rpx.throttler.service.dao.impl.AdjustmentAuditDAOImpl;
import com.bnym.rpx.throttler.service.dao.impl.AdjustmentDAOImpl;
import com.bnym.rpx.throttler.service.dao.impl.GroupAccountDAOImpl;
import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.model.GroupAccount;



@Component
public class PaymentEnricher {

	@Autowired
	private AdjustmentAuditDAOImpl adjustmentAuditDAOImpl;

	@Autowired
	private GroupAccountDAOImpl groupAccountDAOImpl;

	@Autowired
	private AdjustmentDAOImpl  adjustmentDAOImpl;


	private static final Logger LOGGER = Logger.getLogger(PaymentEnricher.class);
	
	

	public GroupAccount getGrpAcctInfo(String accountNo) throws ApplicationException {
		GroupAccount accInfo = null;
		try {
			accInfo = groupAccountDAOImpl.getGrpAcctInfo(accountNo);
			LOGGER.info("getGrpAcctInfo() of PaymentEnricher called. accInfo : " + accInfo);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return accInfo;

	}

	public String getAdjustmentId() throws ApplicationException {
		try{
			return adjustmentDAOImpl.getAdjustmentId();
		}
		catch(Exception e){
			throw new ApplicationException(e);
		}
	}

	public Long getCurrentAuditVersionNo(String adjustmentId) throws ApplicationException {
		Long lastAuditVrsnNo = (long) 0;
		try {
			lastAuditVrsnNo = adjustmentAuditDAOImpl.findLastAuditVersionNo(adjustmentId);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return lastAuditVrsnNo + 1;
	}

	public Timestamp getSystemTimestamp() throws ApplicationException {
		try{
			return adjustmentDAOImpl.getSystemTimestamp();
		}
		catch(Exception e){
			throw new ApplicationException(e);
		}
	}
}
