/**
 * <p>File: ExceptionUtil.java 
 * Project:	Liquidity Management (LQM)
 * 
 * Description: The generic DAO class having methods to perform generic operations on entity</p>
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").
 * 
 * @author LQM Team
 * @version 1.0
 */
package com.bnym.rpx.throttler.service.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import com.bnym.rpx.throttler.service.exception.ApplicationException;

/**
 * @author Pitchireddy
 *
 */
public final class ExceptionUtil {
	private static final String LINE_SEPARATOR = System.getProperty("line.separator");
	private static final int MAX_EXCEPTION_LINES = 60;

	private ExceptionUtil() {

	}

	/**
	 * <p>
	 * Gets the stack trace from a Throwable as a customized String.
	 * </p>
	 * 
	 * @param cause
	 * @param LINE_SEPARATOR
	 * @param maxLines
	 * @return
	 * @throws IOException
	 */
	public static String getCustomStackTrace(Throwable cause, int maxLines) throws ApplicationException, IOException {
		StringWriter stringWriter = null;
		PrintWriter printWriter = null;
		try {
			stringWriter = new StringWriter();
			printWriter = new PrintWriter(stringWriter);
			/* Exception class name */
			printWriter.print("(" + cause.getClass().getName() + ")" + LINE_SEPARATOR);

			StackTraceElement[] stackTrace = cause.getStackTrace();
			for (int i = 0; i < stackTrace.length; i++) {
				printWriter.print(stackTrace[i] + LINE_SEPARATOR);
				if (i >= maxLines) {
					break;
				}
			}
			return stringWriter.toString();
		} catch (Exception e) {
			throw new ApplicationException(e);
		} finally {
			if (printWriter != null) {
				printWriter.close();
			}
			if (stringWriter != null) {
				stringWriter.close();
			}
		}
	}

	/**
	 * <p>
	 * Extracts the root cause of the exception, no matter how nested it is
	 * </p>
	 * 
	 * @param t
	 * @return The deepest cause of the exception that can be found
	 */
	public static Throwable getRootCause(Throwable t) {
		Throwable result = t;
		while ((result.getCause()) != null) {
			result = result.getCause();
		}
		return result;
	}

	public static String getFullStackTrace(Throwable exception) throws ApplicationException, IOException {
		return getFullStackTrace(exception, MAX_EXCEPTION_LINES);
	}

	public static String getFullStackTrace(Throwable exception, int maxLinesPerException)
			throws ApplicationException, IOException {
		final String header = "** Liquidity Management: STACK TRACE **";
		final String footer = LINE_SEPARATOR;

		StringBuilder stackTraceString = new StringBuilder();
		stackTraceString.append(header + LINE_SEPARATOR);

		/* get stack trace string message for the exception */
		stackTraceString.append(getCustomStackTrace(exception, maxLinesPerException));

		/* Add root cause Exception Message, if any */
		stackTraceString.append(addRootCause(exception, maxLinesPerException));

		/* Append the Footer Message */
		stackTraceString.append(footer);

		return stackTraceString.toString();
	}

	public static String getFullExceptionAsString(Throwable exception) throws ApplicationException, IOException {
		return getFullExceptionAsString(exception, MAX_EXCEPTION_LINES);
	}

	/**
	 * @param exception
	 * @param maxLinesPerException
	 * @return
	 * @throws IOException
	 * @throws ApplicationException
	 */
	public static String getFullExceptionAsString(Throwable exception, int maxLinesPerException)
			throws ApplicationException, IOException {
		StringBuilder stackTraceString = new StringBuilder();
		if (exception.getMessage() != null) {
			stackTraceString.append("Message - " + exception.getMessage() + LINE_SEPARATOR);
		}

		return stackTraceString.toString() + getFullStackTrace(exception, maxLinesPerException);
	}

	/**
	 * Add root cause exception details
	 * 
	 * @param exception
	 * @param stackTraceString
	 * @param maxLinesPerException
	 * @return
	 * @throws IOException
	 * @throws ApplicationException
	 */
	public static String addRootCause(Throwable exception, int maxLinesPerException)
			throws ApplicationException, IOException {
		Throwable rootCause = getRootCause(exception);
		StringBuilder stackTraceBuffer = new StringBuilder();
		if (!rootCause.equals(exception)) {
			stackTraceBuffer.append("=== CAUSED BY ===" + LINE_SEPARATOR);
			if (rootCause.getMessage() != null) {
				stackTraceBuffer.append("Message - " + rootCause.getMessage() + LINE_SEPARATOR);
			}
			stackTraceBuffer.append(getCustomStackTrace(rootCause, maxLinesPerException));
		}
		return stackTraceBuffer.toString();
	}

	/**
	 * @param cause
	 * @return
	 */
	public static String getRootMethod(Exception cause) {
		Throwable rootCause = getRootCause(cause);
		StackTraceElement[] stackTrace = rootCause.getStackTrace();
		if (stackTrace.length != 0) {
			return stackTrace[stackTrace.length - 1].getMethodName();
		} else {
			return null;
		}
	}
}
