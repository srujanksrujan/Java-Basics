package com.bnym.rpx.throttler.service.handler;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnym.rpx.throttler.service.builder.TransactionBuilder;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.TransactionsInputRequest;

@Service
public class TransactionHandler {

	private static final Logger LOGGER = Logger.getLogger(TransactionHandler.class);

	private TransactionBuilder transactionBuilder;

	public TransactionBuilder getTransactionBuilder() {
		return transactionBuilder;
	}

	@Autowired
	public void setTransactionBuilder(TransactionBuilder transactionBuilder) {
		this.transactionBuilder = transactionBuilder;
	}

	public APIResponse readTransactionDetails(String type, String srcRefNo, String srcSysCd, String adtVrsnNo)
			throws DAOException {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("readTransaction() called in TransactionHandler :");
		}
		return transactionBuilder.buildReadTransactionDetailsResponse(type, srcRefNo, srcSysCd, adtVrsnNo);
	}

	public APIResponse readAllTransactions(TransactionsInputRequest transactionsInputRequest) throws DAOException {
		LOGGER.info("readAllTransactions() called in TransactionHandler :");
		return transactionBuilder.buildReadAllTransactionsResponse(transactionsInputRequest);
	}
}
