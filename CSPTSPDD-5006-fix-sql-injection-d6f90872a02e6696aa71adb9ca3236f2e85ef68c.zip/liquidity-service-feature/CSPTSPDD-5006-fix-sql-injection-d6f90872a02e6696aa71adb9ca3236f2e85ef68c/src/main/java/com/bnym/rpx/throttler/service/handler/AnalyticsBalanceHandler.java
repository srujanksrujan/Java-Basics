package com.bnym.rpx.throttler.service.handler;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnym.rpx.throttler.service.builder.AnalyticsBalanceBuilder;
import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.model.APIResponse;

@Service
public class AnalyticsBalanceHandler {
	private static final Logger LOGGER = Logger.getLogger(AnalyticsBalanceHandler.class);

	
	private AnalyticsBalanceBuilder analyticsBalanceBuilder;
	
	public AnalyticsBalanceBuilder getAnalyticsBalanceBuilder() {
		return analyticsBalanceBuilder;
	}

	@Autowired
	public void setAnalyticsBalanceBuilder(AnalyticsBalanceBuilder analyticsBalanceBuilder) {
		this.analyticsBalanceBuilder = analyticsBalanceBuilder;
	}



	public APIResponse getAnalyticsBalance(String valueDate, String accountNumber) throws ApplicationException  {
		
		APIResponse response = null;
		try {
			LOGGER.info("getAnalyticsBalance() called in AnalyticsBalanceHandler :");
			response = analyticsBalanceBuilder.getAnalyticsBalance(valueDate, accountNumber);
		} catch (Exception e) { 
			throw new ApplicationException(e);
		}
		return response;
	}
}