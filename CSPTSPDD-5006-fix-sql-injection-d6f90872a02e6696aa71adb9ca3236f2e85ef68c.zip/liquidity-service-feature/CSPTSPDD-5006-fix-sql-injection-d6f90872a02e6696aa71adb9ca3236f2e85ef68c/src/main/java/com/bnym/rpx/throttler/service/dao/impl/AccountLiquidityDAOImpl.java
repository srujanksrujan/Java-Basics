/**
 * File: AccountLiquidityDAOImpl.java
 * Description:
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").
 * 
 * @author  Swati Rashmi
 * @version 1.0
 * @since   Dec 20, 2016
 */
 
package com.bnym.rpx.throttler.service.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.bnym.rpx.throttler.service.common.AccountBalanceDataPoint;
import com.bnym.rpx.throttler.service.dao.AccountLiquidityDAO;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.AccountLiquidity;

@Repository
public class AccountLiquidityDAOImpl extends GenericDAO implements AccountLiquidityDAO {

	private static final Logger LOGGER = Logger.getLogger(AccountLiquidityDAOImpl.class);
	@Override
	public Integer findAccountByAccNo(String accountNo) throws  DAOException {
		try {
			String sql = "SELECT count(*) FROM T_GVP_THRTL_ACCT_LQDY WHERE ACCT_NO = :accountNo ";
			return getJdbcTemplate().queryForObject(sql, new Object[] { accountNo }, Integer.class);
		} catch (DataAccessException e) {
			LOGGER.error("Exception whlie calling findAccountByAccNo() for accountNo:"+ accountNo +" in AccountLiquidityDAOImpl: " + e.getMessage(), e);
			throw new DAOException("Exception: " + e.getMessage(), e);
		}		
	}

	@Override
	public List<AccountLiquidity> getAllAccounts() throws  DAOException {
		try {
			String sql = "SELECT ACCT_NO, ACCT_BR_CD ,ACCT_SRC_SYS_CD, AVL_AM FROM T_GVP_THRTL_ACCT_LQDY ORDER BY ACCT_NO";		
			return getJdbcTemplate().query(sql,	new BeanPropertyRowMapper<AccountLiquidity>(AccountLiquidity.class));		
		} catch (DataAccessException e) {
			LOGGER.error("Exception whlie calling getAllAccounts() in AccountLiquidityDAOImpl: " + e.getMessage(), e);
			throw new DAOException("Exception: " + e.getMessage(), e);
		}
	}

	@Override
	public List<AccountBalanceDataPoint> getLiquidityHistory(String accountNumber, String accountBranch,
			String sourceSystem, String valueDate) throws DAOException {
		try {
			String sql = "SELECT AVL_AM as balance, ACTL_BAL_EFF_TS as timestamp  FROM T_GVP_THRTL_ACCT_LQDY_ADT  WHERE ACCT_NO = :accountNumber AND ACCT_BR_CD = :accountBranch AND ACCT_SRC_SYS_CD = :sourceSystem AND TRUNC(VAL_DT) = :valueDate ORDER BY ACTL_BAL_EFF_TS ASC";
			SqlParameterSource namedParameters = new MapSqlParameterSource("accountNumber", accountNumber)
				    .addValue("accountBranch", accountBranch).addValue("valueDate", valueDate).addValue("sourceSystem", sourceSystem);
			
			return getNamedParameterJdbcTemplate().query(sql, namedParameters, new RowMapper<AccountBalanceDataPoint>() {
				public AccountBalanceDataPoint mapRow(ResultSet resultSet, int rowNum)
						throws SQLException {
					return new AccountBalanceDataPoint(resultSet.getString("balance"), resultSet.getString("timestamp"));
				}});
		} catch (DataAccessException e) {
			LOGGER.error("Exception whlie calling getLiquidityHistory() in AccountLiquidityDAOImpl: " + e.getMessage(), e);
			throw new DAOException("Exception: " + e.getMessage(), e);
		}
	}
	
	@Override
	public AccountBalanceDataPoint getLastLiquidity(String accountNumber, String accountBranch,
			String sourceSystem, String valueDate) throws DAOException {
		try {
			String sql = "SELECT AVL_AM as balance, ACTL_BAL_EFF_TS as timestamp FROM T_GVP_THRTL_ACCT_LQDY_ADT WHERE ACCT_NO = :accountNumber AND ACCT_BR_CD = :accountBranch AND ACCT_SRC_SYS_CD = :sourceSystem AND TRUNC(VAL_DT) < :valueDate ORDER BY ACTL_BAL_EFF_TS DESC fetch first 1 row only";
			SqlParameterSource namedParameters = new MapSqlParameterSource("accountNumber", accountNumber)
				    .addValue("accountBranch", accountBranch).addValue("valueDate", valueDate).addValue("sourceSystem", sourceSystem);
			
			return (AccountBalanceDataPoint) getNamedParameterJdbcTemplate().queryForObject(sql, namedParameters, new RowMapper<AccountBalanceDataPoint>() {
						public AccountBalanceDataPoint mapRow(ResultSet resultSet, int rowNum)
								throws SQLException {
							return new AccountBalanceDataPoint(resultSet.getString("balance"), resultSet.getString("timestamp"));
						}});
		} catch (DataAccessException e) {
			LOGGER.error("Exception whlie calling getLiquidityHistory() in AccountLiquidityDAOImpl: " + e.getMessage(), e);
			throw new DAOException("Exception: " + e.getMessage(), e);
		}
	}

}
