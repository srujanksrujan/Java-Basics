package com.bnym.rpx.throttler.service.exception;

public class NoDataFoundException extends Exception{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 7353347293879530700L;

	public NoDataFoundException(){
		super("No data found for the specific criteria");
	}
	
	public NoDataFoundException(String message){
		super(message);
	}
}
