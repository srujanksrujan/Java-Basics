/**
 * File: Transaction.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 5, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class Transaction implements Serializable{
	private static final long serialVersionUID = 1L;

	private String srcRefNo;
	private long adtVrsnNo;
	private String srcSysCd;
	private String msgRefId;
	private String acctNo;	
	private Date valDt;
	private BigDecimal amount;
	private String amountStr;
	private String ccyIsoCd;
	private Timestamp updTs;
	private String strUpdTs;
	private String procStat;
	private String procStatDesc;
	private String typeCd;
	
	public String getSrcRefNo() {
		return srcRefNo;
	}
	public void setSrcRefNo(String srcRefNo) {
		this.srcRefNo = srcRefNo;
	}
	public long getAdtVrsnNo() {
		return adtVrsnNo;
	}
	public void setAdtVrsnNo(long adtVrsnNo) {
		this.adtVrsnNo = adtVrsnNo;
	}
	public String getSrcSysCd() {
		return srcSysCd;
	}
	public void setSrcSysCd(String srcSysCd) {
		this.srcSysCd = srcSysCd;
	}
	public String getMsgRefId() {
		return msgRefId;
	}
	public void setMsgRefId(String msgRefId) {
		this.msgRefId = msgRefId;
	}
	public String getAcctNo() {
		return acctNo;
	}
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	public Date getValDt() {
		return valDt;
	}
	public void setValDt(Date valDt) {
		this.valDt = valDt;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
		if(amount !=null){
			setAmountStr(amount.toString());	
		}else {
			setAmountStr("");
		}
	}
	public String getCcyIsoCd() {
		return ccyIsoCd;
	}
	public void setCcyIsoCd(String ccyIsoCd) {
		this.ccyIsoCd = ccyIsoCd;
	}
	public Timestamp getUpdTs() {
		return updTs;
	}
	public void setUpdTs(Timestamp updTs) {
		this.updTs = updTs;
	}
	public String getProcStat() {
		return procStat;
	}
	public void setProcStat(String procStat) {
		this.procStat = procStat;
	}
	public String getTypeCd() {
		return typeCd;
	}
	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}

	public String getStrUpdTs() {
		return strUpdTs;
	}
	public void setStrUpdTs(String strUpdTs) {
		this.strUpdTs = strUpdTs;
	}
	public String getProcStatDesc() {
		return procStatDesc;
	}
	public void setProcStatDesc(String procStatDesc) {
		this.procStatDesc = procStatDesc;
	}
	public String getAmountStr() {
		return amountStr;
	}
	public void setAmountStr(String amountStr) {
		this.amountStr = amountStr;
	}
	public Transaction() {
		super();
	}
	
	@Override
	public String toString() {
		return "Transaction [srcRefNo=" + srcRefNo + ", adtVrsnNo=" + adtVrsnNo + ", srcSysCd=" + srcSysCd + ", msgRefId=" + msgRefId + ", acctNo="
				+ acctNo + ", valDt=" + valDt + ", amount=" + amount + ", amountStr=" + amountStr + ", ccyIsoCd=" + ccyIsoCd + ", updTs=" + updTs
				+ ", strUpdTs=" + strUpdTs + ", procStat=" + procStat + ", procStatDesc=" + procStatDesc + ", typeCd=" + typeCd + "]";
	}
}

