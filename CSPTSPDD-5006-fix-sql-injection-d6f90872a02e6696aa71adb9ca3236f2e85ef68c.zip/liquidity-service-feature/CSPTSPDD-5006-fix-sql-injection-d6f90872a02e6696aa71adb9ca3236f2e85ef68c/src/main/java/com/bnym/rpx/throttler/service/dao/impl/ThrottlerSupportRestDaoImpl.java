package com.bnym.rpx.throttler.service.dao.impl;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.bnym.rpx.throttler.service.dao.ThrottlerSupportRestDao;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.util.HostIdentifier;

@Repository
public class ThrottlerSupportRestDaoImpl extends GenericDAO implements ThrottlerSupportRestDao {
	private static final Logger LOGGER = Logger.getLogger(ThrottlerSupportRestDaoImpl.class);
	private static final String EXCEPTION = "Exception:";
	private static final String USER_ID = "rtp_app";
	private static final String SCH_HOSTNM = "SCH_HOSTNM";
	private static final String HZL_CONFIG = "HZL_CONFIG";

	@Autowired
	private HostIdentifier hostIdentifier;

	public int getSeqNo() throws DAOException {
		try {
			LOGGER.info("getSeqNo() called in ThrottlerHostProcDao");
			String sql = "select (MAX(SEQ_NO)+1) FROM T_GVP_THRTL_HOST_PROC";
			return getJdbcTemplate().queryForObject(sql, Integer.class);
		} catch (Exception e) {
			LOGGER.error("Exception while updating the sequence number  :" + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	public int getGvpSeqNo() throws DAOException {
		try {
			LOGGER.info("getGvpSeqNo() called in ThrottlerHostProcDao");
			String sql = "select (MAX(SEQ_NO)+1) FROM T_GVP_THRTL_CONFIG";
			return getJdbcTemplate().queryForObject(sql, Integer.class);
		} catch (Exception e) {
			LOGGER.error("Exception while updating the sequence number  :" + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public int configureCalculatorHost(String hostName, String accountNumber, String throttlerGroupId, String activeFlag,
			Timestamp currentTimestamp) throws DAOException {
		try {
			LOGGER.info("insertCalculatorHost() called in ThrotllerHostProc");
			String sql = "INSERT INTO T_GVP_THRTL_HOST_PROC (SEQ_NO,ACTV_FL,COM_NM,CRT_USR_ID,CRT_TS,UPD_USR_ID,UPD_TS,HOST_NM,ACCT_NO,THRTL_GRP_ID) VALUES (?,?,?,?,?,?,?,?,?,?)";
			return getJdbcTemplate().update(sql, getSeqNo(), activeFlag, hostIdentifier.getRegion(), USER_ID,
					currentTimestamp, USER_ID, currentTimestamp, hostName, accountNumber, throttlerGroupId);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while calling insertCalculatorHost() in ThrotllerHostProc: " + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public int configCalcHostFlag(String hostName, String accountNumber, String throttlerGroupId,
			String activeFlag, Timestamp currentTimestamp) throws DAOException {
		try {
			LOGGER.info("configCalcHostFlag() called in ThrotllerHostProc");
			// String sqlUpdateTimeStamp = "SELECT SYSTIMESTAMP FROM DUAL";
			String sql = "UPDATE T_GVP_THRTL_HOST_PROC SET ACTV_FL = ?, UPD_TS = ? WHERE  HOST_NM = ? AND ACCT_NO = ? AND THRTL_GRP_ID = ?  ";
			return getJdbcTemplate().update(sql, activeFlag, currentTimestamp, hostName, accountNumber,
					throttlerGroupId);
		} catch (DataAccessException e) {
			LOGGER.error(
					"Exception while updating the active Flag while calling configCalcHostFlag() in ThrotllerHostProc :"
							+ e.getMessage(),
					e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public int configureSchedulerHost(String hostName, String activeFlag, String comments, Timestamp currentTimestamp)
			throws DAOException {

		try {
			LOGGER.info("configureSchedulerHost() called  in ThrotllerConfiguration table");
			String sql = "INSERT INTO T_GVP_THRTL_CONFIG (SEQ_NO,FUN_NM,KEY_NM,DESC_TX,ACTV_FL,CRT_USR_ID,CRT_TS,UPD_USR_ID,UPD_TS) VALUES (?,?,?,?,?,?,?,?,?)";
			return getJdbcTemplate().update(sql, getGvpSeqNo(), SCH_HOSTNM, hostName, comments, activeFlag, USER_ID,
					currentTimestamp, USER_ID, currentTimestamp);
		} catch (DataAccessException e) {
			LOGGER.error(
					"Exception while calling configureSchedulerHost() in ThrotllerConfiguration table: " + e.getMessage(),
					e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public int configureSchedulerHostFlag(String hostName, String activeFlag, Timestamp currentTimestamp)
			throws DAOException {
		try {
			LOGGER.info("configureSchedulerHostFlag() called in ThrotllerConfiguration table ");
			String sql = "UPDATE T_GVP_THRTL_CONFIG SET ACTV_FL = ? , UPD_TS = ? WHERE KEY_NM = ? AND FUN_NM = ? ";
			return getJdbcTemplate().update(sql, activeFlag, currentTimestamp, hostName, SCH_HOSTNM);
		} catch (Exception e) {
			LOGGER.error("Exception while  calling configureSchedulerHostFlag() in ThrotllerConfiguration table:"
					+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
	
	@Override
	public int configureHazelCastConfig(String dataCentre, String hazlecastConfig, String activeFlag, String comments,
			Timestamp currentTimestamp) throws DAOException {

		try {
			LOGGER.info("configureHazelCastConfig() called  in ThrotllerConfiguration table");
			String sql = "INSERT INTO T_GVP_THRTL_CONFIG (SEQ_NO,FUN_NM,KEY_NM,VAL_NM,DESC_TX,ACTV_FL,CRT_USR_ID,CRT_TS,UPD_USR_ID,UPD_TS) VALUES (?,?,?,?,?,?,?,?,?,?)";
			return getJdbcTemplate().update(sql, getGvpSeqNo(), HZL_CONFIG, dataCentre, hazlecastConfig, comments,
					activeFlag, USER_ID, currentTimestamp, USER_ID, currentTimestamp);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while calling configureHazelCastConfig() in ThrotllerConfiguration table: "
					+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public int configHazlecastIPAddress(String dataCentre, String hazlecastConfig, Timestamp currentTimestamp)
			throws DAOException {
		try {
			LOGGER.info("configHazlecastIPAddress() called in ThrotllerConfiguration table ");
			String sql = "UPDATE T_GVP_THRTL_CONFIG SET VAL_NM = ? , UPD_TS = ? WHERE KEY_NM = ? AND FUN_NM = ? ";
			return getJdbcTemplate().update(sql, hazlecastConfig, currentTimestamp, dataCentre, HZL_CONFIG);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while  calling configHazlecastIPAddress() in ThrotllerConfiguration table:"
					+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public int configureHazelcastConfigFlag(String dataCentre, String activeFlag, Timestamp currentTimestamp)
			throws DAOException {
		try {
			LOGGER.info("configureHazelcastConfigFlag() called in ThrotllerConfiguration table ");
			String sql = "UPDATE T_GVP_THRTL_CONFIG SET ACTV_FL = ? , UPD_TS = ? WHERE KEY_NM = ? AND FUN_NM = ? ";
			return getJdbcTemplate().update(sql, activeFlag, currentTimestamp, dataCentre, HZL_CONFIG);
		} catch (DataAccessException e) {
			LOGGER.error("Exception while  calling configureHazelcastConfigFlag() in ThrotllerConfiguration table:"
					+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
	
	

}
