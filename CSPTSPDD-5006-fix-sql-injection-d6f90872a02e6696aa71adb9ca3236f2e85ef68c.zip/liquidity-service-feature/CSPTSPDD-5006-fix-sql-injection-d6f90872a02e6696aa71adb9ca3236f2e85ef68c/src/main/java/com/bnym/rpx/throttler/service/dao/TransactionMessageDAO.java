package com.bnym.rpx.throttler.service.dao;

import java.util.List;

import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.TransactionMessageDetails;

public interface TransactionMessageDAO {
	List<TransactionMessageDetails> getTranactionMessageDetails (String messageId,String paymentStatus)throws DAOException ;
}