package com.bnym.rpx.throttler.service.dao.repository;

import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.bnym.rpx.throttler.service.entity.Adjustment;
@Repository
public interface AdjustmentRepository
		extends PagingAndSortingRepository<Adjustment, String>, JpaSpecificationExecutor<Adjustment> {
}
