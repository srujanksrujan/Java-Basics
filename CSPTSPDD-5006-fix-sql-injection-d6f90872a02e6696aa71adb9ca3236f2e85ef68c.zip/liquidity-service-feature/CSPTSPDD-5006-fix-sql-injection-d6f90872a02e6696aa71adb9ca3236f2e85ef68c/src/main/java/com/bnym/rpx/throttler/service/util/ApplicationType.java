package com.bnym.rpx.throttler.service.util;

public enum ApplicationType {

	RTP("RTP", "RTP Throttler UI Application"),
	TCH("TCH", "TCH Switch UI Application"), 
	FCS("FCS", "FCS UI Application"), 
	BEX("BEX", "BEX UI Application"), 
	CXC("CXC", "CXC UI Application"),
	CLNTPRFL("CLNTPRFL", "CLNTPRFL UI Application"),
	OTHER("", "Unknown");

	private String code;
	private String description;

	ApplicationType() {
	}

	ApplicationType(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String code() {
		return (this.code != null) ? this.code : "";
	}

	public String description() {
		return (this.description != null) ? this.description : "";
	}

	public static ApplicationType value(String code) {
		if (code == null) {
			return OTHER;
		}
		for (ApplicationType event : ApplicationType.values()) {
			if (event.code().equals(code)) {
				return event;
			}
		}
		return OTHER;
	}

	public static ApplicationType valueFromDescritpion(String description) {
		if (description == null) {
			return OTHER;
		}
		for (ApplicationType event : ApplicationType.values()) {
			if (event.description().equals(description)) {
				return event;
			}
		}
		return OTHER;
	}
}