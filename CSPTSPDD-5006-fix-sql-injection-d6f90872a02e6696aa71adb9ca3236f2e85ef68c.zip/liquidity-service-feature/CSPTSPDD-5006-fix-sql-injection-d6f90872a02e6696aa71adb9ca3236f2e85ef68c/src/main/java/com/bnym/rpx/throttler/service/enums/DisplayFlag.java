package com.bnym.rpx.throttler.service.enums;

public enum DisplayFlag {

	YES("YES", 'Y'), NO("NO", 'N');

	private String name;
	private char code;

	private DisplayFlag(String name, char code) {
		this.name = name;
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public char getCode() {
		return code;
	}

	public void setCode(char code) {
		this.code = code;
	}

	public static DisplayFlag value(String name) {
		if (name == null) {
			return null;
		}
		for (DisplayFlag event : DisplayFlag.values()) {
			if (event.getName().equals(name)) {
				return event;
			}
		}
		return null;
	}

}
