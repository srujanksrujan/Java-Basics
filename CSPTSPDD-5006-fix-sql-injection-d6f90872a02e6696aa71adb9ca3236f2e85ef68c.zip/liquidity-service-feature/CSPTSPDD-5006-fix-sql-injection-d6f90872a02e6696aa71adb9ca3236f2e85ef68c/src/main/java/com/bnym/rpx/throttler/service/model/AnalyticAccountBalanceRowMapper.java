package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class AnalyticAccountBalanceRowMapper implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String acctNo;
	private Timestamp openingTime;
	private BigDecimal openingBalance;
	private Timestamp closingTime;
	private BigDecimal closingBalance;
	
	public String getAcctNo() {
		return acctNo;
	}
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	public Timestamp getOpeningTime() {
		return openingTime;
	}
	public void setOpeningTime(Timestamp openingTime) {
		this.openingTime = openingTime;
	}
	public BigDecimal getOpeningBalance() {
		return openingBalance;
	}
	public void setOpeningBalance(BigDecimal openingBalance) {
		this.openingBalance = openingBalance;
	}
	public Timestamp getClosingTime() {
		return closingTime;
	}
	public void setClosingTime(Timestamp closingTime) {
		this.closingTime = closingTime;
	}
	public BigDecimal getClosingBalance() {
		return closingBalance;
	}
	public void setClosingBalance(BigDecimal closingBalance) {
		this.closingBalance = closingBalance;
	}
	
	@Override
	public String toString() {
		return "AnalyticAccountBalance [acctNo=" + acctNo + ", openingTime=" + openingTime + ", openingBalance=" + openingBalance + ", closingTime="
				+ closingTime + ", closingBalance=" + closingBalance + "]";
	}
}