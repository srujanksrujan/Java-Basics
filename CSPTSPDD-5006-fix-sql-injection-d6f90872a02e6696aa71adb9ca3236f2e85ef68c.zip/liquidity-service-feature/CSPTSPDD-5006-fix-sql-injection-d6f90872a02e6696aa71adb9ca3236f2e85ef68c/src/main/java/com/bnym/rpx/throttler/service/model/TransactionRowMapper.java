/**
 * File: TransactionRowMapper.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 6, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class TransactionRowMapper implements RowMapper<Transaction>{


	@Override
	public Transaction mapRow(ResultSet rs, int arg1) throws SQLException {
		Transaction transaction = new Transaction();
		transaction.setAcctNo(rs.getString("ACCT_NO"));
		transaction.setAdtVrsnNo(rs.getLong("ADT_VRSN_NO"));
		transaction.setCcyIsoCd(rs.getString("CCY_ISO_CD"));
		transaction.setMsgRefId(rs.getString("MSG_REF_ID"));
		transaction.setProcStat(rs.getString("PROC_STAT"));
		transaction.setAmount(rs.getBigDecimal("AMT"));
		transaction.setSrcRefNo(rs.getString("SRC_REF_NO"));
		transaction.setSrcSysCd(rs.getString("SRC_SYS_CD"));
		transaction.setUpdTs(rs.getTimestamp("UPD_TS"));
		transaction.setStrUpdTs(rs.getString("STR_UPD_TS"));
		transaction.setValDt(rs.getDate("VAL_DT"));
		transaction.setTypeCd(rs.getString("TYPE_CD"));

		return transaction;
	}


	

}
