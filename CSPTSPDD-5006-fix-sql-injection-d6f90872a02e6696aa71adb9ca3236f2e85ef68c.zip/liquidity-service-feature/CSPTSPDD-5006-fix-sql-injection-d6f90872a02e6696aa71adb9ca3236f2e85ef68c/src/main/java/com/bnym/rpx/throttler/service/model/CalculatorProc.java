/**
 * File: CalculatorProc.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 10, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class CalculatorProc implements Serializable {

	private static final long serialVersionUID = 1L;

	private String seqNo;
	private String acctNo;
	private BigDecimal amt;
	private String bulkId;
	private String ccyIsoCd;
	private Timestamp crtTm;	
	private Timestamp crtTs;
	private String crtUsrId;
	private String inOutCd;
	private String isRqstUpdt;
	private String msgRefId;
	private BigDecimal netLiquidityChange;
	private String procStat;
	private String pyCrCd;
	private String reqTypCd;
	private String srcRefNo;
	private String srcSysCd;
	private String thrtlGrpId;
	private Timestamp updTs;
	private String updUsrId;
	private Date valDt;
	
	public String getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(String seqNo) {
		this.seqNo = seqNo;
	}
	public String getAcctNo() {
		return acctNo;
	}
	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}
	public BigDecimal getAmt() {
		return amt;
	}
	public void setAmt(BigDecimal amt) {
		this.amt = amt;
	}
	public String getBulkId() {
		return bulkId;
	}
	public void setBulkId(String bulkId) {
		this.bulkId = bulkId;
	}
	public String getCcyIsoCd() {
		return ccyIsoCd;
	}
	public void setCcyIsoCd(String ccyIsoCd) {
		this.ccyIsoCd = ccyIsoCd;
	}
	public Timestamp getCrtTm() {
		return crtTm;
	}
	public void setCrtTm(Timestamp crtTm) {
		this.crtTm = crtTm;
	}
	public Timestamp getCrtTs() {
		return crtTs;
	}
	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}
	public String getCrtUsrId() {
		return crtUsrId;
	}
	public void setCrtUsrId(String crtUsrId) {
		this.crtUsrId = crtUsrId;
	}
	public String getInOutCd() {
		return inOutCd;
	}
	public void setInOutCd(String inOutCd) {
		this.inOutCd = inOutCd;
	}
	public String getIsRqstUpdt() {
		return isRqstUpdt;
	}
	public void setIsRqstUpdt(String isRqstUpdt) {
		this.isRqstUpdt = isRqstUpdt;
	}
	public String getMsgRefId() {
		return msgRefId;
	}
	public void setMsgRefId(String msgRefId) {
		this.msgRefId = msgRefId;
	}
	public BigDecimal getNetLiquidityChange() {
		return netLiquidityChange;
	}
	public void setNetLiquidityChange(BigDecimal netLiquidityChange) {
		this.netLiquidityChange = netLiquidityChange;
	}
	public String getProcStat() {
		return procStat;
	}
	public void setProcStat(String procStat) {
		this.procStat = procStat;
	}
	public String getPyCrCd() {
		return pyCrCd;
	}
	public void setPyCrCd(String pyCrCd) {
		this.pyCrCd = pyCrCd;
	}
	public String getReqTypCd() {
		return reqTypCd;
	}
	public void setReqTypCd(String reqTypCd) {
		this.reqTypCd = reqTypCd;
	}
	public String getSrcRefNo() {
		return srcRefNo;
	}
	public void setSrcRefNo(String srcRefNo) {
		this.srcRefNo = srcRefNo;
	}
	public String getSrcSysCd() {
		return srcSysCd;
	}
	public void setSrcSysCd(String srcSysCd) {
		this.srcSysCd = srcSysCd;
	}
	public String getThrtlGrpId() {
		return thrtlGrpId;
	}
	public void setThrtlGrpId(String thrtlGrpId) {
		this.thrtlGrpId = thrtlGrpId;
	}
	public Timestamp getUpdTs() {
		return updTs;
	}
	public void setUpdTs(Timestamp updTs) {
		this.updTs = updTs;
	}
	public String getUpdUsrId() {
		return updUsrId;
	}
	public void setUpdUsrId(String updUsrId) {
		this.updUsrId = updUsrId;
	}
	public Date getValDt() {
		return valDt;
	}
	public void setValDt(Date valDt) {
		this.valDt = valDt;
	}
	
	
}
