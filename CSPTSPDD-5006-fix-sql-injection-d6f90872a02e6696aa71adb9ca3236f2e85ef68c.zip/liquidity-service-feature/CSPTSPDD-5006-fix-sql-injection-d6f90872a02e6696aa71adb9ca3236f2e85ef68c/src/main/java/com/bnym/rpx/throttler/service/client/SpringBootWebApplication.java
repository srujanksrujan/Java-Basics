package com.bnym.rpx.throttler.service.client;

import javax.annotation.PostConstruct;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
@SpringBootApplication
@ComponentScan(basePackages = "com.bnym.rpx")
@ImportResource("spring/spring-context.xml")
@Configuration
@EnableAutoConfiguration
@EnableJpaRepositories(basePackages = "com.bnym.rpx.throttler.service.dao.repository")
@PropertySource({ 
	  "${${subEnvironment}.mq.properties.file}",
	  "${${subEnvironment}.db.properties.file}",
	  "classpath:/swagger.properties"
	})
@EntityScan(basePackages={
        "com.bnym.rpx.throttler.service.entity"
})
public class SpringBootWebApplication {

	@Autowired
	DataSource dataSource;

	@Bean
	public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
	    //JpaVendorAdapteradapter can be autowired as well if it's configured in application properties.
	    HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
	    vendorAdapter.setGenerateDdl(false);

	    LocalContainerEntityManagerFactoryBean factory = new LocalContainerEntityManagerFactoryBean();
	    factory.setJpaVendorAdapter(vendorAdapter);
	    //Add package to scan for entities.
	    factory.setPackagesToScan("com.bnym.rpx.throttler.service.entity");
	    factory.setDataSource(dataSource);
	    return factory;
	}

	
	@Value(value = "${subEnvironment}")
	private String subEnvironment;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebApplication.class, args);
	}

	@PostConstruct
	public void init() throws IllegalStateException, NamingException {
		System.setProperty("subEnvironment", subEnvironment);
	}
}
