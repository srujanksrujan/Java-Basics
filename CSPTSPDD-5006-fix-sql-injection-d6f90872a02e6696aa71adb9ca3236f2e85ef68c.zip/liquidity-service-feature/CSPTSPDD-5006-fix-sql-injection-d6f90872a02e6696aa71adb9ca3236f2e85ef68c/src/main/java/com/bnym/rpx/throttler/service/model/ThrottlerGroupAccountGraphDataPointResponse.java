package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.util.List;

import com.bnym.rpx.throttler.service.common.AccountBalanceDataPoint;

public class ThrottlerGroupAccountGraphDataPointResponse implements Serializable {

	private static final long serialVersionUID = -3915270338389167965L;

	private ResponseMetadata respMetadata;
	String accountNumber;
	String valueDate;
	private List<AccountBalanceDataPoint> accountBalanceDataPointList;

	public ThrottlerGroupAccountGraphDataPointResponse(String accountNumber, String valueDate,
			List<AccountBalanceDataPoint> accountBalanceDataPointList) {
		super();
		this.accountNumber = accountNumber;
		this.valueDate = valueDate;
		this.accountBalanceDataPointList = accountBalanceDataPointList;
	}

	public ResponseMetadata getRespMetadata() {
		return respMetadata;
	}

	public void setRespMetadata(ResponseMetadata respMetadata) {
		this.respMetadata = respMetadata;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getValueDate() {
		return valueDate;
	}

	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}

	public List<AccountBalanceDataPoint> getAccountBalanceDataPointList() {
		return accountBalanceDataPointList;
	}

	public void setAccountBalanceDataPointList(List<AccountBalanceDataPoint> accountBalanceDataPointList) {
		this.accountBalanceDataPointList = accountBalanceDataPointList;
	}

	@Override
	public String toString() {
		return "ThrottlerGroupAccountGraphDataPointResponse [respMetadata=" + respMetadata + ", accountNumber=" + accountNumber + ", valueDate="
				+ valueDate + ", accountBalanceDataPointList=" + accountBalanceDataPointList + "]";
	}
}
