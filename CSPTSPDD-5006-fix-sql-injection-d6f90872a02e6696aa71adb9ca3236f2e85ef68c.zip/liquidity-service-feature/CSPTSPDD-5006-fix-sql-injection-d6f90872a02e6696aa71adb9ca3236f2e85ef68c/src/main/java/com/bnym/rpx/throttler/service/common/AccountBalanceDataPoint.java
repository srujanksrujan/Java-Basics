package com.bnym.rpx.throttler.service.common;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class AccountBalanceDataPoint implements Serializable {

	private static final long serialVersionUID = -3915270338389167965L;

	private String balance;
	private String timestamp;
	
	public AccountBalanceDataPoint(String balance, String timestamp) {
		super();
		this.balance = balance;
		this.timestamp = timestamp;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	@Override
	public String toString() {
		return "AccountBalanceDataPoint [balance=" + balance + ", timestamp="
				+ timestamp + "]";
	}
	@JsonIgnore
	public String getTime() {
		return timestamp.substring(11, 16);
	}
}