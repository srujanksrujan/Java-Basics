/**
 * Description
 *
 * @author  Swati Rashmi
 * @version 1.0
 * @since   Dec 13, 2016
 */
package com.bnym.rpx.throttler.service.handler;

import java.text.ParseException;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.bnym.rpx.throttler.service.builder.AdjustmentBuilder;
import com.bnym.rpx.throttler.service.common.ApplicationConstants.AdjustmentDecisionCodes;
import com.bnym.rpx.throttler.service.dao.repository.AdjustmentRepository;
import com.bnym.rpx.throttler.service.dao.spec.AdjustmentSpecification;
import com.bnym.rpx.throttler.service.dao.spec.SearchCriteria;
import com.bnym.rpx.throttler.service.entity.Adjustment;
import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.AdjustmentInputRequest;
import com.bnym.rpx.throttler.service.model.AdjustmentRequest;
import com.bnym.rpx.throttler.service.oxm.CalculatorTopic;

@Service
public class AdjustmentHandler {

	private static final Logger LOGGER = Logger.getLogger(AdjustmentHandler.class);

	@Autowired
	private AdjustmentRepository adjustmentRepository;
	
	private AdjustmentBuilder adjustmentBuilder;

	public AdjustmentBuilder getAdjustmentBuilder() {
		return adjustmentBuilder;
	}

	@Autowired
	public void setAdjustmentBuilder(AdjustmentBuilder adjustmentBuilder) {
		this.adjustmentBuilder = adjustmentBuilder;
	}

	private MessageHandler messageHandler;

	public MessageHandler getMessageHandler() {
		return messageHandler;
	}

	@Autowired
	public void setMessageHandler(MessageHandler messageHandler) {
		this.messageHandler = messageHandler;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false, rollbackFor = { Exception.class })
	public APIResponse updateAdjustment(String adjustmentId, AdjustmentRequest adjustmentReq)
			throws ApplicationException {
		APIResponse response = null;
		try {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("updateAdjustment() called in AdjustmentHandler :");
			}
			response = adjustmentBuilder.buildUpdateAdjustmentResponse(adjustmentId, adjustmentReq);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return response;
	}

	public APIResponse approveAdjustment(AdjustmentRequest adjustmentReq, String adjustmentId, String action)
			throws ApplicationException {
		APIResponse response = null;
		try {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("approveAdjustment() called in AdjustmentHandler :");
			}

			if (action == null || action.trim().isEmpty()) {
				LOGGER.error("Mandatory parameter action is missing!");
				throw new ApplicationException("Mandatory parameter action is missing!");
			}
			response = persistAdjustmentEntities(adjustmentReq, adjustmentId, action);
			Adjustment adj = (Adjustment) response.getResult().getResultList().get(0);

			if (adj != null && action.equalsIgnoreCase(AdjustmentDecisionCodes.APPROVED.getCode())) {
				// For APPROVE post message to Calculator Topic
				CalculatorTopic topic = new CalculatorTopic();
				topic.setAccountNumber(adj.getAcctNo());
				topic.setThrottlerGroupID(adj.getThrtlGrpId());
				messageHandler.postMessageToTopic(topic);
				LOGGER.info("MESSAGE SENT ON CALCULATOR TOPIC:" + topic);
			}
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return response;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false, rollbackFor = { Exception.class })
	public APIResponse persistAdjustmentEntities(AdjustmentRequest adjustmentReq, String adjustmentId, String action)
			throws ApplicationException {
		try {
			return adjustmentBuilder.buildApproveAdjustmentResponse(adjustmentReq, adjustmentId, action);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = false, rollbackFor = { Exception.class })
	public APIResponse createAdjustment(AdjustmentRequest adjustmentReq) throws ParseException, ApplicationException {
		APIResponse response = null;
		try {
			response = adjustmentBuilder.buildCreateAdjustmentResponse(adjustmentReq);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return response;
	}

	public APIResponse readAdjustment(String adjustmentId) throws ApplicationException {
		APIResponse response = null;
		try {
			response = adjustmentBuilder.buildReadAdjustmentResponse(adjustmentId);
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return response;
	}

	public Page<Adjustment> readAllAdjustment(AdjustmentInputRequest adjustmentRequest, Pageable pageRequest)
			throws ApplicationException {
		try {
			Specification<Adjustment> specification = null;

			if (!StringUtils.isEmpty(adjustmentRequest.getAccountNo())) {
				AdjustmentSpecification spec = new AdjustmentSpecification(new SearchCriteria("acctNo", "==", adjustmentRequest.getAccountNo()));
				specification = Specification.where(spec);
			}
			if (adjustmentRequest.getFrmValueDate() != null) {
				AdjustmentSpecification spec = new AdjustmentSpecification(new SearchCriteria("valDt", ">=", adjustmentRequest.getFrmValueDate()));
				specification = (specification != null) ? specification.and(spec) : Specification.where(spec);
			}

			if (adjustmentRequest.getToValueDate() != null) {
				AdjustmentSpecification spec = new AdjustmentSpecification(new SearchCriteria("valDt", "<=", adjustmentRequest.getToValueDate()));
				specification = (specification != null) ? specification.and(spec) : Specification.where(spec);
			}
			
			if (adjustmentRequest.getFrmAmount() != null) {
				AdjustmentSpecification spec = new AdjustmentSpecification(new SearchCriteria("pyAmt", ">=", adjustmentRequest.getFrmAmount()));
				specification = (specification != null) ? specification.and(spec) : Specification.where(spec);
			}
			
			if (adjustmentRequest.getToAmount() != null) {
				AdjustmentSpecification spec = new AdjustmentSpecification(new SearchCriteria("pyAmt", "<=", adjustmentRequest.getToAmount()));
				specification = (specification != null) ? specification.and(spec) : Specification.where(spec);
			}
			
			if (adjustmentRequest.getStatus() != null) {
				AdjustmentSpecification spec = new AdjustmentSpecification(new SearchCriteria("aprvDcsnCd", "==", adjustmentRequest.getStatus()));
				specification = (specification != null) ? specification.and(spec) : Specification.where(spec);
			}
			
			AdjustmentSpecification inSpec = new AdjustmentSpecification(new SearchCriteria("adjInOutCd", "==", "I"));
			AdjustmentSpecification outSpec = new AdjustmentSpecification(new SearchCriteria("adjInOutCd", "==", "O"));
			if (adjustmentRequest.getInAdjusted() != null && adjustmentRequest.getOutAdjusted() != null) {
				specification = (specification != null) ? specification.and(inSpec).or(outSpec) : Specification.where(inSpec).or(outSpec);
			} else if (adjustmentRequest.getInAdjusted() == null && adjustmentRequest.getOutAdjusted() != null) {
				specification = (specification != null) ? specification.and(outSpec) : Specification.where(outSpec);
			} else if (adjustmentRequest.getInAdjusted() != null && adjustmentRequest.getOutAdjusted() == null) {
				specification = (specification != null) ? specification.and(inSpec) : Specification.where(inSpec);
			}
			
			return (specification == null) ? adjustmentRepository.findAll(pageRequest)
					: adjustmentRepository.findAll(specification, pageRequest);
			
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}

}
