package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.util.List;

public class ThrottlerGroupBalanceResponse implements Serializable {

	private static final long serialVersionUID = -3915270338389167965L;

	private ResponseMetadata respMetadata;
	private List<ThrottlerGroup> throttlerGroups;

	public ResponseMetadata getRespMetadata() {
		return respMetadata;
	}

	public void setRespMetadata(ResponseMetadata respMetadata) {
		this.respMetadata = respMetadata;
	}

	public List<ThrottlerGroup> getThrottlerGroups() {
		return throttlerGroups;
	}

	public void setThrottlerGroups(List<ThrottlerGroup> throttlerGroups) {
		this.throttlerGroups = throttlerGroups;
	}
}
