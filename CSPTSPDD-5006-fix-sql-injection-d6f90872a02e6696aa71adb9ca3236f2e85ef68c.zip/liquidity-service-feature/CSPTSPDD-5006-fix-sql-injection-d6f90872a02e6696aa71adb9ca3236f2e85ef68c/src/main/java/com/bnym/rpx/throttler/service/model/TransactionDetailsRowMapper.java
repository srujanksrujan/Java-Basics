/**
 * File: TransactionDetailsRowMapper.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 17, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class TransactionDetailsRowMapper implements RowMapper<TransactionDetails>{


	@Override
	public TransactionDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		TransactionDetails tranDetails = new TransactionDetails();
		tranDetails.setTranType(rs.getString("TRAN_TYPE"));
		tranDetails.setAcctCat(rs.getString("ACCT_CAT"));
		tranDetails.setAcctNo(rs.getString("ACCT_NO"));
		tranDetails.setAcctTypCd(rs.getString("ACCT_TYP_CD"));
		tranDetails.setAdtVrsnNo(rs.getLong("ADT_VRSN_NO"));
		tranDetails.setBaseAmt(rs.getBigDecimal("BASE_AMT"));
		tranDetails.setBaseCcyCd(rs.getString("BASE_CCY_CD"));
		tranDetails.setBaseFxRate(rs.getBigDecimal("BASE_FX_RATE"));
		tranDetails.setBulkId(rs.getString("BULK_ID"));
		tranDetails.setCcyIsoCd(rs.getString("CCY_ISO_CD"));
		tranDetails.setCrtTm(rs.getTimestamp("CRT_TM"));
		tranDetails.setCrtTs(rs.getTimestamp("CRT_TS"));
		tranDetails.setCrtUsrId(rs.getString("CRT_USR_ID"));
		tranDetails.setDbCrCd(rs.getString("DB_CR_CD"));
		tranDetails.setDomainNm(rs.getString("DOMAIN_NM"));
		tranDetails.setFxRt(rs.getBigDecimal("FX_RT"));
		tranDetails.setGrpBrId(rs.getString("GRP_BR_ID"));
		tranDetails.setGrpOffId(rs.getString("GRP_OFF_ID"));
		tranDetails.setGrpRefId(rs.getString("GRP_REF_ID"));
		tranDetails.setInstrAmt(rs.getBigDecimal("INSTR_AMT"));
		tranDetails.setInstrCcyCd(rs.getString("INSTR_CCY_CD"));
		tranDetails.setIntrDirCd(rs.getString("INTR_DIR_CD"));
		tranDetails.setIntrTypCd(rs.getString("INTR_TYP_CD"));
		tranDetails.setMsgBrId(rs.getString("MSG_BR_ID"));
		tranDetails.setMsgCnt(rs.getBigDecimal("MSG_CNT"));
		tranDetails.setMsgOffId(rs.getString("MSG_OFF_ID"));
		tranDetails.setMsgRefId(rs.getString("MSG_REF_ID"));
		tranDetails.setOrigRefId(rs.getString("ORIG_REF_ID"));
		tranDetails.setPostEntrTyp(rs.getString("POST_ENTR_TYP"));
		tranDetails.setPostOvrCd(rs.getString("POST_OVR_CD"));
		tranDetails.setProcStat(rs.getString("PROC_STAT"));
		tranDetails.setReqTypCd(rs.getString("REQ_TYP_CD"));
		tranDetails.setRsvId(rs.getString("RSV_ID"));
		tranDetails.setSrcRefNo(rs.getString("SRC_REF_NO"));
		tranDetails.setSrcSysCd(rs.getString("SRC_SYS_CD"));
		tranDetails.setThrtlGrpId(rs.getString("THRTL_GRP_ID"));
		tranDetails.setTranAmt(rs.getBigDecimal("AMT"));
		tranDetails.setTrnNarr(rs.getString("TRN_NARR"));		
		tranDetails.setUpdTs(rs.getTimestamp("UPD_TS"));
		tranDetails.setUpdUsrId(rs.getString("UPD_USR_ID"));
		tranDetails.setValDt(rs.getDate("VAL_DT"));
		tranDetails.setVrsnNo(rs.getBigDecimal("VRSN_NO"));
		tranDetails.setStrCrtTm(rs.getString("STR_CRT_TM"));
		tranDetails.setStrCrtTs(rs.getString("STR_CRT_TS"));
		tranDetails.setStrUpdTs(rs.getString("STR_UPD_TS"));
		
		return tranDetails;
	}
}
