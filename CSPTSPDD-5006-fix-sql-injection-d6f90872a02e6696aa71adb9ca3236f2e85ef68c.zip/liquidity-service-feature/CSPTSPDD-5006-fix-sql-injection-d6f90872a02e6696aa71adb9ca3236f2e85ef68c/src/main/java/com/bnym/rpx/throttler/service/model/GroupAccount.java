package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * The persistent class for the T_GVP_THRTL_GRP_ACCT database table.
 * 
 */

public class GroupAccount implements Serializable {
	private static final long serialVersionUID = 1L;


	private String thrtlGrpId;
	private String acctNo;
	private String acctBrCd;
	private String acctSrcSysCd;
	private String aprvDcsnCd;
	private Timestamp aprvTs;
	private String aprvUsrId;
	private String cmntTx;
	private Timestamp crtTs;
	private String dsplFl;
	private String lqmCrtUsrId;
	private Timestamp setUpTs;
	private String setUpUsrId;
	private String statCd;
	private Timestamp updTs;
	private String updUsrId;


	public String getThrtlGrpId() {
		return thrtlGrpId;
	}


	public void setThrtlGrpId(String thrtlGrpId) {
		this.thrtlGrpId = thrtlGrpId;
	}


	public String getAcctNo() {
		return acctNo;
	}


	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}


	public String getAcctBrCd() {
		return this.acctBrCd;
	}

	public void setAcctBrCd(String acctBrCd) {
		this.acctBrCd = acctBrCd;
	}

	public String getAcctSrcSysCd() {
		return this.acctSrcSysCd;
	}

	public void setAcctSrcSysCd(String acctSrcSysCd) {
		this.acctSrcSysCd = acctSrcSysCd;
	}

	public String getAprvDcsnCd() {
		return this.aprvDcsnCd;
	}

	public void setAprvDcsnCd(String aprvDcsnCd) {
		this.aprvDcsnCd = aprvDcsnCd;
	}

	public Timestamp getAprvTs() {
		return this.aprvTs;
	}

	public void setAprvTs(Timestamp aprvTs) {
		this.aprvTs = aprvTs;
	}

	public String getAprvUsrId() {
		return this.aprvUsrId;
	}

	public void setAprvUsrId(String aprvUsrId) {
		this.aprvUsrId = aprvUsrId;
	}

	public String getCmntTx() {
		return this.cmntTx;
	}

	public void setCmntTx(String cmntTx) {
		this.cmntTx = cmntTx;
	}

	public Timestamp getCrtTs() {
		return this.crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getDsplFl() {
		return this.dsplFl;
	}

	public void setDsplFl(String dsplFl) {
		this.dsplFl = dsplFl;
	}

	public String getLqmCrtUsrId() {
		return this.lqmCrtUsrId;
	}

	public void setLqmCrtUsrId(String lqmCrtUsrId) {
		this.lqmCrtUsrId = lqmCrtUsrId;
	}

	public Timestamp getSetUpTs() {
		return this.setUpTs;
	}

	public void setSetUpTs(Timestamp setUpTs) {
		this.setUpTs = setUpTs;
	}

	public String getSetUpUsrId() {
		return this.setUpUsrId;
	}

	public void setSetUpUsrId(String setUpUsrId) {
		this.setUpUsrId = setUpUsrId;
	}

	public String getStatCd() {
		return this.statCd;
	}

	public void setStatCd(String statCd) {
		this.statCd = statCd;
	}

	public Timestamp getUpdTs() {
		return this.updTs;
	}

	public void setUpdTs(Timestamp updTs) {
		this.updTs = updTs;
	}

	public String getUpdUsrId() {
		return this.updUsrId;
	}

	public void setUpdUsrId(String updUsrId) {
		this.updUsrId = updUsrId;
	}


	@Override
	public String toString() {
		return "GroupAccount [thrtlGrpId=" + thrtlGrpId + ", acctNo=" + acctNo + ", acctBrCd=" + acctBrCd
				+ ", acctSrcSysCd=" + acctSrcSysCd + ", aprvDcsnCd=" + aprvDcsnCd + ", aprvTs=" + aprvTs
				+ ", aprvUsrId=" + aprvUsrId + ", cmntTx=" + cmntTx + ", crtTs=" + crtTs + ", dsplFl=" + dsplFl
				+ ", lqmCrtUsrId=" + lqmCrtUsrId + ", setUpTs=" + setUpTs + ", setUpUsrId=" + setUpUsrId + ", statCd="
				+ statCd + ", updTs=" + updTs + ", updUsrId=" + updUsrId + "]";
	}
	
	
	

}