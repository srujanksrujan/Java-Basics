/**
 * File: GroupAccount.java
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").
 * Since: Dec 20, 2016
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.dao;

import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.GroupAccount;


public interface GroupAccountDAO {

	GroupAccount getGrpAcctInfo(String accountNo) throws DAOException;
}
