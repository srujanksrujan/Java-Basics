            package com.bnym.rpx.throttler.service.builder;

import java.sql.Timestamp;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnym.rpx.throttler.service.common.ApplicationConstants;
import com.bnym.rpx.throttler.service.common.ApplicationConstants.AdjustmentDecisionCodes;
import com.bnym.rpx.throttler.service.dao.impl.AdjustmentAuditDAOImpl;
import com.bnym.rpx.throttler.service.dao.impl.AdjustmentDAOImpl;
import com.bnym.rpx.throttler.service.dao.impl.CalculatorProcDAOImpl;
import com.bnym.rpx.throttler.service.dao.repository.AdjustmentRepository;
import com.bnym.rpx.throttler.service.entity.Adjustment;
import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.AdjustmentRequest;
import com.bnym.rpx.throttler.service.model.CalculatorProc;
import com.bnym.rpx.throttler.service.model.GroupAccount;
import com.bnym.rpx.throttler.service.model.Result;
import com.bnym.rpx.throttler.service.util.DateUtil;
import com.bnym.rpx.throttler.service.util.PaymentEnricher;
import com.bnym.rpx.throttler.service.validator.AdjustmentValidator;

@Component
public class AdjustmentBuilder {


	private static final Logger LOGGER = Logger.getLogger(AdjustmentBuilder.class);
	private static final String NOTIFY = "NOTIFY" ;
	
	private AdjustmentValidator adjustmentValidator;
	
	@Autowired
	AdjustmentRepository adjustmentReader;
	
	public AdjustmentValidator getAdjustmentValidator() {
		return adjustmentValidator;
	}

	@Autowired
	public void setAdjustmentValidator(AdjustmentValidator adjustmentValidator) {
		this.adjustmentValidator = adjustmentValidator;
	}
	

	private PaymentEnricher enricher;
	
	public PaymentEnricher getEnricher() {
		return enricher;
	}

	@Autowired
	public void setEnricher(PaymentEnricher enricher) {
		this.enricher = enricher;
	}
	
	
	private AdjustmentDAOImpl adjustmentDaoImpl;

	public AdjustmentDAOImpl getAdjustmentDaoImpl() {
		return adjustmentDaoImpl;
	}

	@Autowired
	public void setAdjustmentDaoImpl(AdjustmentDAOImpl adjustmentDaoImpl) {
		this.adjustmentDaoImpl = adjustmentDaoImpl;
	}
	
	
	private AdjustmentAuditDAOImpl adjustmentAuditDaoImpl;

	public AdjustmentAuditDAOImpl getAdjustmentAuditDaoImpl() {
		return adjustmentAuditDaoImpl;
	}

	@Autowired
	public void setAdjustmentAuditDaoImpl(AdjustmentAuditDAOImpl adjustmentAuditDaoImpl) {
		this.adjustmentAuditDaoImpl = adjustmentAuditDaoImpl;
	}
	
	
	private CalculatorProcDAOImpl calculatorProcDAOImpl;

	public CalculatorProcDAOImpl getCalculatorProcDAOImpl() {
		return calculatorProcDAOImpl;
	}

	@Autowired
	public void setCalculatorProcDAOImpl(CalculatorProcDAOImpl calculatorProcDAOImpl) {
		this.calculatorProcDAOImpl = calculatorProcDAOImpl;
	}


	public  APIResponse buildUpdateAdjustmentResponse(String adjustmentId,AdjustmentRequest adjustmentReq) throws DAOException, ParseException, ApplicationException  {

		LOGGER.info("buildUpdateAdjustmentResponse() called in AdjustmentBuilder :" );
		int adjRowCreated = 0;
		int adjRowUpdated = 0;
		int auditRowCreated = 0;
		Adjustment adjustment= adjustmentReader.findById(adjustmentId).get();

		if (adjustment == null){
			LOGGER.info("No Adjustment record exists with adjustmentId:"+ adjustmentId);
			adjustment= createNewAdjustmentRecord(adjustmentReq);		
			LOGGER.info("New Adjustment Object created: " +adjustment);
			adjustmentReader.save(adjustment);
		}
		else{
			LOGGER.info("Updating Adjustment record with adjustmentId:"+ adjustmentId);
			adjustment = createUpdateAdjustmentRecord(adjustmentId,adjustment,adjustmentReq,null);
			adjustmentReader.save(adjustment);
		}

		//Insert into Audit table
		auditRowCreated = adjustmentAuditDaoImpl.insertAdjustmentAudit(adjustment);


		LOGGER.info("Adjustment rows inserted: " + adjRowCreated +"|Adjustment rows updated: " + adjRowUpdated
				+ "|Audit Rows inserted:" + auditRowCreated );

		//

		List < Adjustment> adjResponseList= new ArrayList<>();
		adjResponseList.add(adjustment);
		APIResponse apiResponse = new APIResponse();
		apiResponse.setResult(new Result(new ArrayList<Object>(adjResponseList)));

		return apiResponse;

	}

	public APIResponse buildApproveAdjustmentResponse(AdjustmentRequest adjustmentReq,String adjustmentId, String action) throws DAOException, ParseException, ApplicationException  {

		LOGGER.info("buildApproveAdjustmentResponse() called in AdjustmentBuilder :" );

		int adjRowUpdated = 0;
		int auditRowCreated = 0;

		Adjustment adjustment= adjustmentReader.findById(adjustmentId).get();
		APIResponse apiResponse = new APIResponse();
		
		if (adjustment == null){
			throw new ApplicationException("NO_RECORD FOUND FOR ADJUSTMENT_ID : " + adjustmentId);
		}
		else{
			LOGGER.info("Approve/Reject Adjustment record with adjustmentId:"+ adjustmentId);
			adjustment = createUpdateAdjustmentRecord(adjustmentId,adjustment,adjustmentReq,action);
			adjustmentReader.save(adjustment);
		}

		//Insert into Audit table
		auditRowCreated = adjustmentAuditDaoImpl.insertAdjustmentAudit(adjustment);
		LOGGER.info("Adjustment rows updated: " + adjRowUpdated + "Audit Rows inserted:" + auditRowCreated );

		//For APPROVE action insert record into CAL_PROC table
		if (action != null && action.equalsIgnoreCase(AdjustmentDecisionCodes.APPROVED.getCode())){
			CalculatorProc calRec = buildCalculatorRecord(adjustment);
			int calRowsInserted = calculatorProcDAOImpl.insertCalProcRecord(calRec);
			LOGGER.info("Calculator Rows inserted:" + calRowsInserted);
		}

		List < Adjustment> adjResponseList= new ArrayList<>();
		adjResponseList.add(adjustment);
	
		apiResponse.setResult(new Result(new ArrayList<Object>(adjResponseList)));

		return apiResponse;

	}

	private CalculatorProc buildCalculatorRecord(Adjustment adjustment) throws DAOException, ApplicationException{
		LOGGER.info("buildCalculatorRecord() called in AdjustmentBuilder");

		CalculatorProc calRec = new CalculatorProc();
		
		calRec.setSeqNo(calculatorProcDAOImpl.getCalProcSeqNo());//SQL function to be called
		calRec.setBulkId(null);
		calRec.setThrtlGrpId(adjustment.getThrtlGrpId());
		calRec.setSrcRefNo(adjustment.getAdjId());		
		calRec.setSrcSysCd("RTP");
		calRec.setReqTypCd("ADJUSTMENT");
		calRec.setProcStat(NOTIFY);
		calRec.setMsgRefId(calculatorProcDAOImpl.getMessageId());
		calRec.setCrtTm(adjustment.getCrtTs());
		calRec.setCcyIsoCd("USD"); 
		calRec.setAmt(adjustment.getPyAmt());
		calRec.setValDt(adjustment.getValDt());
		calRec.setAcctNo(adjustment.getAcctNo());
		calRec.setInOutCd(adjustment.getAdjInOutCd());
		calRec.setPyCrCd("A");
		calRec.setCrtUsrId("THRTL-AD");
		
		Timestamp currentTS = enricher.getSystemTimestamp();
		calRec.setCrtTs(currentTS);
		calRec.setUpdTs(currentTS);
		
		calRec.setUpdUsrId("THRTL-AD");
		calRec.setIsRqstUpdt(null);		
		calRec.setNetLiquidityChange(null);
	
		return calRec;

	}

	private Adjustment createUpdateAdjustmentRecord(String adjustmentId,Adjustment adjustment,AdjustmentRequest adjustmentReq, String action ) throws DAOException, ParseException, ApplicationException {

		LOGGER.info("updateAdjustmentRecord() called in AdjustmentBuilder. Action :" + action );
		Timestamp currentTS = enricher.getSystemTimestamp();

		//Validate accountNo
		String accountNo = adjustment.getAcctNo();		
		boolean isAccountValid= adjustmentValidator.validateAccountNo(accountNo);

		LOGGER.info("Account No: " + "accountNo is valid: " + isAccountValid);

		if (isAccountValid){
			//if update 
			if (action == null ){

				//set the values recieved from UI
				adjustment.setAcctNo(accountNo);
				adjustment.setAcctBrCd(adjustmentReq.getAccountBranch());
				adjustment.setPyAmt(adjustmentReq.getAmount());
				adjustment.setAdjInOutCd(adjustmentReq.getSign());
				adjustment.setValDt(DateUtil.getParsedSQLDate(adjustmentReq.getValueDate()));
				adjustment.setProcStat(NOTIFY); 			
				adjustment.setAdjRsnTx(adjustmentReq.getAdjustmentResason());
				adjustment.setCmntTx(adjustmentReq.getComment());
				adjustment.setUpdUsrId(adjustmentReq.getUserId());				
				adjustment.setUpdTs(currentTS);
		
				//get new AuditVersionNo
				adjustment.setAdtVrsnNo(enricher.getCurrentAuditVersionNo(adjustmentId));					
			
				//update adjustment approve decision code to PENDING_APPROVAL in case of update
				adjustment.setAprvDcsnCd(ApplicationConstants.AdjustmentDecisionCodes.PENDING_APPROVAL.getCode());	
				adjustment.setAprvUsrId(null);
				adjustment.setAprvTs(null);
				
			}

			// If approve/reject request
			else{
				//get new AuditVersionNo
				adjustment.setAdtVrsnNo(enricher.getCurrentAuditVersionNo(adjustmentId));
				//action code : approve/reject 
				adjustment.setAprvDcsnCd(action);
				adjustment.setAprvUsrId(adjustmentReq.getUserId());
				adjustment.setAprvTs(currentTS);	
				adjustment.setUpdUsrId(adjustmentReq.getUserId());
				adjustment.setUpdTs(currentTS);
				adjustment.setAdjRsnTx(adjustmentReq.getAdjustmentResason());
				adjustment.setCmntTx(adjustmentReq.getComment());
			}
		}else{
			throw new ApplicationException("Exception while creating Adjustment- Invalid Account No: " + accountNo);
		}
		LOGGER.info("Adjustment Object created: " +adjustment);
		return adjustment;

	}


	public  APIResponse buildCreateAdjustmentResponse(AdjustmentRequest adjustmentReq) throws DAOException, ParseException, ApplicationException {

		LOGGER.info("buildCreateAdjustmentResponse() called in AdjustmentBuilder :" );
		APIResponse apiResponse = new APIResponse();

		Adjustment adjustment= createNewAdjustmentRecord(adjustmentReq);

		if (adjustment != null){
			adjustmentReader.save(adjustment);
			adjustmentAuditDaoImpl.insertAdjustmentAudit(adjustment);

			List < Adjustment> adjResponseList= new ArrayList<>();
			adjResponseList.add(adjustment);
			apiResponse.setResult(new Result(new ArrayList<Object>(adjResponseList)));
		}			

		return apiResponse;

	}




	public  Adjustment createNewAdjustmentRecord(AdjustmentRequest adjustmentReq) throws DAOException, ParseException, ApplicationException{

		LOGGER.info("createAdjustmentRecord() called in AdjustmentBuilder :" );

		Adjustment adjustment = null;
		String adjId= null;
		Timestamp currentTS = null;

		//Validate accountNo
		String accountNo = adjustmentReq.getAccountNo();		
		boolean isAccountValid= adjustmentValidator.validateAccountNo(accountNo);

		LOGGER.info("Account No: " + "accountNo is valid: " + isAccountValid);
		if (isAccountValid){	
			adjustment = new Adjustment();

			//set the values recieved from UI
			adjustment.setAcctNo(accountNo);
			adjustment.setAcctBrCd(adjustmentReq.getAccountBranch());
			adjustment.setPyAmt(adjustmentReq.getAmount());
			adjustment.setAdjInOutCd(adjustmentReq.getSign());
			adjustment.setValDt(DateUtil.getParsedSQLDate(adjustmentReq.getValueDate()));
			adjustment.setProcStat(NOTIFY); // TBD
			adjustment.setAprvDcsnCd(adjustmentReq.getAprvDcsnCd());
			adjustment.setCrtUsrId(adjustmentReq.getUserId());
			adjustment.setAdjRsnTx(adjustmentReq.getAdjustmentResason());
			adjustment.setCmntTx(adjustmentReq.getComment());
			adjustment.setUpdUsrId(adjustmentReq.getUserId());

			//Enrich adjustment with other Info
			adjId= enricher.getAdjustmentId();
			adjustment.setAdjId(adjId);
			GroupAccount grpAcct = enricher.getGrpAcctInfo(accountNo);
			if ( grpAcct != null){
				adjustment.setThrtlGrpId(grpAcct.getThrtlGrpId());
				adjustment.setAcctSrcSysCd(grpAcct.getAcctSrcSysCd());
			}
			adjustment.setAdtVrsnNo(enricher.getCurrentAuditVersionNo(adjId));
			currentTS =  enricher.getSystemTimestamp();
			adjustment.setCrtTs(currentTS);
			adjustment.setUpdTs(currentTS);
			
			//set default values as null
			adjustment.setAprvUsrId(null);
			adjustment.setAprvTs(null);
			

		}else{
			throw new ApplicationException("Exception while creating Adjustment- Invalid Account No: " + accountNo);
		}

		return adjustment;



	}

	public APIResponse buildReadAdjustmentResponse(String adjustmentId) throws DAOException, ApplicationException  {

		LOGGER.info("buildReadAdjustmentResponse() called in AdjustmentBuilder  for adjustmentId:" + adjustmentId );
		Adjustment adjustment;
		try {
			adjustment = adjustmentReader.findById(adjustmentId).get();
		} catch (NoSuchElementException ex) {
			throw new ApplicationException("NO_RECORD FOUND FOR ADJUSTMENT_ID : " + adjustmentId);
		}
 
		List < Adjustment> adjResponseList= new ArrayList<>();
		adjResponseList.add(adjustment);
		APIResponse apiResponse = new APIResponse();
		apiResponse.setResult(new Result(new ArrayList<Object>(adjResponseList)));
		return apiResponse;

	}


}
