package com.bnym.rpx.throttler.service.builder;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnym.rpx.throttler.service.dao.impl.AnalyticsBalanceDAOImpl;
import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.AnalyticAccountBalance;
import com.bnym.rpx.throttler.service.model.AnalyticAccountBalanceRowMapper;
import com.bnym.rpx.throttler.service.model.Result;
import com.bnym.rpx.throttler.service.util.DateUtil;

@Component
public class AnalyticsBalanceBuilder {
	private static final Logger LOGGER = Logger.getLogger(AnalyticsBalanceBuilder.class);

	private AnalyticsBalanceDAOImpl analyticsBalanceDAOImpl;
	
	public AnalyticsBalanceDAOImpl getAnalyticsBalanceDAOImpl() {
		return analyticsBalanceDAOImpl;
	}

	@Autowired
	public void setAnalyticsBalanceDAOImpl(AnalyticsBalanceDAOImpl analyticsBalanceDAOImpl) {
		this.analyticsBalanceDAOImpl = analyticsBalanceDAOImpl;
	}

	public APIResponse getAnalyticsBalance(String valueDate, String accountNumber) throws ApplicationException {
		
		try{
			LOGGER.info("buildReadTransactionResponse() called in AnalyticsBalanceBuilder  for valueDate:" + valueDate+" accountNumber:" + accountNumber);
			
			List<AnalyticAccountBalanceRowMapper> analyticAccountBalanceRowMapperList = analyticsBalanceDAOImpl.getAnalyticsBalance(valueDate, accountNumber);
			if(analyticAccountBalanceRowMapperList == null){
				throw new ApplicationException("NO_RECORD FOUND");
			}
			List<AnalyticAccountBalance> analyticAccountBalanceList=createAnalyticAccountBalance(analyticAccountBalanceRowMapperList);
			
			List<AnalyticAccountBalance> responseList= new ArrayList<>();
			responseList.addAll(analyticAccountBalanceList);
			APIResponse apiResponse = new APIResponse();
			apiResponse.setResult(new Result(new ArrayList<Object>(responseList)));
			return apiResponse;

		}catch (Exception ex) {
			throw new ApplicationException(ex);
		}
	}
	
	public static List<AnalyticAccountBalance> createAnalyticAccountBalance(List<AnalyticAccountBalanceRowMapper> analyticAccountBalanceRowMapperList) throws ApplicationException{
		List<AnalyticAccountBalance> analyticAccountBalanceList = new ArrayList<>(); 
		AnalyticAccountBalance analyticAccountBalanceObjDefault = new AnalyticAccountBalance();
		AnalyticAccountBalance analyticAccountBalanceObjClone = new AnalyticAccountBalance();
		try{
			if(analyticAccountBalanceRowMapperList!=null){
				for (AnalyticAccountBalanceRowMapper analyticAccountBalanceRowMapperObj : analyticAccountBalanceRowMapperList) {
					if(analyticAccountBalanceRowMapperObj!=null){
						analyticAccountBalanceObjClone = (AnalyticAccountBalance) analyticAccountBalanceObjDefault.clone();
						analyticAccountBalanceObjClone.setAcctNo(analyticAccountBalanceRowMapperObj.getAcctNo());
						analyticAccountBalanceObjClone.setClosingBalance(analyticAccountBalanceRowMapperObj.getClosingBalance());
						analyticAccountBalanceObjClone.setClosingTime(DateUtil.getFormattedDate(analyticAccountBalanceRowMapperObj.getClosingTime()));
						analyticAccountBalanceObjClone.setOpeningBalance(analyticAccountBalanceRowMapperObj.getOpeningBalance());
						analyticAccountBalanceObjClone.setOpeningTime(DateUtil.getFormattedDate(analyticAccountBalanceRowMapperObj.getOpeningTime()));
						analyticAccountBalanceList.add(analyticAccountBalanceObjClone);	
					}
				}
			}
		}catch(Exception ex){
			throw new ApplicationException(ex);
		}
		return analyticAccountBalanceList;
	}
}
