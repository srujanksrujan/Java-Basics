package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;

public class ThrottlerGroupModel implements Serializable {

	private static final long serialVersionUID = -3915270338389167965L;

	String throttlerGroupName;
	String throttlerGroupId;

	public ThrottlerGroupModel() {
		super();
	}

	public ThrottlerGroupModel(String throttlerGroupName,
			String throttlerGroupId) {
		super();
		this.throttlerGroupName = throttlerGroupName;
		this.throttlerGroupId = throttlerGroupId;
	}

	public String getThrottlerGroupName() {
		return throttlerGroupName;
	}

	public void setThrottlerGroupName(String throttlerGroupName) {
		this.throttlerGroupName = throttlerGroupName;
	}

	public String getThrottlerGroupId() {
		return throttlerGroupId;
	}

	public void setThrottlerGroupId(String throttlerGroupId) {
		this.throttlerGroupId = throttlerGroupId;
	}



}
