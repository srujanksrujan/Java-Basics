package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;

public class TransactionMessageDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String messageQueueName;
	private String messageReferenNumber;
	private String messageProcessStatusCode;
	private String messageProcessReasonText;
	private String rawMessage;
	
	public String getMessageQueueName() {
		return messageQueueName;
	}

	public void setMessageQueueName(String messageQueueName) {
		this.messageQueueName = messageQueueName;
	}

	public String getMessageReferenNumber() {
		return messageReferenNumber;
	}

	public void setMessageReferenNumber(String messageReferenNumber) {
		this.messageReferenNumber = messageReferenNumber;
	}

	public String getMessageProcessStatusCode() {
		return messageProcessStatusCode;
	}

	public void setMessageProcessStatusCode(String messageProcessStatusCode) {
		this.messageProcessStatusCode = messageProcessStatusCode;
	}

	public String getMessageProcessReasonText() {
		return messageProcessReasonText;
	}

	public void setMessageProcessReasonText(String messageProcessReasonText) {
		this.messageProcessReasonText = messageProcessReasonText;
	}

	public String getRawMessage() {
		return rawMessage;
	}

	public void setRawMessage(String rawMessage) {
		this.rawMessage = rawMessage;
	}
	
	public void setToDefaultValue(){
		this.setMessageProcessReasonText("");
		this.setMessageProcessStatusCode("");
		this.setMessageQueueName("");
		this.setMessageReferenNumber("");
		this.setRawMessage("");
	}

	@Override
	public String toString() {
		return "TransactionMessageDetails [messageQueueName=" + messageQueueName + ", messageReferenNumber=" + messageReferenNumber
				+ ", messageProcessStatusCode=" + messageProcessStatusCode + ", messageProcessReasonText=" + messageProcessReasonText
				+ ", rawMessage=" + rawMessage + "]";
	}
}