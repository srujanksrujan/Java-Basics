package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class BusinessDate implements Serializable {
	private static final long serialVersionUID = 1L;

	private String businessDate;

	public String getBusinessDate() {
		return businessDate;
	}

	public void setBusinessDate(String businessDate) {
		this.businessDate = businessDate;
	}

	@Override
	public String toString() {
		return "BusinessDate [businessDate=" + businessDate + "]";
	}
}