/**
 * File: Config.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 18, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Config implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String keyNm;
	private String valNm;
	private String funNm;
	private String descTx;
	private String actvFl;
	
	public String getKeyNm() {
		return keyNm;
	}
	public void setKeyNm(String keyNm) {
		this.keyNm = keyNm;
	}
	public String getValNm() {
		return valNm;
	}
	public void setValNm(String valNm) {
		this.valNm = valNm;
	}
	public String getFunNm() {
		return funNm;
	}
	public void setFunNm(String funNm) {
		this.funNm = funNm;
	}
	public String getDescTx() {
		return descTx;
	}
	public void setDescTx(String descTx) {
		this.descTx = descTx;
	}
	public String getActvFl() {
		return actvFl;
	}
	public void setActvFl(String actvFl) {
		this.actvFl = actvFl;
	}
	
	
	
}
