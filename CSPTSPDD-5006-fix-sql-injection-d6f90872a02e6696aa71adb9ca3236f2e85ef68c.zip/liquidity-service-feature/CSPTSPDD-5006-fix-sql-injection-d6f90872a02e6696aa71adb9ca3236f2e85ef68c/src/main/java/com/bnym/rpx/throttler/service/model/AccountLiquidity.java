package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.math.BigDecimal;


/**
 * The persistent class for the T_GVP_THRTL_ACCT_LQDY database table.
 * 
 */

public class AccountLiquidity implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String acctNo;
	private String acctBrCd;
	private String acctSrcSysCd;
	private BigDecimal avlAm;
	
	public BigDecimal getAvlAm() {
		return avlAm;
	}

	public void setAvlAm(BigDecimal avlAm) {
		this.avlAm = avlAm;
	}


	public String getAcctNo() {
		return acctNo;
	}

	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	public String getAcctBrCd() {
		return acctBrCd;
	}

	public void setAcctBrCd(String acctBrCd) {
		this.acctBrCd = acctBrCd;
	}

	public String getAcctSrcSysCd() {
		return acctSrcSysCd;
	}
	
	public void setAcctSrcSysCd(String acctSrcSysCd) {
		this.acctSrcSysCd = acctSrcSysCd;
	}

	@Override
	public String toString() {
		return "AccountLiquidity [acctNo=" + acctNo + ", acctBrCd=" + acctBrCd + ", acctSrcSysCd=" + acctSrcSysCd + ", avlAm=" + avlAm + "]";
	}
	
}