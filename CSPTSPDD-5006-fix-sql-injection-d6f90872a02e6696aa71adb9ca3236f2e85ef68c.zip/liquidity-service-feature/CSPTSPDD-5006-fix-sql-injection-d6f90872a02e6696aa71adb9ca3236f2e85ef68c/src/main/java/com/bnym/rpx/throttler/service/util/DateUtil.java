/**
 * File: DateUtil.java 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").
 * 
 */
package com.bnym.rpx.throttler.service.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {
	
	private DateUtil() {
		super();
	}

	public static java.sql.Date getParsedSQLDate(String strDate) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
        Date parsed = format.parse(strDate);
        return new java.sql.Date(parsed.getTime());
    }
	
	public static java.sql.Date getParsedDate(String strDate) throws ParseException {
        SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yyyy");
        Date parsed = format.parse(strDate);
        return new java.sql.Date(parsed.getTime());
    }
	
	public static String getFormattedDate(Timestamp timestamp)  {
        SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy HH:mm:ss a");
        return format.format(timestamp);
    }
}
