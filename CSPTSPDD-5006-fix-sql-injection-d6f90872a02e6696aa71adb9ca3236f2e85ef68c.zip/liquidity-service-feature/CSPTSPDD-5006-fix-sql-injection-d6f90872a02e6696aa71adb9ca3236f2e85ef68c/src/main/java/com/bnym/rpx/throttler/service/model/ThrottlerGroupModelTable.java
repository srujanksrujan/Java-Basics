package com.bnym.rpx.throttler.service.model;

public class ThrottlerGroupModelTable {

	private String throttlerGroupId;
	private String throttlerGroupName;
	private String currencyCode;
	private String clearingChannelCode;
	private String timezoneCode;
	private String currentUserId;
	private String currentTimestamp;
	private String updatedUserId;
	private String updatedTimestamp;

	public String getThrottlerGroupId() {
		return throttlerGroupId;
	}

	public void setThrottlerGroupId(String throttlerGroupId) {
		this.throttlerGroupId = throttlerGroupId;
	}

	public String getThrottlerGroupName() {
		return throttlerGroupName;
	}

	public void setThrottlerGroupName(String throttlerGroupName) {
		this.throttlerGroupName = throttlerGroupName;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getClearingChannelCode() {
		return clearingChannelCode;
	}

	public void setClearingChannelCode(String clearingChannelCode) {
		this.clearingChannelCode = clearingChannelCode;
	}

	public String getTimezoneCode() {
		return timezoneCode;
	}

	public void setTimezoneCode(String timezoneCode) {
		this.timezoneCode = timezoneCode;
	}

	public String getCurrentUserId() {
		return currentUserId;
	}

	public void setCurrentUserId(String currentUserId) {
		this.currentUserId = currentUserId;
	}

	public String getCurrentTimestamp() {
		return currentTimestamp;
	}

	public void setCurrentTimestamp(String currentTimestamp) {
		this.currentTimestamp = currentTimestamp;
	}

	public String getUpdatedUserId() {
		return updatedUserId;
	}

	public void setUpdatedUserId(String updatedUserId) {
		this.updatedUserId = updatedUserId;
	}

	public String getUpdatedTimestamp() {
		return updatedTimestamp;
	}

	public void setUpdatedTimestamp(String updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}

	@Override
	public String toString() {
		return "ThrottlerGroupModelTable [throttlerGroupId=" + throttlerGroupId + ", throttlerGroupName="
				+ throttlerGroupName + ", currencyCode=" + currencyCode + ", clearingChannelCode=" + clearingChannelCode
				+ ", timezoneCode=" + timezoneCode + ", currentUserId=" + currentUserId + ", currentTimestamp="
				+ currentTimestamp + ", updatedUserId=" + updatedUserId + ", updatedTimestamp=" + updatedTimestamp
				+ "]";
	}

	
	

}
