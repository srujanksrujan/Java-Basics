package com.bnym.rpx.throttler.service.dao.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.bnym.rpx.throttler.service.dao.AnalyticsBalanceDAO;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.AnalyticAccountBalanceRowMapper;

@Repository
public class AnalyticsBalanceDAOImpl extends GenericDAO implements AnalyticsBalanceDAO {
	
	private static final Logger LOGGER = Logger.getLogger(AnalyticsBalanceDAOImpl.class);
	
	private static final String EXCEPTION = "Exception : ";
	
	@Override
	public List<AnalyticAccountBalanceRowMapper> getAnalyticsBalance(String valueDate, String accountNumber) throws DAOException {
	try {
		//LOGGER.info("Analytics Balance for "+valueDate + " account number:"+ accountNumber); 
 
		if (accountNumber.equalsIgnoreCase("All")) {
			accountNumber = null;
		}  
		
		String sql = " SELECT   acct_grp.acct_no                                                           AS acct_no " +
		"         ,TO_TIMESTAMP(:valueDate || ' 00.00.00.000000000','dd-MON-RRRR hh24.MI.ss.ff')  AS opening_time " +
		"         ,NVL( " +
		"          CASE " +
		"             WHEN    TRUNC(CAST(TO_TIMESTAMP(acct_nfo.later_dt_close_time,'dd-MON-RR hh.MI.ss.ff PM') AS DATE))  <   TO_DATE(:valueDate,'dd-MON-RRRR') " +
		"             THEN    acct_nfo.later_dt_close_bal " +
		"             WHEN    TRUNC(CAST(TO_TIMESTAMP(acct_nfo.later_dt_close_time,'dd-MON-RR hh.MI.ss.ff PM') AS DATE))  =   TO_DATE(:valueDate,'dd-MON-RRRR')  AND " +
		"                     acct_nfo.earlier_dt_close_time                                                              IS  NOT NULL " +
		"             THEN    earlier_dt_close_bal " +
		"             WHEN    TRUNC(CAST(TO_TIMESTAMP(acct_nfo.later_dt_close_time,'dd-MON-RR hh.MI.ss.ff PM') AS DATE))  =   TO_DATE(:valueDate,'dd-MON-RRRR')  AND " +
		"                     acct_nfo.earlier_dt_close_time                                                              IS  NULL                            AND " +
		"                     acct_nfo.later_dt_open_time                                                                 IS  NOT NULL " +
		"             THEN    acct_nfo.later_dt_open_bal " +
		"             WHEN    TRUNC(CAST(TO_TIMESTAMP(acct_nfo.later_dt_close_time,'dd-MON-RR hh.MI.ss.ff PM') AS DATE))  =   TO_DATE(:valueDate,'dd-MON-RRRR')  AND " +
		"                     acct_nfo.earlier_dt_close_time                                                              IS  NULL                            AND " +
		"                     acct_nfo.later_dt_open_time                                                                 IS  NULL " +
		"             THEN    acct_nfo.later_dt_close_bal " +
		"          END,0)                                                                     AS opening_balance " +
		"         ,TO_TIMESTAMP(:valueDate || ' 23.59.59.999999999','dd-MON-RRRR hh24.MI.ss.ff')  AS closing_time " +
		"         ,NVL(acct_nfo.later_dt_close_bal,0)                                         AS closing_balance " +
		"         /*--------------------------------------------------------------------------------------------------------*/ " +
		"         ,acct_nfo.earlier_dt_open_time                                              AS xx_earlier_dt_open_time " +
		"         ,acct_nfo.earlier_dt_open_bal                                               AS xx_earlier_dt_open_bal " +
		"         ,acct_nfo.earlier_dt_close_time                                             AS xx_earlier_dt_close_time " +
		"         ,acct_nfo.earlier_dt_close_bal                                              AS xx_earlier_dt_close_bal " +
		"         ,acct_nfo.later_dt_open_time                                                AS xx_later_dt_open_time " +
		"         ,acct_nfo.later_dt_open_bal                                                 AS xx_later_dt_open_bal " +
		"         ,acct_nfo.later_dt_close_time                                               AS xx_later_dt_close_time " +
		"         ,acct_nfo.later_dt_close_bal                                                AS xx_later_dt_close_bal " +
		"         /*--------------------------------------------------------------------------------------------------------*/ " +
		" FROM    (   SELECT       acct_no                                                                            AS acct_no " +
		"                         ,LISTAGG(lssr_day_opening_time   ) WITHIN GROUP (ORDER BY lssr_day_opening_time   ) AS earlier_dt_open_time " +
		"                         ,LISTAGG(lssr_day_opening_balance) WITHIN GROUP (ORDER BY lssr_day_opening_balance) AS earlier_dt_open_bal " +
		"                         ,LISTAGG(lssr_day_closing_time   ) WITHIN GROUP (ORDER BY lssr_day_closing_time   ) AS earlier_dt_close_time " +
		"                         ,LISTAGG(lssr_day_closing_balance) WITHIN GROUP (ORDER BY lssr_day_closing_balance) AS earlier_dt_close_bal " +
		"                         ,LISTAGG(grtr_day_opening_time   ) WITHIN GROUP (ORDER BY grtr_day_opening_time   ) AS later_dt_open_time " +
		"                         ,LISTAGG(grtr_day_opening_balance) WITHIN GROUP (ORDER BY grtr_day_opening_balance) AS later_dt_open_bal " +
		"                         ,LISTAGG(grtr_day_closing_time   ) WITHIN GROUP (ORDER BY grtr_day_closing_time   ) AS later_dt_close_time " +
		"                         ,LISTAGG(grtr_day_closing_balance) WITHIN GROUP (ORDER BY grtr_day_closing_balance) AS later_dt_close_bal " +
		"             FROM        ( " +
		"                             SELECT      acct_no                                                                         AS acct_no, " +
		"                                         crt_dt                                                                          AS crt_dt, " +
		"                                         CASE WHEN rn = 2 AND ts_type =  'MIN_TS'                 THEN min_crt_ts  END   AS lssr_day_opening_time, " +
		"                                         CASE WHEN rn = 2 AND ts_type =  'MIN_TS'                 THEN avl_am      END   AS lssr_day_opening_balance, " +
		"                                         CASE WHEN rn = 2 AND ts_type IN ( 'MAX_TS','MAX_MIN_TS') THEN max_crt_ts  END   AS lssr_day_closing_time, " +
		"                                         CASE WHEN rn = 2 AND ts_type IN ( 'MAX_TS','MAX_MIN_TS') THEN avl_am      END   AS lssr_day_closing_balance, " +
		"                                         CASE WHEN rn = 1 AND ts_type =  'MIN_TS'                 THEN min_crt_ts  END   AS grtr_day_opening_time, " +
		"                                         CASE WHEN rn = 1 AND ts_type =  'MIN_TS'                 THEN avl_am      END   AS grtr_day_opening_balance, " +
		"                                         CASE WHEN rn = 1 AND ts_type IN ( 'MAX_TS','MAX_MIN_TS') THEN max_crt_ts  END   AS grtr_day_closing_time, " +
		"                                         CASE WHEN rn = 1 AND ts_type IN ( 'MAX_TS','MAX_MIN_TS') THEN avl_am      END   AS grtr_day_closing_balance " +
		"                             FROM        ( " +
		"                                             SELECT  acct_no                                             AS acct_no, " +
		"                                                     crt_dt                                              AS crt_dt, " +
		"                                                     crt_ts                                              AS crt_ts, " +
		"                                                     avl_am                                              AS avl_am, " +
		"                                                     rn                                                  AS rn, " +
		"                                                     MAX(crt_ts) OVER (PARTITION BY acct_no, crt_dt, rn) AS max_crt_ts, " +
		"                                                     MIN(crt_ts) OVER (PARTITION BY acct_no, crt_dt, rn) AS min_crt_ts, " +
		"                                                     CASE " +
		"                                                         WHEN    MAX(crt_ts) OVER (PARTITION BY acct_no, crt_dt, rn) = " +
		"                                                                 MIN(crt_ts) OVER (PARTITION BY acct_no, crt_dt, rn) " +
		"                                                         THEN    'MAX_MIN_TS' " +
		"                                                         WHEN    MIN(crt_ts) OVER (PARTITION BY acct_no, crt_dt, rn) = " +
		"                                                                 crt_ts " +
		"                                                         THEN    'MIN_TS' " +
		"                                                         WHEN    MAX(crt_ts) OVER (PARTITION BY acct_no, crt_dt, rn) = " +
		"                                                                 crt_ts " +
		"                                                         THEN    'MAX_TS' " +
		"                                                         ELSE    'OTHER' " +
		"                                                     END                                                 AS ts_type " +
		"                                             FROM    ( " +
		"                                                         SELECT  acct_no         AS acct_no, " +
		"                                                                 TRUNC(crt_ts)   AS crt_dt, " +
		"                                                                 crt_ts          AS crt_ts, " +
		"                                                                 avl_am          AS avl_am, " +
		"                                                                 DENSE_RANK() OVER( " +
		"                                                                     PARTITION BY acct_no " +
		"                                                                     ORDER BY acct_no, TRUNC(crt_ts) DESC " +
		"                                                                 )               AS rn " +
		"                                                         FROM    t_gvp_thrtl_acct_lqdy_adt " +
		"                                                         WHERE   LNNVL( " +
		"                                                                     acct_no NOT IN  (   SELECT      REGEXP_SUBSTR(:accountNumber,'[^,]+',1,LEVEL) AS acct_no " +
		"                                                                                         FROM        DUAL " +
		"                                                                                         CONNECT BY  REGEXP_SUBSTR(:accountNumber,'[^,]+',1,LEVEL) IS NOT NULL " +
		"                                                                                     ) " +
		"                                                                 ) " +
		"                                                         AND     crt_ts  <=          TO_TIMESTAMP( :valueDate || ' 23.59.59.999999999', " +
		"                                                                                         'dd-MON-RRRR hh24.MI.ss.ff' " +
		"                                                                                     ) " +
		"                                                     ) " +
		"                                             WHERE   rn  <=  2 " +
		"                                         ) " +
		"                             WHERE       ts_type !=  'OTHER' " +
		"                         ) " +
		"             GROUP BY    acct_no " +
		"         )   acct_nfo " +
		"         RIGHT OUTER JOIN " +
		"         (   SELECT  acct_no " +
		"             FROM    t_gvp_thrtl_grp_acct " +
		"             WHERE   LNNVL( " +
		"                         acct_no NOT IN  (   SELECT      REGEXP_SUBSTR(:accountNumber,'[^,]+',1,LEVEL) AS acct_no " +
		"                                             FROM        DUAL " +
		"                                             CONNECT BY  REGEXP_SUBSTR(:accountNumber,'[^,]+',1,LEVEL) IS NOT NULL " +
		"                                         ) " +
		"                     ) " +
		"         )   acct_grp " +
		"         ON  (   acct_nfo.acct_no    =   acct_grp.acct_no    )" ;

		SqlParameterSource namedParameters = new MapSqlParameterSource("accountNumber", accountNumber)
				.addValue("valueDate", valueDate);
		return getNamedParameterJdbcTemplate().query(sql, namedParameters,
				new BeanPropertyRowMapper<AnalyticAccountBalanceRowMapper>(AnalyticAccountBalanceRowMapper.class));

		} catch (Exception e) {
			LOGGER.info("Exception while executing query for analytics balance " + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
}
	
	