/**
 * File: MessageHandler.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 10, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.handler;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessagePostProcessor;
import org.springframework.stereotype.Component;

import com.bnym.rpx.throttler.service.exception.ApplicationException;

@Component
public class MessageHandler {

	private static final Logger LOGGER = Logger.getLogger(AdjustmentHandler.class);

	@Autowired
	@Qualifier(value = "jmsTopicTemplate")
	private JmsTemplate jmsTopicTemplate;

	public void postMessageToTopic(final Object message) throws ApplicationException {
		try {
			jmsTopicTemplate.convertAndSend(message, new MessagePostProcessor() {
				@Override
				public Message postProcessMessage(final Message message) throws JMSException {
					if (LOGGER.isDebugEnabled()) {
						LOGGER.debug("postProcessMessage() called.");
					}
					if (message instanceof BytesMessage) {
						final BytesMessage jmsMessage = (BytesMessage) message;
						jmsMessage.reset();
						final Long length = jmsMessage.getBodyLength();
						final byte[] byteMyMessage = new byte[length.intValue()];
						jmsMessage.readBytes(byteMyMessage);
					}
					return message;
				}
			});
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}
}
