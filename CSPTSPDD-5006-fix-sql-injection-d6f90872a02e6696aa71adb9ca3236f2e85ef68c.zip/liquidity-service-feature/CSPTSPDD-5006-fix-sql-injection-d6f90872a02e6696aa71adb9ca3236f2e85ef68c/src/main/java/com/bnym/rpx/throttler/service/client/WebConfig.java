package com.bnym.rpx.throttler.service.client;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@SuppressWarnings("deprecation")
@Configuration
public class WebConfig extends WebMvcConfigurerAdapter {

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**").allowedOrigins("https://rpx-throttler.bnymellon.net")
				.allowedOrigins("https://rpx-throttler.dev.bnymellon.net")
				.allowedOrigins("https://rpx-throttler-alpha.test.bnymellon.net")
				.allowedOrigins("https://rpx-throttler-uat.test.bnymellon.net")
				.allowedOrigins("https://rpx-throttler.qa.bnymellon.net")
				.allowedOrigins("https://es1portal.dev.bnymellon.net/")
				.allowedMethods("PUT", "DELETE", "GET", "HEAD", "OPTIONS")
				.allowedHeaders("x-requested-with", "accept", "authorization", "content-type")
				.exposedHeaders("access-control-allow-headers", "access-control-allow-methods",
						"access-control-max-age", "X-Frame-Options")
				.allowCredentials(true).maxAge(3600);
	}
}