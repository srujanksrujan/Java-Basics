package com.bnym.rpx.throttler.service.controller;

import java.io.IOException;

import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.bnym.rpx.throttler.service.common.ApplicationConstants;
import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.handler.ThrottlerSupportHTTPHandler;
import com.bnym.rpx.throttler.service.handler.ThrottlerSupportRestHandler;
import com.bnym.rpx.throttler.service.model.APIError;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.ResponseMetadata;
import com.bnym.rpx.throttler.service.util.ExceptionUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@Api(value = "PaymentThrottlerService")
@CrossOrigin(origins="https://rpx-payment-utility.dev.bnymellon.net",allowedHeaders={"x-requested-with", "accept", "authorization", "content-type"}, 
exposedHeaders={"access-control-allow-headers", "access-control-allow-methods", "access-control-max-age", "X-Frame-Options","access-control-allow-origin"})  
public class ThrottlerSupportRestController {

	private static final Logger LOGGER = Logger.getLogger(ThrottlerSupportRestController.class);

	public static String getException() {
		return EXCEPTION;
	}

	@Autowired
	private ThrottlerSupportRestHandler throttlerSupportRestHandler;
	private static final String EXCEPTION = "EXCEPTION";

	@Autowired
	private ThrottlerSupportHTTPHandler throttlerSupportHTTPHandler;

	@RequestMapping(value = "/configure/calculator/host", method = RequestMethod.POST)
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = " Insert entry into Throttler Host Proc Table. Created URL for Throttler technology support ", notes = " Insert entry into Throttler Host Proc Table. Created URL for Throttler technology support. Calculator AccountRefresh URI needs to be executed once calculator host is added.", response = APIResponse.class)
	public @ResponseBody APIResponse configureCalculatorHost(
			@RequestParam(value = "hostName", required = true) String hostName,
			@RequestParam(value = "accountNumber", required = true) String accountNumber,
			@RequestParam(value = "throttlerGroupId", required = true) String throttlerGroupId,
			@ApiParam(name = "activeFlag", value = "activeFlag", allowableValues = "YES, NO", required = true) @RequestParam String activeFlag)
			throws ApplicationException, IOException {

		LOGGER.info(
				"Controller : Request Received for Throttler Host Proc Table in  /configure/calculator/host  with Parameters as hostName:"
						+ hostName + "accountNo:" + accountNumber + "throttlerGroupId:" + throttlerGroupId);
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportRestHandler.configureCalculatorHost(hostName, accountNumber, throttlerGroupId,
					activeFlag);
		} catch (ApplicationException e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/configure/calculator/host/flag", method = RequestMethod.PUT)
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = " Enables or disables given account processing mapped to given host. ", notes = " Update Calculator host flag to YES or NO configured in Calculator Host Proc table based on input parameters. Calculator AccountRefresh URI needs to be executed once calculator host flag is updated ", response = APIResponse.class)
	public @ResponseBody APIResponse configCalcHostFlag(
			@RequestParam(value = "hostName", required = true) String hostName,
			@RequestParam(value = "accountNumber", required = true) String accountNumber,
			@RequestParam(value = "throttlerGroupId", required = true) String throttlerGroupId,
			@ApiParam(name = "activeFlag", value = "activeFlag", allowableValues = "YES, NO", required = true) @RequestParam String activeFlag)
			throws ApplicationException, IOException {
		LOGGER.info("Controller : Request Received for /configure/calculator/host/flag  with Parameters as hostName:"
				+ hostName + "accntNo:" + accountNumber + "throttlerGroupId:" + throttlerGroupId);
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportRestHandler.configCalcHostFlag(hostName, accountNumber, throttlerGroupId,
					activeFlag);
		} catch (ApplicationException e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/configure/scheduler/host", method = RequestMethod.POST)
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = " Insert entry into Throttler Config Table. Created URL for Throttler Technology Support", notes = "Insert entry into Throttler Config Table. Created URL for technology support.Scheduler AccountRefresh URI needs to be executed once scheduler host is added. NOTE : Scheduler AccountRefresh URI needs to be executed once scheduler host is added.", response = APIResponse.class)
	public @ResponseBody APIResponse configureSchedulerHost(
			@RequestParam(value = "hostName", required = true) String hostName,
			@ApiParam(name = "activeFlag", value = "activeFlag", allowableValues = "YES, NO", required = true) @RequestParam String activeFlag,
			@RequestParam(value = "comments", required = true) String comments)
			throws ApplicationException, IOException {
		LOGGER.info("Controller : Request Received for /configure/scheduler/host  with Parameters as hostName:"
				+ hostName + "activeFlag:" + activeFlag + "comments:" + comments);
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportRestHandler.configureSchedulerHost(hostName, activeFlag, comments);
		} catch (ApplicationException e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/configure/scheduler/host/flag", method = RequestMethod.PUT)
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Enables or disables given account processing mapped to given host", notes = "Scheduler Account Refresh URI needs to be executed once Scheduler host flag is updated. NOTE : Scheduler Account Refresh URI needs to be executed once Scheduler host flag is updated", response = APIResponse.class)
	public @ResponseBody APIResponse configureSchedulerHostFlag(@RequestParam(value = "hostName", required = true) String hostName,
			@ApiParam(name = "activeFlag", value = "activeFlag", allowableValues = "YES, NO", required = true) @RequestParam String activeFlag)
			throws ApplicationException, IOException {
		LOGGER.info(
				"Controller : Request Received for /configure/scheduler/host/flag  with Parameters as follows: HostName :"
						+ hostName + "activeFlag:" + activeFlag);
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportRestHandler.configureSchedulerHostFlag(hostName, activeFlag);
		} catch (ApplicationException e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/refresh/calculator/accounts", method = RequestMethod.PUT)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Calculator Account Refresh URL will refresh list of accounts present in application for given host", notes = " Calculator Account Refresh URL will refresh list of accounts present in application for given host.Uses HTTP Client or Spring Rest Client Template in order to invoke following URL :  http://HostName:PortNumber/RTThrottlerCalculator/AccountRefresh.html", response = APIResponse.class)
	public @ResponseBody APIResponse refreshCalculatorAccounts(
			@ApiParam(name = "hostName", value = "Enter Host Name", required = true) @RequestParam(value = "hostName") String hostName,
			@ApiParam(name = "portNumber", value = "Enter Port Number", required = true) @RequestParam(value = "portNumber") String portNumber)
			throws ApplicationException, IOException {
		LOGGER.info(
				"Controller : Request Received for /refresh/calculator/accountswith Parameters as follows hostName : "
						+ hostName + " , portNumber : " + portNumber);
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportHTTPHandler.refreshCalculatorAccounts(hostName, portNumber);
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));

			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/refresh/scheduler/accounts", method = RequestMethod.PUT)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "refresh list of accounts present in application for given host", notes = " http://HostName:PortNumber/RTThrottlerScheduler/AccountRefresh.htmlScheduler Account Refresh URL will refresh list of accounts present in application for given host.", response = APIResponse.class)
	public @ResponseBody APIResponse refreshSchedulerAccounts(
			@ApiParam(name = "hostName", value = "Enter Host Name", required = true) @RequestParam(value = "hostName") String hostName,
			@ApiParam(name = "portNumber", value = "Enter Port Number", required = true) @RequestParam(value = "portNumber") String portNumber)
			throws ApplicationException, IOException {
		LOGGER.info(
				"Controller : Request Received for /refresh/scheduler/accounts with Parameters as follows hostName : "
						+ hostName + " , portNumber : " + portNumber);
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportHTTPHandler.refreshSchedulerAccounts(hostName, portNumber);
			response.setMetadata(new ResponseMetadata(200, ApplicationConstants.SUCCESS));
		} catch (Exception e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

 
	@RequestMapping(value = "/cofigure/throttler/account", method = RequestMethod.POST)
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Insert entry into Throttler Account Liquidity table, Throttler Account Liquidity Audit table and Throttler Group Account table", notes = "Insert entry into Throttler Account Liquidity table, Throttler Account Liquidity Audit table and Throttler Group Account table; Assumption : Throttler Group ID is already present in Throttler Group table", response = APIResponse.class)
	public @ResponseBody APIResponse configureThrottlerAccount(
			@ApiParam(name = "groupId", value = "Group Id", required = true) @RequestParam String groupId,
			@ApiParam(name = "accountNumber", value = "Account Number", required = true) @RequestParam String accountNumber,
			@ApiParam(name = "accountBranchCode", value = "Account Branch Code", required = true) @RequestParam String accountBranchCode,
			@ApiParam(name = "accountSourceSysCode", value = "Account Source System Code", required = true) @RequestParam String accountSourceSysCode,
			@ApiParam(name = "availableAmt", value = "Enter Amount; Eg.: 10", required = true) @RequestParam Number availableAmt,
			@ApiParam(name = "displayFlag", value = "Display Flag", allowableValues = "YES, NO", required = true) @RequestParam String displayFlag,
			@ApiParam(name = "isFundAgent", value = "Is Fund Agent", allowableValues = "YES, NO", required = true) @RequestParam String isFundAgent,
			@ApiParam(name = "dcsnCode", value = "Decision Code", allowableValues = "APPROVED, DISAPPROVED", required = true) @RequestParam String dcsnCode)
			throws ApplicationException, IOException {
		LOGGER.info("Controller : Request Received for /add/throttler/account  with Parameters as groupId:" + groupId
				+ "accountNumber:" + accountNumber + "accountBranchCode:" + accountBranchCode + "accountSourceSysCode:"
				+ accountSourceSysCode + "availableAmt:" + availableAmt + "displayFlag:" + displayFlag + "dcsnCode:"
				+ dcsnCode + "isFundAgent:" + isFundAgent);
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportRestHandler.configureThrottlerAccount(groupId, accountNumber, accountBranchCode,
					accountSourceSysCode, availableAmt, displayFlag, dcsnCode, isFundAgent);
		} catch (ApplicationException e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/configure/throttler/group", method = RequestMethod.POST)
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Insert entry into Throttler Group table", notes = "Insert entry into Throttler Group table", response = APIResponse.class)
	public @ResponseBody APIResponse configureThrottlerGroup(
			@ApiParam(name = "groupId", value = "Group Id", required = true) @RequestParam String groupId,
			@ApiParam(name = "groupName", value = "Group Name", required = true) @RequestParam String groupName,
			@ApiParam(name = "currency", value = "Currency", required = true) @RequestParam String currency)
			throws ApplicationException, IOException {
		LOGGER.info("Controller : Request Received for /insert/throttler/group  with Parameters as groupId:" + groupId
				+ "groupName:" + groupName + "currency:" + currency);
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportRestHandler.configureThrottlerGroup(groupId, groupName, currency);
		} catch (ApplicationException e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

	@RequestMapping(value = "/throttler/groups", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Fetches the details of Throttler Group Table", notes = "Fetches the details of Throttler Group Table", response = APIResponse.class)
	public @ResponseBody APIResponse getThrottlerGroups() throws ApplicationException, IOException {
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportRestHandler.getThrottlerGroups();
		} catch (ApplicationException e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;

	}

	@RequestMapping(value = "/calculator/hosts", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Fetches calculator hosts from Throttler Host Proc Table", notes = "Fetches calculator hosts from Throttler Host Proc Table", response = APIResponse.class)
	public @ResponseBody APIResponse getCalculatorHosts() throws ApplicationException, IOException {
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportRestHandler.getCalculatorHosts();
		} catch (ApplicationException e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}
	
	@RequestMapping(value = "/throttler/accounts", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Fetches Throttler Accounts from Throttler Account Liquidity table", notes = "Fetches Throttler Accounts from Throttler Account Liquidity table", response = APIResponse.class)
	public @ResponseBody APIResponse getThrottlerAccounts() throws ApplicationException, IOException {
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportRestHandler.getThrottlerAccounts();
		} catch (ApplicationException e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}
	
	@RequestMapping(value = "/scheduler/hosts", method = RequestMethod.GET)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Fetches Scheduler Hosts from Throttler Config table", notes = "Fetches Scheduler Hosts from Throttler Config table", response = APIResponse.class)
	public @ResponseBody APIResponse getSchedulerHosts() throws ApplicationException, IOException {
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportRestHandler.getSchedulerHosts();
		} catch (ApplicationException e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}
	
	@RequestMapping(value = "/configure/throttler/account/displayflag", method = RequestMethod.PUT)
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Update Throttler Account Display Flag present in Throttler Group Account Table", notes = "Update Throttler Account Display Flag present in Throttler Group Account Table", response = APIResponse.class)
	public @ResponseBody APIResponse configureThrottlerAccntDispFlag(
			@ApiParam(name = "groupId", value = "Group Id", required = true) @RequestParam String groupId,
			@ApiParam(name = "accountNumber", value = "Account Number", required = true) @RequestParam String accountNumber,
			@ApiParam(name = "accountBranchCode", value = "Account Branch Code", required = true) @RequestParam String accountBranchCode,
			@ApiParam(name = "accountSourceSysCode", value = "Account Source System Code", required = true) @RequestParam String accountSourceSysCode,
			@ApiParam(name = "displayFlag", value = "Display Flag", allowableValues = "YES, NO", required = true) @RequestParam String displayFlag)
			throws ApplicationException, IOException {
		LOGGER.info("Controller : Request Received for /add/throttler/account  with Parameters as groupId:" + groupId
				+ "accountNumber:" + accountNumber + "accountBranchCode:" + accountBranchCode + "accountSourceSysCode:"
				+ accountSourceSysCode + "displayFlag:" + displayFlag);
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportRestHandler.configureThrottlerAccntDispFlag(groupId, accountNumber, accountBranchCode,
					accountSourceSysCode, displayFlag);
		} catch (ApplicationException e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}
	
	@RequestMapping(value = "/configure/throttler/account/fundingagentflag", method = RequestMethod.PUT)
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value = "Update Throttler Account Funding Agent Flag present in Throttler Account Table", notes = "Update Throttler Account Funding Agent Flag present in Throttler Account Table", response = APIResponse.class)
	public @ResponseBody APIResponse configureThrottlerAccntFundingAgentFlag(
			@ApiParam(name = "groupId", value = "Group Id", required = true) @RequestParam String groupId,
			@ApiParam(name = "accountNumber", value = "Account Number", required = true) @RequestParam String accountNumber,
			@ApiParam(name = "accountBranchCode", value = "Account Branch Code", required = true) @RequestParam String accountBranchCode,
			@ApiParam(name = "accountSourceSysCode", value = "Account Source System Code", required = true) @RequestParam String accountSourceSysCode,
			@ApiParam(name = "isFundAgent", value = "Is Fund Agent", allowableValues = "YES, NO", required = true) @RequestParam String isFundAgent)
			throws ApplicationException, IOException {
		LOGGER.info("Controller : Request Received for /add/throttler/account  with Parameters as groupId:" + groupId
				+ "accountNumber:" + accountNumber + "accountBranchCode:" + accountBranchCode + "accountSourceSysCode:"
				+ accountSourceSysCode + "isFundAgent:" + isFundAgent);
		APIResponse response = new APIResponse();
		try {
			response = throttlerSupportRestHandler.configureThrottlerAccntFundingAgentFlag(groupId, accountNumber, accountBranchCode,
					accountSourceSysCode,isFundAgent);
		} catch (ApplicationException e) {
			LOGGER.error(ExceptionUtil.getFullExceptionAsString(e));
			response.setError(new APIError(getException(), e.getMessage()));
			response.setMetadata(new ResponseMetadata(500, ApplicationConstants.FAILURE));
		}
		return response;
	}

}
