package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class AccountBalance implements Serializable, Cloneable{
	
	
	private static final long serialVersionUID = -3915270338389167965L;
	
	private String throttlerGroupId;
	private String throttlerGroupName;
	private String accountNumber;
	private BigDecimal cashIn;
	private BigDecimal adjIn;
	private BigDecimal totalsIn;
	private BigDecimal cashOut;
	private BigDecimal adjOut;
	private BigDecimal totalsOut;
	private BigDecimal availableAmount;
	private BigDecimal pendingPaymentCount;
	private BigDecimal pendingCreditCount;
	private String isFundingAgentFlag;
	private String currencyCode;
	private Timestamp updatedTime;
	
	public String getThrottlerGroupId() {
		return throttlerGroupId;
	}

	public void setThrottlerGroupId(String throttlerGroupId) {
		this.throttlerGroupId = throttlerGroupId;
	}

	public String getThrottlerGroupName() {
		return throttlerGroupName;
	}

	public void setThrottlerGroupName(String throttlerGroupName) {
		this.throttlerGroupName = throttlerGroupName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public BigDecimal getCashIn() {
		return cashIn;
	}

	public void setCashIn(BigDecimal cashIn) {
		this.cashIn = cashIn;
	}

	public BigDecimal getAdjIn() {
		return adjIn;
	}

	public void setAdjIn(BigDecimal adjIn) {
		this.adjIn = adjIn;
	}

	public BigDecimal getTotalsIn() {
		return totalsIn;
	}

	public void setTotalsIn(BigDecimal totalsIn) {
		this.totalsIn = totalsIn;
	}

	public BigDecimal getCashOut() {
		return cashOut;
	}

	public void setCashOut(BigDecimal cashOut) {
		this.cashOut = cashOut;
	}

	public BigDecimal getAdjOut() {
		return adjOut;
	}

	public void setAdjOut(BigDecimal adjOut) {
		this.adjOut = adjOut;
	}

	public BigDecimal getTotalsOut() {
		return totalsOut;
	}

	public void setTotalsOut(BigDecimal totalsOut) {
		this.totalsOut = totalsOut;
	}

	public BigDecimal getAvailableAmount() {
		return availableAmount;
	}

	public void setAvailableAmount(BigDecimal availableAmount) {
		this.availableAmount = availableAmount;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public Timestamp getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(Timestamp updatedTime) {
		this.updatedTime = updatedTime;
	}
	
	public BigDecimal getPendingPaymentCount() {
		return pendingPaymentCount;
	}

	public void setPendingPaymentCount(BigDecimal pendingPaymentCount) {
		this.pendingPaymentCount = pendingPaymentCount;
	}

	public BigDecimal getPendingCreditCount() {
		return pendingCreditCount;
	}

	public void setPendingCreditCount(BigDecimal pendingCreditCount) {
		this.pendingCreditCount = pendingCreditCount;
	}

	public String getIsFundingAgentFlag() {
		return isFundingAgentFlag;
	}

	public void setIsFundingAgentFlag(String isFundingAgentFlag) {
		this.isFundingAgentFlag = isFundingAgentFlag;
	}
	
	public void setToDefaultValue(){
		this.setAccountNumber("");
		this.setAdjIn(BigDecimal.ZERO);
		this.setAdjOut(BigDecimal.ZERO);
		this.setAvailableAmount(BigDecimal.ZERO);
		this.setCashIn(BigDecimal.ZERO);
		this.setCashOut(BigDecimal.ZERO);
		this.setCurrencyCode("");
		this.setIsFundingAgentFlag("");
		this.setTotalsIn(BigDecimal.ZERO);
		this.setTotalsOut(BigDecimal.ZERO);
		this.setPendingPaymentCount(BigDecimal.ZERO);
		this.setPendingCreditCount(BigDecimal.ZERO);
		this.setThrottlerGroupId("");
		this.setThrottlerGroupName("");
		this.setUpdatedTime(null);
	}
	
	 public Object clone() throws CloneNotSupportedException {
	        return super.clone();
	    }

	@Override
	public String toString() {
		return "AccountBalance [throttlerGroupId=" + throttlerGroupId + ", throttlerGroupName=" + throttlerGroupName + ", accountNumber="
				+ accountNumber + ", cashIn=" + cashIn + ", adjIn=" + adjIn + ", totalsIn=" + totalsIn + ", cashOut=" + cashOut + ", adjOut="
				+ adjOut + ", totalsOut=" + totalsOut + ", availableAmount=" + availableAmount + ", pendingPaymentCount=" + pendingPaymentCount
				+ ", pendingCreditCount=" + pendingCreditCount + ", isFundingAgentFlag=" + isFundingAgentFlag + ", currencyCode=" + currencyCode
				+ ", updatedTime=" + updatedTime + "]";
	}
}