package com.bnym.rpx.throttler.service.enums;

public enum DecisionCode {
	
	APPROVED("APPROVED", "APRVD"), 
	DISAPPROVED("DISAPPROVED", "DISAPRVD");

	private String name;
	private String code;
	
	private DecisionCode(String name, String code) {
		this.name = name;
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	public static DecisionCode value(String name) {
		if (name == null) {
			return null;
		}
		for (DecisionCode event : DecisionCode.values()) {
			if (event.getName().equals(name)) {
				return event;
			}
		}
		return null;
	}

}
