/**
 * File: AdjustmentRowMapper.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 6, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.RowMapper;

import com.bnym.rpx.throttler.service.entity.Adjustment;

public class AdjustmentRowMapper implements RowMapper<Adjustment> {
	private static final Logger LOGGER = Logger.getLogger(AdjustmentRowMapper.class);

	@Override
	public Adjustment mapRow(ResultSet rs, int arg1) throws SQLException {
		Adjustment adj = new Adjustment();
		adj.setAdjId(rs.getString("ADJ_ID"));
		adj.setBulkId(rs.getString("BULK_ID"));
		adj.setValDt(rs.getDate("VAL_DT"));
		adj.setAdtVrsnNo(rs.getLong("ADT_VRSN_NO"));
		adj.setProcStat(rs.getString("PROC_STAT"));
		adj.setAcctNo(rs.getString("ACCT_NO"));
		adj.setAcctBrCd(rs.getString("ACCT_BR_CD"));
		adj.setAcctSrcSysCd(rs.getString("ACCT_SRC_SYS_CD"));
		adj.setThrtlGrpId(rs.getString("THRTL_GRP_ID"));
		adj.setPyAmt(rs.getBigDecimal("PY_AMT"));
		adj.setAdjInOutCd(rs.getString("ADJ_IN_OUT_CD"));
		adj.setAdjRsnTx(rs.getString("ADJ_RSN_TX"));
		adj.setCmntTx(rs.getString("CMNT_TX"));
		adj.setCrtUsrId(rs.getString("CRT_USR_ID"));
		adj.setCrtTs(rs.getTimestamp("CRT_TS"));
		adj.setUpdUsrId(rs.getString("UPD_USR_ID"));
		adj.setUpdTs(rs.getTimestamp("UPD_TS"));
		adj.setAprvUsrId(rs.getString("APRV_USR_ID"));
		adj.setAprvTs(rs.getTimestamp("APRV_TS"));
		adj.setAprvDcsnCd(rs.getString("APRV_DCSN_CD"));
		adj.setCrtTs(rs.getTimestamp("STR_CRT_TS"));
		adj.setUpdTs(rs.getTimestamp("STR_UPD_TS"));
		adj.setAprvTs(rs.getTimestamp("STR_APRV_TS"));
		LOGGER.info("Inside mapRow , Adjustment:" +adj);
		return adj;
	}

}
