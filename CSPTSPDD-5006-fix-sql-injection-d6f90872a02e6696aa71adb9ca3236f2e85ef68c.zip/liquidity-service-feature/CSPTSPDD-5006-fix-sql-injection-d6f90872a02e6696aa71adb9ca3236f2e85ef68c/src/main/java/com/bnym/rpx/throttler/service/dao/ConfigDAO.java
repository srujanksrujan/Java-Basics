/**
 * File: ConfigDAO.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 18, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.dao;

import java.util.List;

import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.exception.NoDataFoundException;
import com.bnym.rpx.throttler.service.model.BusinessDate;
import com.bnym.rpx.throttler.service.model.Config;

public interface ConfigDAO {
	
	List<Config>  getAdjustmentReasons() throws  DAOException;
	/**
	 * Gets the list of configs which are active for the given configName
	 * @param configName
	 * @return  List&lt;Config&gt;
	 * @throws DAOException if any exception occurs
	 * @throws NoDataFoundException  if no data found for the specified criteria
	 */
	List<Config>  getActiveConfigs(String configName) throws  DAOException, NoDataFoundException;
	List<BusinessDate> getBusinessDate() throws DAOException;
	
}
