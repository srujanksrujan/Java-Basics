/**
* Description
*
* @author  Swati Rashmi
* @version 1.0
* @since   Dec 19, 2016
*/
package com.bnym.rpx.throttler.service.model;

/**
* Description
*
* @author  Swati Rashmi
* @version 1.0
* @since   Dec 19, 2016
*/
public class APIResponse {
	
	private Result result;
	private ResponseMetadata metadata;
	private APIError error;
	/**
	 * @return the result
	 */
	public Result getResult() {
		return result;
	}
	/**
	 * @param result the result to set
	 */
	public void setResult(Result result) {
		this.result = result;
	}
	/**
	 * @return the metadata
	 */
	public ResponseMetadata getMetadata() {
		return metadata;
	}
	/**
	 * @param metadata the metadata to set
	 */
	public void setMetadata(ResponseMetadata metadata) {
		this.metadata = metadata;
	}
	/**
	 * @return the error
	 */
	public APIError getError() {
		return error;
	}
	/**
	 * @param error the error to set
	 */
	public void setError(APIError error) {
		this.error = error;
	}
	/**
	 * 
	 */
	public APIResponse() {
		super();
	}
	/**
	 * @param result
	 * @param metadata
	 * @param error
	 */
	public APIResponse(Result result, ResponseMetadata metadata, APIError error) {
		super();
		this.result = result;
		this.metadata = metadata;
		this.error = error;
	}
	
	@Override
	public String toString() {
		return "APIResponse [result=" + result + ", metadata=" + metadata + ", error=" + error + "]";
	}
	
	

}
