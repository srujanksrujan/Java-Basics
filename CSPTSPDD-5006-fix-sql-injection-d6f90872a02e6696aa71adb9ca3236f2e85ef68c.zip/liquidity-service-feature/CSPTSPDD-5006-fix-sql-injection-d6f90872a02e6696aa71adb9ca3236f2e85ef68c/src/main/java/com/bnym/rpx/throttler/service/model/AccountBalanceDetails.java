package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;

public class AccountBalanceDetails implements Serializable{
	
	
	private static final long serialVersionUID = -3915270338389167965L;
	

	private String accountNumber;
	private String cashIn;
	private String adjIn;
	private String totalsIn;
	private String cashOut;
	private String adjOut;
	private String totalsOut;
	private String availableAmount;
	private String currencyCode;
	private String pendingPaymentCount;
	private String pendingCreditCount;
	private String isFundingAgentFlag;
	private String updatedTime;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCashIn() {
		return cashIn;
	}

	public void setCashIn(String cashIn) {
		this.cashIn = cashIn;
	}
	
	public String getAdjIn() {
		return adjIn;
	}

	public void setAdjIn(String adjIn) {
		this.adjIn = adjIn;
	}

	public String getTotalsIn() {
		return totalsIn;
	}

	public void setTotalsIn(String totalsIn) {
		this.totalsIn = totalsIn;
	}

	public String getCashOut() {
		return cashOut;
	}

	public void setCashOut(String cashOut) {
		this.cashOut = cashOut;
	}

	public String getAdjOut() {
		return adjOut;
	}

	public void setAdjOut(String adjOut) {
		this.adjOut = adjOut;
	}

	public String getTotalsOut() {
		return totalsOut;
	}

	public void setTotalsOut(String totalsOut) {
		this.totalsOut = totalsOut;
	}

	public String getAvailableAmount() {
		return availableAmount;
	}

	public void setAvailableAmount(String availableAmount) {
		this.availableAmount = availableAmount;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(String updatedTime) {
		this.updatedTime = updatedTime;
	}

	public String getPendingPaymentCount() {
		return pendingPaymentCount;
	}

	public void setPendingPaymentCount(String pendingPaymentCount) {
		this.pendingPaymentCount = pendingPaymentCount;
	}

	public String getPendingCreditCount() {
		return pendingCreditCount;
	}

	public void setPendingCreditCount(String pendingCreditCount) {
		this.pendingCreditCount = pendingCreditCount;
	}

	public String getIsFundingAgentFlag() {
		return isFundingAgentFlag;
	}

	public void setIsFundingAgentFlag(String isFundingAgentFlag) {
		this.isFundingAgentFlag = isFundingAgentFlag;
	}

	@Override
	public String toString() {
		return "AccountBalanceDetails [accountNumber=" + accountNumber + ", cashIn=" + cashIn + ", adjIn=" + adjIn + ", totalsIn=" + totalsIn
				+ ", cashOut=" + cashOut + ", adjOut=" + adjOut + ", totalsOut=" + totalsOut + ", availableAmount=" + availableAmount
				+ ", currencyCode=" + currencyCode + ", pendingPaymentCount=" + pendingPaymentCount + ", pendingCreditCount=" + pendingCreditCount
				+ ", isFundingAgentFlag=" + isFundingAgentFlag + ", updatedTime=" + updatedTime + "]";
	}
}