/**
 * File: TransactionDetails.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 17, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class TransactionDetails implements Serializable {

	private static final long serialVersionUID = 1L;

	private String tranType;
	private String srcRefNo;
	private String srcSysCd;
	private long adtVrsnNo;
	private String acctCat;
	private String acctNo;
	private String acctTypCd;
	private BigDecimal baseAmt;
	private String baseCcyCd;
	private BigDecimal baseFxRate;
	private String bulkId;
	private String ccyIsoCd;
	private Timestamp crtTm;
	private Timestamp crtTs;
	private String crtUsrId;	
	private String dbCrCd;
	private String domainNm;
	private BigDecimal fxRt;
	private String grpBrId;
	private String grpOffId;
	private String grpRefId;
	private BigDecimal instrAmt;
	private String instrCcyCd;
	private String intrDirCd;
	private String intrTypCd;
	private String msgBrId;
	private BigDecimal msgCnt;
	private String msgOffId;
	private String msgRefId;
	private String origRefId;
	private String postEntrTyp;
	private String postOvrCd;
	private String procStat;
	private BigDecimal tranAmt;
	private String reqTypCd;
	private String rsvId;
	private String thrtlGrpId;
	private String trnNarr;
	private Timestamp updTs;
	private String updUsrId;
	private Date valDt;
	private BigDecimal vrsnNo;
	private String strCrtTm;
	private String strCrtTs;
	private String strUpdTs;

	public String getTranType() {
		return tranType;
	}


	public void setTranType(String tranType) {
		this.tranType = tranType;
	}


	public String getSrcRefNo() {
		return srcRefNo;
	}


	public void setSrcRefNo(String srcRefNo) {
		this.srcRefNo = srcRefNo;
	}


	public String getSrcSysCd() {
		return srcSysCd;
	}


	public void setSrcSysCd(String srcSysCd) {
		this.srcSysCd = srcSysCd;
	}


	public long getAdtVrsnNo() {
		return adtVrsnNo;
	}


	public void setAdtVrsnNo(long adtVrsnNo) {
		this.adtVrsnNo = adtVrsnNo;
	}


	public String getAcctCat() {
		return acctCat;
	}


	public void setAcctCat(String acctCat) {
		this.acctCat = acctCat;
	}


	public String getAcctNo() {
		return acctNo;
	}


	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}


	public String getAcctTypCd() {
		return acctTypCd;
	}


	public void setAcctTypCd(String acctTypCd) {
		this.acctTypCd = acctTypCd;
	}


	public BigDecimal getBaseAmt() {
		return baseAmt;
	}


	public void setBaseAmt(BigDecimal baseAmt) {
		this.baseAmt = baseAmt;
	}


	public String getBaseCcyCd() {
		return baseCcyCd;
	}


	public void setBaseCcyCd(String baseCcyCd) {
		this.baseCcyCd = baseCcyCd;
	}


	public BigDecimal getBaseFxRate() {
		return baseFxRate;
	}


	public void setBaseFxRate(BigDecimal baseFxRate) {
		this.baseFxRate = baseFxRate;
	}


	public String getBulkId() {
		return bulkId;
	}


	public void setBulkId(String bulkId) {
		this.bulkId = bulkId;
	}


	public String getCcyIsoCd() {
		return ccyIsoCd;
	}


	public void setCcyIsoCd(String ccyIsoCd) {
		this.ccyIsoCd = ccyIsoCd;
	}


	public Timestamp getCrtTm() {
		return crtTm;
	}


	public void setCrtTm(Timestamp crtTm) {
		this.crtTm = crtTm;
	}


	public Timestamp getCrtTs() {
		return crtTs;
	}


	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}


	public String getCrtUsrId() {
		return crtUsrId;
	}


	public void setCrtUsrId(String crtUsrId) {
		this.crtUsrId = crtUsrId;
	}


	public String getDbCrCd() {
		return dbCrCd;
	}


	public void setDbCrCd(String dbCrCd) {
		this.dbCrCd = dbCrCd;
	}


	public String getDomainNm() {
		return domainNm;
	}


	public void setDomainNm(String domainNm) {
		this.domainNm = domainNm;
	}


	public BigDecimal getFxRt() {
		return fxRt;
	}


	public void setFxRt(BigDecimal fxRt) {
		this.fxRt = fxRt;
	}


	public String getGrpBrId() {
		return grpBrId;
	}


	public void setGrpBrId(String grpBrId) {
		this.grpBrId = grpBrId;
	}


	public String getGrpOffId() {
		return grpOffId;
	}


	public void setGrpOffId(String grpOffId) {
		this.grpOffId = grpOffId;
	}


	public String getGrpRefId() {
		return grpRefId;
	}


	public void setGrpRefId(String grpRefId) {
		this.grpRefId = grpRefId;
	}


	public BigDecimal getInstrAmt() {
		return instrAmt;
	}


	public void setInstrAmt(BigDecimal instrAmt) {
		this.instrAmt = instrAmt;
	}


	public String getInstrCcyCd() {
		return instrCcyCd;
	}


	public void setInstrCcyCd(String instrCcyCd) {
		this.instrCcyCd = instrCcyCd;
	}


	public String getIntrDirCd() {
		return intrDirCd;
	}


	public void setIntrDirCd(String intrDirCd) {
		this.intrDirCd = intrDirCd;
	}


	public String getIntrTypCd() {
		return intrTypCd;
	}


	public void setIntrTypCd(String intrTypCd) {
		this.intrTypCd = intrTypCd;
	}


	public String getMsgBrId() {
		return msgBrId;
	}


	public void setMsgBrId(String msgBrId) {
		this.msgBrId = msgBrId;
	}


	public BigDecimal getMsgCnt() {
		return msgCnt;
	}


	public void setMsgCnt(BigDecimal msgCnt) {
		this.msgCnt = msgCnt;
	}


	public String getMsgOffId() {
		return msgOffId;
	}


	public void setMsgOffId(String msgOffId) {
		this.msgOffId = msgOffId;
	}


	public String getMsgRefId() {
		return msgRefId;
	}


	public void setMsgRefId(String msgRefId) {
		this.msgRefId = msgRefId;
	}


	public String getOrigRefId() {
		return origRefId;
	}


	public void setOrigRefId(String origRefId) {
		this.origRefId = origRefId;
	}


	public String getPostEntrTyp() {
		return postEntrTyp;
	}


	public void setPostEntrTyp(String postEntrTyp) {
		this.postEntrTyp = postEntrTyp;
	}


	public String getPostOvrCd() {
		return postOvrCd;
	}


	public void setPostOvrCd(String postOvrCd) {
		this.postOvrCd = postOvrCd;
	}


	public String getProcStat() {
		return procStat;
	}


	public void setProcStat(String procStat) {
		this.procStat = procStat;
	}


	public BigDecimal getTranAmt() {
		return tranAmt;
	}


	public void setTranAmt(BigDecimal tranAmt) {
		this.tranAmt = tranAmt;
	}


	public String getReqTypCd() {
		return reqTypCd;
	}


	public void setReqTypCd(String reqTypCd) {
		this.reqTypCd = reqTypCd;
	}


	public String getRsvId() {
		return rsvId;
	}


	public void setRsvId(String rsvId) {
		this.rsvId = rsvId;
	}


	public String getThrtlGrpId() {
		return thrtlGrpId;
	}


	public void setThrtlGrpId(String thrtlGrpId) {
		this.thrtlGrpId = thrtlGrpId;
	}


	public String getTrnNarr() {
		return trnNarr;
	}


	public void setTrnNarr(String trnNarr) {
		this.trnNarr = trnNarr;
	}


	public Timestamp getUpdTs() {
		return updTs;
	}


	public void setUpdTs(Timestamp updTs) {
		this.updTs = updTs;
	}


	public String getUpdUsrId() {
		return updUsrId;
	}


	public void setUpdUsrId(String updUsrId) {
		this.updUsrId = updUsrId;
	}


	public Date getValDt() {
		return valDt;
	}


	public void setValDt(Date valDt) {
		this.valDt = valDt;
	}


	public BigDecimal getVrsnNo() {
		return vrsnNo;
	}


	public void setVrsnNo(BigDecimal vrsnNo) {
		this.vrsnNo = vrsnNo;
	}


	public String getStrCrtTm() {
		return strCrtTm;
	}


	public void setStrCrtTm(String strCrtTm) {
		this.strCrtTm = strCrtTm;
	}


	public String getStrCrtTs() {
		return strCrtTs;
	}


	public void setStrCrtTs(String strCrtTs) {
		this.strCrtTs = strCrtTs;
	}


	public String getStrUpdTs() {
		return strUpdTs;
	}


	public void setStrUpdTs(String strUpdTs) {
		this.strUpdTs = strUpdTs;
	}


	@Override
	public String toString() {
		return "TransactionDetails [srcRefNo=" + srcRefNo + ", srcSysCd=" + srcSysCd + ", adtVrsnNo=" + adtVrsnNo
				+ ", acctCat=" + acctCat + ", acctNo=" + acctNo + ", acctTypCd=" + acctTypCd + ", baseAmt=" + baseAmt
				+ ", baseCcyCd=" + baseCcyCd + ", baseFxRate=" + baseFxRate + ", bulkId=" + bulkId + ", ccyIsoCd="
				+ ccyIsoCd + ", crtTm=" + crtTm + ", crtTs=" + crtTs + ", crtUsrId=" + crtUsrId + ", dbCrCd=" + dbCrCd
				+ ", domainNm=" + domainNm + ", fxRt=" + fxRt + ", grpBrId=" + grpBrId + ", grpOffId=" + grpOffId
				+ ", grpRefId=" + grpRefId + ", instrAmt=" + instrAmt + ", instrCcyCd=" + instrCcyCd + ", intrDirCd="
				+ intrDirCd + ", intrTypCd=" + intrTypCd + ", msgBrId=" + msgBrId + ", msgCnt=" + msgCnt + ", msgOffId="
				+ msgOffId + ", msgRefId=" + msgRefId + ", origRefId=" + origRefId + ", postEntrTyp=" + postEntrTyp
				+ ", postOvrCd=" + postOvrCd + ", procStat=" + procStat + ", tranAmt=" + tranAmt + ", reqTypCd="
				+ reqTypCd + ", rsvId=" + rsvId + ", thrtlGrpId=" + thrtlGrpId + ", trnNarr=" + trnNarr + ", updTs="
				+ updTs + ", updUsrId=" + updUsrId + ", valDt=" + valDt + ", vrsnNo=" + vrsnNo + ", strCrtTm="
				+ strCrtTm + ", strCrtTs=" + strCrtTs + ", strUpdTs=" + strUpdTs + "]";
	}


	




}
