/**
 * File: AdjustmentRequest.java
 * Description: Model for Adjustment creation request JSON
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Dec 22, 2016
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class AdjustmentRequest implements Serializable{


	private static final long serialVersionUID = 1L;
	
	
	private String accountNo;
	private String accountBranch;
	private BigDecimal amount;	
	private String sign;
	private String valueDate; //dd-MMM-yy
	private String aprvDcsnCd;
	private String userId;
	private String adjustmentResason;
	private String comment;
	
	public String getAccountNo() {
		return accountNo;
	}
	
	
	public String getAccountBranch() {
		return accountBranch;
	}


	public void setAccountBranch(String accountBranch) {
		this.accountBranch = accountBranch;
	}


	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getValueDate() {
		return valueDate;
	}


	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}


	public String getAprvDcsnCd() {
		return aprvDcsnCd;
	}
	public void setAprvDcsnCd(String aprvDcsnCd) {
		this.aprvDcsnCd = aprvDcsnCd;
	}	

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getAdjustmentResason() {
		return adjustmentResason;
	}
	public void setAdjustmentResason(String adjustmentResason) {
		this.adjustmentResason = adjustmentResason;
	}

	@Override
	public String toString() {
		return "AdjustmentRequest [accountNo=" + accountNo + ", accountBranch=" + accountBranch + ", amount=" + amount
				+ ", sign=" + sign + ", valueDate=" + valueDate + ", aprvDcsnCd=" + aprvDcsnCd + ", userId=" + userId
				+ ", adjustmentResason=" + adjustmentResason + ", comment=" + comment + "]";
	}


	
	
	



}
