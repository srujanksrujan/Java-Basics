/**
 * File: AccountHandler.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 5, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.handler;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnym.rpx.throttler.service.builder.RefDataBuilder;
import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.exception.NoDataFoundException;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.DomainUrl;
import com.bnym.rpx.throttler.service.model.Result;
import com.bnym.rpx.throttler.service.util.HostIdentifier;

@Service
public class RefDataHandler {

	private static final Logger LOGGER = Logger.getLogger(RefDataHandler.class);

	@Autowired
	private RefDataBuilder refDataBuilder;
 
	@Autowired
	private PropertyFileHandler propertyFileHandler;

	private HostIdentifier hostInfo;

	public HostIdentifier getHostInfo() {
		return hostInfo;
	}

	@Autowired
	public void setHostInfo(HostIdentifier hostInfo) {
		this.hostInfo = hostInfo;
	}

	public APIResponse getAllAccounts() throws ApplicationException {
		try {
			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("getAllAccounts() called in RefDataHandler :");
			}
			return refDataBuilder.buildGetAllAccountsResponse();
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}

	public APIResponse getAdjReasons() throws ApplicationException {
		try {
			LOGGER.info("getAdjReasons() called in RefDataHandler :");
			return refDataBuilder.buildGetAdjReasonsResponse();
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}

	public APIResponse getBusinessDate() throws ApplicationException {
		try {
			LOGGER.info("getBusinessDate() called in RefDataHandler :");
			return refDataBuilder.getBusinessDate();
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}

	public APIResponse getAdjStatus() throws ApplicationException {
		try {
			LOGGER.info("getAdjStatus() called in RefDataHandler :");
			return refDataBuilder.buildGetAdjStatusResponse();
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
	}

	public APIResponse getAllServiceDomainUrls() throws ApplicationException {
		List<DomainUrl> domainUrlList;
		APIResponse apiResponse = new APIResponse();
		String region = null;
		try {
			LOGGER.info("getAllServiceDomainUrls() called in RefDataHandler :");
			region = getRegion();
			LOGGER.info("Region : " + region);
			domainUrlList = propertyFileHandler.buildGetDomainUrlResponse(region);
			LOGGER.info("Domain Url List : " + domainUrlList.toString());
			apiResponse.setResult(new Result(new ArrayList<Object>(domainUrlList)));
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return apiResponse;
	}

	public String getRegion() throws Exception {
		return hostInfo.getRegion();
	}

	/**
	 * Gets the list of configs which are active for the given configName
	 * 
	 * @param configName
	 * @return APIResponse which contains the result list
	 * @throws ApplicationException
	 *             if any exception occurs
	 * @throws NoDataFoundException
	 *             if no data found
	 */
	public APIResponse getActiveConfigs(String configName) throws ApplicationException, NoDataFoundException {

		return refDataBuilder.getActiveConfigs(configName);

	}
}
