package com.bnym.rpx.throttler.service.handler;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnym.rpx.throttler.service.dao.impl.TransactionMessageDAOImpl;
import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.Result;
import com.bnym.rpx.throttler.service.model.TransactionMessageDetails;

@Service
public class TransactionMessageHandler {

	private static final Logger LOGGER = Logger.getLogger(TransactionMessageHandler.class);
	private static final String EXCEPTION = "Exception :";

	private TransactionMessageDAOImpl transactionMessageDAOImpl;

	public TransactionMessageDAOImpl getTransactionMessageDAOImpl() {
		return transactionMessageDAOImpl;
	}

	@Autowired
	public void setTransactionMessageDAOImpl(TransactionMessageDAOImpl transactionMessageDAOImpl) {
		this.transactionMessageDAOImpl = transactionMessageDAOImpl;
	}

	public APIResponse getTranactionMessageDetails(String referenceNumber, String paymentStatus)
			throws ApplicationException {
		List<TransactionMessageDetails> transactionMessageDetailsList;
		APIResponse apiResponse = new APIResponse();
		
		if (paymentStatus.equals("Released")) {
			paymentStatus = "RELD";
		}
		if (paymentStatus.equals("Notified")) {
			paymentStatus = "NOTIFY";
		}
		try {
			transactionMessageDetailsList = transactionMessageDAOImpl.getTranactionMessageDetails(referenceNumber,
					paymentStatus);
			if (transactionMessageDetailsList != null && transactionMessageDetailsList.size() > 0) {
				apiResponse.setResult(new Result(new ArrayList<Object>(transactionMessageDetailsList)));
			} else {
				apiResponse.setResult(null);
			}
		} catch (Exception ex) {
			LOGGER.info("Exception while getting getTranactionMessageDetails : " + ex.getMessage());
			throw new ApplicationException(EXCEPTION + ex.getMessage(), ex);
		}
		return apiResponse;
	}

}