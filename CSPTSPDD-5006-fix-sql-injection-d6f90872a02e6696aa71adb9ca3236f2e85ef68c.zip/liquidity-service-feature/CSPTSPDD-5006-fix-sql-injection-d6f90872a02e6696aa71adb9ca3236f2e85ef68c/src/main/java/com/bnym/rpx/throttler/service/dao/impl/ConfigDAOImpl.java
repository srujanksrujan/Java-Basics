/**
 * File: ConfigDAOImpl.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 18, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.bnym.rpx.throttler.service.dao.ConfigDAO;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.exception.NoDataFoundException;
import com.bnym.rpx.throttler.service.model.BusinessDate;
import com.bnym.rpx.throttler.service.model.Config;

@Repository
public class ConfigDAOImpl extends GenericDAO  implements ConfigDAO {
	
	private static final Logger LOGGER = Logger.getLogger(ConfigDAOImpl.class);
	private static final String EXCEPTION = "Exception:" ;
	
	@Autowired
	private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
	
	@Override
	public List<Config>  getAdjustmentReasons() throws DAOException {
		try {
			LOGGER.info("getAdjustmentReasons() called in ConfigDAOImpl*************** ");
			String sql = "SELECT KEY_NM, VAL_NM FROM T_GVP_THRTL_CONFIG WHERE FUN_NM = 'ADJ_REASON' ORDER BY VAL_NM" ;
			return getJdbcTemplate().query(sql,	new BeanPropertyRowMapper<Config>(Config.class));	
		} catch(Exception e){
			LOGGER.error("Exception whlie calling getAdjustmentReasons() in ConfigDAOImpl: "+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	public List<Config> getAdjustmentStatus() throws DAOException {
		try {
			LOGGER.info("getAdjustmentReasons() called in ConfigDAOImpl*************** ");
			String sql = "SELECT KEY_NM, VAL_NM FROM T_GVP_THRTL_CONFIG WHERE FUN_NM = 'ADJ_STATUS' ORDER BY VAL_NM " ;
			 return getJdbcTemplate().query(sql,	new BeanPropertyRowMapper<Config>(Config.class));	
		} catch(Exception e){
			LOGGER.error("Exception whlie calling getAdjustmentReasons()  ConfigDAOImpl: "+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
	
	@Override
	public List<Config> getActiveConfigs(String configName) throws DAOException,NoDataFoundException {
		try {
			if(StringUtils.isEmpty(configName)){
				throw new DAOException("Parameter configName should not be null");
			}
			
			MapSqlParameterSource parameterSource=new  MapSqlParameterSource();
			parameterSource.addValue("fun_nm", configName);
			String sql = "SELECT KEY_NM AS keyNm, VAL_NM as valNm FROM T_GVP_THRTL_CONFIG WHERE FUN_NM = :fun_nm and ACTV_FL='Y' ORDER BY VAL_NM " ;
			List<Config> configList = namedParameterJdbcTemplate.query(sql,parameterSource,new BeanPropertyRowMapper<Config>(Config.class));
			if(configList.isEmpty()){
				throw new NoDataFoundException();
			}
			return configList;
		} catch(DataAccessException e){
			LOGGER.error("Exception while calling getActiveConfigs()  ConfigDAOImpl: "+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
	
	@Override
	public List<BusinessDate> getBusinessDate() throws DAOException {
		List<BusinessDate> businessDateList = new ArrayList<BusinessDate>();
		BusinessDate businessDateObj = new BusinessDate();
		try {
			LOGGER.info("getBusinessDate() called in ConfigDAOImpl");
			String sql = "select to_char(sysdate) as bussiness_date from dual";
			businessDateObj.setBusinessDate((String)getJdbcTemplate().queryForObject(sql, null, String.class));
			businessDateList.add(businessDateObj);
		} catch(Exception e){
			LOGGER.error("Exception whlie calling getAdjustmentReasons() in ConfigDAOImpl: "+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
		return businessDateList;
	}
	
 
}
