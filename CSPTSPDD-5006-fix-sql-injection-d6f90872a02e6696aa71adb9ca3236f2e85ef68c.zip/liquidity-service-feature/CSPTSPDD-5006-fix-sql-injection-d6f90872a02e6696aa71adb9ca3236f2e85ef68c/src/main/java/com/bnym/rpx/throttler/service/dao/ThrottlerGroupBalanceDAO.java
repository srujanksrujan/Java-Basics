package com.bnym.rpx.throttler.service.dao;

import java.util.List;

import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.ThrottlerGroupModel;

public interface ThrottlerGroupBalanceDAO {
	public List  getAnalyticsAccountLiquidity(String currentDBTimestamp) throws DAOException;
	public String getCurrentDBTimestamp() throws DAOException;
	public ThrottlerGroupModel getThrottlerGroup(String accountNumber, String accountBranchCode,String accountSourceSystemCode) throws DAOException;
}
