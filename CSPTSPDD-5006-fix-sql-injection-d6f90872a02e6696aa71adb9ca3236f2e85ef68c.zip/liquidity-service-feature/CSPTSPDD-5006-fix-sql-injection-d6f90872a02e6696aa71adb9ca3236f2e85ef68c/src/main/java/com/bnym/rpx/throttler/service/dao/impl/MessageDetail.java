package com.bnym.rpx.throttler.service.dao.impl;

public class MessageDetail {

}
