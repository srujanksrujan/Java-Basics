package com.bnym.rpx.throttler.service.util;

public enum TransactionProcessStatusType {

	ARELD("ARELD","Already Released"), 
	CAN("CAN", "Cancelled"), 
	DUP("DUP", "Duplicate"),
	EXCP("EXCP", "Exception"),
	NOTIFY("NOTIFY", "Notified"),
	RELD("RELD", "Released"),
	WAIT("WAIT", "Waiting"),
	OTHER("", "");

	private String code;
	private String description;

	TransactionProcessStatusType() {
	}

	TransactionProcessStatusType(String code, String description) {
		this.code = code;
		this.description = description;
	}

	public String code() {
		return (this.code != null) ? this.code : "";
	}

	public String description() {
		return (this.description != null) ? this.description : "";
	}

	public static TransactionProcessStatusType value(String code) {
		if (code == null) {
			return OTHER;
		}
		for (TransactionProcessStatusType event : TransactionProcessStatusType.values()) {
			if (event.code().equals(code)) {
				return event;
			}
		}
		return OTHER;
	}
	public static TransactionProcessStatusType valueFromDescritpion(String description) {
		if (description == null) {
			return OTHER;
		}
		for (TransactionProcessStatusType event : TransactionProcessStatusType.values()) {
			if (event.description().equals(description)) {
				return event;
			}
		}
		return OTHER;
	}
}
