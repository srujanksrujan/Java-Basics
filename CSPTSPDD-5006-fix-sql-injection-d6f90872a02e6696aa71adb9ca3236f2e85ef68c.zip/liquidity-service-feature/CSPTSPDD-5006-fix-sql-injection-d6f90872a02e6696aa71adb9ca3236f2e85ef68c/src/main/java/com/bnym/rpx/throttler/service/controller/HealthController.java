package com.bnym.rpx.throttler.service.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
@Api(value = "App Engine Health Check ")
@RequestMapping(value = "/health")
@RestController
public class HealthController {
	private final Logger LOGGER = LoggerFactory.getLogger(HealthController.class);
	@ApiOperation(value = "Health Check", httpMethod = "GET", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = String.class),
			@ApiResponse(code = 500, message = "Internal Server Error") })
	@RequestMapping(value = "/status", method = RequestMethod.GET)
	public ResponseEntity<String> queueList() {
		LOGGER.info("Health Check Request ..");
		return new ResponseEntity<>("OK", HttpStatus.OK);
	}
	
	
	@ApiOperation(value = "Simulate JVM Crash", httpMethod = "GET", response = String.class)
	@ApiResponses(value = { @ApiResponse(code = 200, message = "Success", response = String.class),
			@ApiResponse(code = 500, message = "Internal Server Error") })
	@RequestMapping(value = "/crash", method = RequestMethod.GET)
	public ResponseEntity<String> simulateCrash(
			@ApiParam(value = "Weapon", allowableValues = "INFINITE_THREAD,OUT_OF_MEMORY,RUNTIME_HALT", required = true)
			@RequestParam("weapon") String weapon) {
		LOGGER.info("Health Check Request ..");
		/*switch (weapon) {
		case "INFINITE_THREAD":
			final Runnable[] arr = new Runnable[1];
			arr[0] = () -> {
				while (true) {
					new Thread(arr[0]).start();
				}
			};
			arr[0].run();
			break;
		case "OUT_OF_MEMORY":
			int arraySize = 20;
			// Create arrays in an infinite loop
			while (true) {
				LOGGER.info("Available memory (in bytes): " + Runtime.getRuntime().freeMemory());
				int[] fillMemory = new int[arraySize];
				arraySize = arraySize * 5;
			}
		case "RUNTIME_HALT":
			Runtime.getRuntime().halt(500);
			break;
		}*/
		return new ResponseEntity<>("OK", HttpStatus.OK);
	}
}