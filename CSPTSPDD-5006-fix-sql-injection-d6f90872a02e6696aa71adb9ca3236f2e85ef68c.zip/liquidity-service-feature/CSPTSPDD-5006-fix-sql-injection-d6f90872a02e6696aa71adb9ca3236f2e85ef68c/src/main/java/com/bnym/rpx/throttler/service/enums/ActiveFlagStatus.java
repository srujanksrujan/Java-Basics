package com.bnym.rpx.throttler.service.enums;

public enum ActiveFlagStatus {
	YES("YES", "Y"), NO("NO", "N");

	private String name;
	private String code;

	private ActiveFlagStatus(String name, String code) {
		this.name = name;
		this.code = code;
	}

	public String getName() {
		return (this.name != null) ? this.name : "";
	}

	public String getCode() {
		return (this.code != null) ? this.code : "";
	}

	public static ActiveFlagStatus value(String name) {
		if (name == null) {
			return null;
		}
		for (ActiveFlagStatus event : ActiveFlagStatus.values()) {
			if (event.getName().equals(name)) {
				return event;
			}
		}
		return null;
	}
}
