/**
 * Description
 *
 * @author  Swati Rashmi
 * @version 1.0
 * @since   Dec 13, 2016
 */
package com.bnym.rpx.throttler.service.handler;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.Result;

@PropertySource("classpath:config/config.properties")
@Service
public class ThrottlerSupportHTTPHandler {

	@Autowired
	HTTPClientService httpClientService;

	@Value("${calculator.accounts.refresh.url}")
	private String calculatorAccountsRefreshURL;

	@Value("${scheduler.accounts.refresh.url}")
	private String schedulerAccountsRefreshURL;

	private static final Logger LOGGER = Logger.getLogger(ThrottlerSupportHTTPHandler.class);

	public APIResponse refreshCalculatorAccounts(String hostName, String portNumber) throws ApplicationException {
		APIResponse apiResponse = new APIResponse();
		String baseUrl = "http://" + hostName + ":" + portNumber + calculatorAccountsRefreshURL;
		try {
			LOGGER.info("baseUrl : " + baseUrl);
			if (hostName != null && portNumber != null) {
				List<String> urlResponse = new ArrayList<>();
				String response = httpClientService.getHttpUrlResponse(baseUrl);
				urlResponse.add(response);
				apiResponse.setResult(new Result(new ArrayList<Object>(urlResponse)));
			}
		} catch (ApplicationException ex) {
			throw new ApplicationException("Exception while refreshing calculator account : " + ex.getMessage());
		}
		return apiResponse;
	}

	public APIResponse refreshSchedulerAccounts(String hostName, String portNumber) throws ApplicationException {
		APIResponse apiResponse = new APIResponse();
		String baseUrl = "http://" + hostName + ":" + portNumber + schedulerAccountsRefreshURL;
		try {
			LOGGER.info("baseUrl : " + baseUrl);
			if (hostName != null && portNumber != null) {
				List<String> urlResponse = new ArrayList<>();
				String response = httpClientService.getHttpUrlResponse(baseUrl);
				urlResponse.add((response));
				apiResponse.setResult(new Result(new ArrayList<Object>(urlResponse)));
			}
		} catch (Exception ex) {
			throw new ApplicationException("Exception while refreshing scheduler account : " + ex.getMessage());
		}
		return apiResponse;
	}

}
