package com.bnym.rpx.throttler.service.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class AdjustmentInputRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String accountNo;
	private Date frmValueDate;
	private Date toValueDate;
	private BigDecimal frmAmount;
	private BigDecimal toAmount;
	private String inAdjusted;
	private String outAdjusted;
	private String status;
 

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public Date getFrmValueDate() {
		return frmValueDate;
	}

	public void setFrmValueDate(Date frmValueDate) {
		this.frmValueDate = frmValueDate;
	}

	public Date getToValueDate() {
		return toValueDate;
	}

	public void setToValueDate(Date toValueDate) {
		this.toValueDate = toValueDate;
	}

	public BigDecimal getFrmAmount() {
		return frmAmount;
	}

	public void setFrmAmount(BigDecimal frmAmount) {
		this.frmAmount = frmAmount;
	}

	public BigDecimal getToAmount() {
		return toAmount;
	}

	public void setToAmount(BigDecimal toAmount) {
		this.toAmount = toAmount;
	}

	public String getInAdjusted() {
		return inAdjusted;
	}

	public void setInAdjusted(String inAdjusted) {
		this.inAdjusted = inAdjusted;
	}

	public String getOutAdjusted() {
		return outAdjusted;
	}

	public void setOutAdjusted(String outAdjusted) {
		this.outAdjusted = outAdjusted;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "AdjustmentInputRequest [accountNo=" + accountNo + ", frmValueDate=" + frmValueDate + ", toValueDate="
				+ toValueDate + ", frmAmount=" + frmAmount + ", toAmount=" + toAmount + ", inAdjusted=" + inAdjusted
				+ ", outAdjusted=" + outAdjusted + ", status=" + status + "]";
	}

 

}
