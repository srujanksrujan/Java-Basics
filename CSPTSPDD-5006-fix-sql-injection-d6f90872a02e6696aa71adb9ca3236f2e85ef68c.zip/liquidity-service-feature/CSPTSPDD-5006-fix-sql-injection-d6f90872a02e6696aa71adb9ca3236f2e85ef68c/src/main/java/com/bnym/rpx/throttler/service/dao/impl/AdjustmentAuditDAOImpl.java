/**
 * File: AdjustmentAuditDAOImpl.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Dec 20, 2016
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.dao.impl;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.bnym.rpx.throttler.service.builder.AdjustmentBuilder;
import com.bnym.rpx.throttler.service.dao.AdjustmentAuditDAO;
import com.bnym.rpx.throttler.service.entity.Adjustment;
import com.bnym.rpx.throttler.service.exception.DAOException;

@Repository
public class AdjustmentAuditDAOImpl extends GenericDAO  implements AdjustmentAuditDAO {

	private static final Logger LOGGER = Logger.getLogger(AdjustmentBuilder.class);
	private static final String EXCEPTION = "Exception:"; 
	@Override
	public Long findLastAuditVersionNo(String adjustmentId) throws DAOException {
		Long lastAuditVsrnNo = (long) 0;
		try {
			String sql = "select NVL(max(ADT_VRSN_NO)  , 0)  from T_GVP_THRTL_ADJ_ADT where ADJ_ID = ?";
			lastAuditVsrnNo = getJdbcTemplate().queryForObject(sql, new Object[] { adjustmentId }, Long.class);
			
		} catch (DataAccessException e) {
			LOGGER.error("Exception whlie calling findLastAuditVersionNo()  for adjustmentId=" + adjustmentId + "in AdjustmentAuditDAOImpl:" + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
			
		} catch (Exception e) {
			LOGGER.error("Exception whlie calling findLastAuditVersionNo() for adjustmentId=" + adjustmentId +" in AdjustmentAuditDAOImpl:" + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
		return lastAuditVsrnNo;
	}
	
	
	@Override
	public int insertAdjustmentAudit(Adjustment adjustment) throws DAOException {
		try {
			LOGGER.info("insertAdjustment() called in AdjustmentAuditDAOImpl" );

			String sql = "Insert into T_GVP_THRTL_ADJ_ADT "
				+ "(ADJ_ID,BULK_ID,VAL_DT,ADT_VRSN_NO,PROC_STAT,ACCT_NO,ACCT_BR_CD,ACCT_SRC_SYS_CD,"
				+ "THRTL_GRP_ID,PY_AMT,ADJ_IN_OUT_CD,ADJ_RSN_TX,CMNT_TX,CRT_USR_ID,CRT_TS,UPD_USR_ID,"
				+ "UPD_TS,APRV_USR_ID,APRV_TS,APRV_DCSN_CD) values (?,?,?,?,? ,?,?,?,?,? ,?,?,?,?,? ,?,?,?,?,?)";

			return getJdbcTemplate().update(sql, 
					adjustment.getAdjId(),	
					null,					 
					adjustment.getValDt(),
					adjustment.getAdtVrsnNo(),
					adjustment.getProcStat(),
					adjustment.getAcctNo(),
					adjustment.getAcctBrCd(),
					adjustment.getAcctSrcSysCd(),
					adjustment.getThrtlGrpId(),
					adjustment.getPyAmt(),
					adjustment.getAdjInOutCd(),
					adjustment.getAdjRsnTx(),
					adjustment.getCmntTx(),
					adjustment.getCrtUsrId(),
					adjustment.getCrtTs(),
					adjustment.getUpdUsrId(),
					adjustment.getUpdTs(),
					adjustment.getAprvUsrId(),
					adjustment.getAprvTs(),
					adjustment.getAprvDcsnCd()
			);
			
		}  catch(Exception e){
			LOGGER.error("Exception whlie calling insertAdjustmentAudit() in AdjustmentAuditDAOImpl:"+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
}
