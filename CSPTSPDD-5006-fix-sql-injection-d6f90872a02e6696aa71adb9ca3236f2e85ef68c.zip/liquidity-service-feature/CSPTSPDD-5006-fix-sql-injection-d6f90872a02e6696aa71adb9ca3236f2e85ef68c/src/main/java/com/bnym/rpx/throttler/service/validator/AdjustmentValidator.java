/**
 * File: AdjustmentValidator.java
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").
 * 
 * @author  Swati Rashmi
 * @version 1.0
 * @since   Dec 19, 2016
 * 
 */
package com.bnym.rpx.throttler.service.validator;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bnym.rpx.throttler.service.exception.DAOException;


@Component
public class AdjustmentValidator {

	private static final Logger LOGGER = Logger.getLogger(AdjustmentValidator.class);

	@Autowired
	private com.bnym.rpx.throttler.service.dao.impl.AccountLiquidityDAOImpl accountLiquidityDAOImpl;


	public boolean validateAccountNo(String accountNo) throws DAOException{
		try {
			Integer count = accountLiquidityDAOImpl.findAccountByAccNo(accountNo);
			LOGGER.info("validateAccountNo() of AdjustmentValidator called. Count:" + count);
			return  (count > 0) ? true : false ;
		} catch (Exception e) {
			throw new DAOException("Exception whlie calling RTP Procedure ", e);
		}

	}


}
