/**
 * File: TransactionDAOImpl.java
 * Description: 
 * Project - Real Time Payment (RPX)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 6, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.dao.impl;

import org.apache.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;

import com.bnym.rpx.throttler.service.dao.TransactionDAO;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.handler.PaginationHandler;
import com.bnym.rpx.throttler.service.model.Page;
import com.bnym.rpx.throttler.service.model.Transaction;
import com.bnym.rpx.throttler.service.model.TransactionDetails;
import com.bnym.rpx.throttler.service.model.TransactionDetailsRowMapper;
import com.bnym.rpx.throttler.service.model.TransactionRowMapper;
import com.bnym.rpx.throttler.service.model.TransactionsInputRequest;

@Repository
public class TransactionDAOImpl extends GenericDAO implements TransactionDAO {

	private static final Logger LOGGER = Logger.getLogger(TransactionDAOImpl.class);
	private static final String EXCEPTION = "Exception:";

	@Override
	public TransactionDetails getTranactionDetails(String tranType, String srcRefNo, String srcSysCd, String adtVrsnNo)
			throws DAOException {
		try {

			if (tranType.equalsIgnoreCase("P")) {
				String sql = " SELECT 'P' AS TRAN_TYPE,SRC_REF_NO, SRC_SYS_CD, ADT_VRSN_NO , PROC_STAT, THRTL_GRP_ID,BULK_ID, DOMAIN_NM ,INTR_DIR_CD , "
						+ " INTR_TYP_CD , REQ_TYP_CD , VRSN_NO , GRP_OFF_ID, GRP_BR_ID , MSG_CNT, GRP_REF_ID , CRT_TM  , MSG_REF_ID, ORIG_REF_ID,"
						+ " MSG_OFF_ID , MSG_BR_ID , RSV_ID,POST_ENTR_TYP,ACCT_NO ,ACCT_BR_CD , ACCT_SRC_SYS_CD , ACCT_CAT ,CCY_ISO_CD ,"
						+ " ACCT_TYP_CD  , VAL_DT  , DB_CR_CD  , POST_OVR_CD  , TRN_NARR  ,INSTR_CCY_CD , INSTR_AMT , FX_RT  ,"
						+ " BASE_CCY_CD , BASE_AMT, BASE_FX_RATE , CRT_USR_ID,CRT_TS , UPD_USR_ID , UPD_TS , "
						+ " TO_CHAR(CRT_TM,  'DD-MON-YYYY HH24:MI:SS') AS STR_CRT_TM , "
						+ " TO_CHAR(CRT_TS,  'DD-MON-YYYY HH24:MI:SS') AS STR_CRT_TS , "
						+ " TO_CHAR(UPD_TS,  'DD-MON-YYYY HH24:MI:SS') AS STR_UPD_TS , PY_AMT AS AMT FROM T_GVP_THRTL_PY_RQST_ADT "
						+ " WHERE SRC_REF_NO = ? AND SRC_SYS_CD = ? AND ADT_VRSN_NO = ? ";

				return getJdbcTemplate().queryForObject(sql, new TransactionDetailsRowMapper(), srcRefNo, srcSysCd,
						adtVrsnNo);
			} else {
				String sql = " SELECT 'C' AS TRAN_TYPE,SRC_REF_NO, SRC_SYS_CD, ADT_VRSN_NO , PROC_STAT, THRTL_GRP_ID,BULK_ID, DOMAIN_NM ,INTR_DIR_CD , "
						+ " INTR_TYP_CD , REQ_TYP_CD , VRSN_NO , GRP_OFF_ID, GRP_BR_ID , MSG_CNT, GRP_REF_ID , CRT_TM  , MSG_REF_ID, ORIG_REF_ID,"
						+ " MSG_OFF_ID , MSG_BR_ID , RSV_ID,POST_ENTR_TYP,ACCT_NO ,ACCT_BR_CD , ACCT_SRC_SYS_CD , ACCT_CAT ,CCY_ISO_CD ,"
						+ " ACCT_TYP_CD  , VAL_DT  , DB_CR_CD  , POST_OVR_CD  , TRN_NARR  ,INSTR_CCY_CD , INSTR_AMT , FX_RT  ,"
						+ " BASE_CCY_CD , BASE_AMT, BASE_FX_RATE , CRT_USR_ID,CRT_TS , UPD_USR_ID , UPD_TS , "
						+ " TO_CHAR(CRT_TM,  'DD-MON-YYYY HH24:MI:SS') AS STR_CRT_TM , "
						+ " TO_CHAR(CRT_TS,  'DD-MON-YYYY HH24:MI:SS') AS STR_CRT_TS , "
						+ " TO_CHAR(UPD_TS,  'DD-MON-YYYY HH24:MI:SS') AS STR_UPD_TS , CR_AMT AS AMT FROM T_GVP_THRTL_CR_RQST_ADT "
						+ " WHERE SRC_REF_NO = ? AND SRC_SYS_CD = ? AND ADT_VRSN_NO = ? ";

				return getJdbcTemplate().queryForObject(sql, new TransactionDetailsRowMapper(), srcRefNo, srcSysCd,
						adtVrsnNo);
			}
		} catch (EmptyResultDataAccessException e) {
			LOGGER.info("No transaction record found with  srcRefNo:" + srcRefNo + " srcSysCd:" + srcSysCd
					+ " adtVrsnNo:" + adtVrsnNo);
			return null;
		} catch (Exception e) {
			LOGGER.error("Exception whlie calling getTranactionDetails() in TransactionDAOImpl:" + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}

	}

	@Override
	public Page<Transaction> getAllTransactions(TransactionsInputRequest transactionsInputRequest) throws DAOException {
		try {

			PaginationHandler<Transaction> handler = new PaginationHandler<>();
			
			StringBuilder sqlWhere = buildSqlWhere(transactionsInputRequest);
			StringBuilder sqlWherePyAmt = new StringBuilder();
			StringBuilder sqlWhereCrAmt = new StringBuilder();

			if (transactionsInputRequest.getFromAmount() != null) {
				if (sqlWhere.length() == 0) {
					sqlWherePyAmt.append(" WHERE PY_AMT >= '").append(transactionsInputRequest.getFromAmount())
							.append("'");
					sqlWhereCrAmt.append(" WHERE CR_AMT >= '").append(transactionsInputRequest.getFromAmount())
							.append("'");
				} else {
					sqlWherePyAmt.append(" AND PY_AMT >= '").append(transactionsInputRequest.getFromAmount())
							.append("'");
					sqlWhereCrAmt.append(" AND CR_AMT >= '").append(transactionsInputRequest.getFromAmount())
							.append("'");
				}
			}

			if (transactionsInputRequest.getToAmount() != null) {
				if (sqlWhere.length() == 0 && sqlWherePyAmt.length() == 0 && sqlWhereCrAmt.length() == 0) {
					sqlWherePyAmt.append(" WHERE PY_AMT <= '").append(transactionsInputRequest.getToAmount())
							.append("'");
					sqlWhereCrAmt.append(" WHERE CR_AMT <= '").append(transactionsInputRequest.getToAmount())
							.append("'");
				} else {
					sqlWherePyAmt.append(" AND PY_AMT <= '").append(transactionsInputRequest.getToAmount()).append("'");
					sqlWhereCrAmt.append(" AND CR_AMT <= '").append(transactionsInputRequest.getToAmount()).append("'");
				}
			}
			StringBuilder sqlSort = buildSqlSort(transactionsInputRequest);

			StringBuilder sqlCountCr = new StringBuilder(" SELECT COUNT (*)  FROM T_GVP_THRTL_CR_RQST_ADT ")
					.append(sqlWhere.toString()).append(sqlWhereCrAmt.toString());

			StringBuilder sqlCountPy = new StringBuilder(" SELECT COUNT (*)  FROM T_GVP_THRTL_PY_RQST_ADT ")
					.append(sqlWhere.toString()).append(sqlWherePyAmt.toString());

			StringBuilder sqlSelectCr = new StringBuilder(
					" SELECT SRC_REF_NO, ADT_VRSN_NO, SRC_SYS_CD, MSG_REF_ID, ACCT_NO, VAL_DT, "
							+ " CR_AMT AMT, CCY_ISO_CD, UPD_TS,TO_CHAR(UPD_TS,  'DD-MON-YYYY HH12:MI:SS AM') AS STR_UPD_TS, PROC_STAT, 'CREDIT' AS TYPE_CD "
							+ " FROM T_GVP_THRTL_CR_RQST_ADT ").append(sqlWhere.toString())
									.append(sqlWhereCrAmt.toString());

			StringBuilder sqlSelcetPy = new StringBuilder(
					" SELECT SRC_REF_NO, ADT_VRSN_NO, SRC_SYS_CD, MSG_REF_ID, ACCT_NO, VAL_DT, "
							+ "PY_AMT AMT, CCY_ISO_CD, UPD_TS, TO_CHAR(UPD_TS,  'DD-MON-YYYY HH12:MI:SS AM') AS STR_UPD_TS,PROC_STAT, 'PAYMENT' AS TYPE_CD "
							+ "FROM T_GVP_THRTL_PY_RQST_ADT ").append(sqlWhere.toString())
									.append(sqlWherePyAmt.toString());

			StringBuilder sqlCountAll = new StringBuilder(" SELECT COUNT(*) FROM ( ").append(sqlSelectCr.toString())
					.append(" UNION ALL ").append(sqlSelcetPy.toString()).append(" ) ");

			StringBuilder sqlSelectAll = new StringBuilder(sqlSelectCr.toString()).append(" UNION ALL ")
					.append(sqlSelcetPy.toString()).append(sqlSort.toString());

			Page<Transaction> page = null;

			// Both Payments and Credits transactionss
			if (transactionsInputRequest.getTranType() == null) {
				page = handler.fetchPage(getJdbcTemplate(), sqlCountAll.toString(), sqlSelectAll.toString(),
						transactionsInputRequest.getPageNo(), transactionsInputRequest.getPageSize(),
						new TransactionRowMapper());

			} else {
				// if Payments
				if (transactionsInputRequest.getTranType().equalsIgnoreCase("P")) {
					page = handler.fetchPage(getJdbcTemplate(), sqlCountPy.toString(),
							sqlSelcetPy.append(sqlSort).toString(), transactionsInputRequest.getPageNo(),
							transactionsInputRequest.getPageSize(), new TransactionRowMapper());

					// if Credits
				} else if (transactionsInputRequest.getTranType().equalsIgnoreCase("C")) {
					page = handler.fetchPage(getJdbcTemplate(), sqlCountCr.toString(),
							sqlSelectCr.append(sqlSort).toString(), transactionsInputRequest.getPageNo(),
							transactionsInputRequest.getPageSize(), new TransactionRowMapper());

				}

			}
			return page;
		} catch (Exception e) {
			LOGGER.error("Exception whlie calling getAllTransactions() in TransactionDAOImpl: " + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	private StringBuilder buildSqlSort(TransactionsInputRequest transactionsInputRequest) {
		StringBuilder sqlSort = new StringBuilder();
		if (transactionsInputRequest.getSortKeys() != null) {
			sqlSort.append(" ORDER BY ").append(" ").append(transactionsInputRequest.getSortKeys()).append(" ");
		} else {
			sqlSort.append(" ORDER BY ").append(" SRC_REF_NO ASC , UPD_TS DESC ");
		}
		return sqlSort;
	}

	private StringBuilder buildSqlWhere(TransactionsInputRequest transactionsInputRequest) {
		StringBuilder sqlWhere = new StringBuilder();
		if (transactionsInputRequest.getRefNo() != null) {
			if (sqlWhere.length() == 0)
				sqlWhere.append(" WHERE  SRC_REF_NO = '").append(transactionsInputRequest.getRefNo()).append("'");
			else
				sqlWhere.append(" AND  SRC_REF_NO = '").append(transactionsInputRequest.getRefNo()).append("'");
		}

		if (transactionsInputRequest.getAcctNo() != null) {
			if (sqlWhere.length() == 0)
				sqlWhere.append(" WHERE  ACCT_NO = '").append(transactionsInputRequest.getAcctNo()).append("'");
			else
				sqlWhere.append(" AND  ACCT_NO = '").append(transactionsInputRequest.getAcctNo()).append("'");
		}

		if (transactionsInputRequest.getFromValueDate() != null) {
			if (sqlWhere.length() == 0)
				sqlWhere.append(" WHERE  TRUNC(VAL_DT) >= '").append(transactionsInputRequest.getFromValueDate())
						.append("'");
			else
				sqlWhere.append(" AND  TRUNC(VAL_DT) >=  '").append(transactionsInputRequest.getFromValueDate())
						.append("'");
		}
		sqlWhere = buildSqlWhere2(transactionsInputRequest, sqlWhere);

		return sqlWhere;
	}

	private StringBuilder buildSqlWhere2(TransactionsInputRequest transactionsInputRequest, StringBuilder sqlWhere) {
		if (transactionsInputRequest.getToValueDate() != null) {
			if (sqlWhere.length() == 0)
				sqlWhere.append(" WHERE  TRUNC(VAL_DT) <= '").append(transactionsInputRequest.getToValueDate())
						.append("'");
			else
				sqlWhere.append(" AND  TRUNC(VAL_DT) <= '").append(transactionsInputRequest.getToValueDate())
						.append("'");
		}

		if (transactionsInputRequest.getStatus() != null) {
			if (sqlWhere.length() == 0)
				sqlWhere.append(" WHERE  PROC_STAT = '").append(transactionsInputRequest.getStatus()).append("'");
			else
				sqlWhere.append(" AND  PROC_STAT = '").append(transactionsInputRequest.getStatus()).append("'");
		}

		if (transactionsInputRequest.getCcyCode() != null) {
			if (sqlWhere.length() == 0)
				sqlWhere.append(" WHERE  CCY_ISO_CD = '").append(transactionsInputRequest.getCcyCode()).append("'");
			else
				sqlWhere.append(" AND  CCY_ISO_CD =  '").append(transactionsInputRequest.getCcyCode()).append("'");
		}
		return sqlWhere;
	}

}
