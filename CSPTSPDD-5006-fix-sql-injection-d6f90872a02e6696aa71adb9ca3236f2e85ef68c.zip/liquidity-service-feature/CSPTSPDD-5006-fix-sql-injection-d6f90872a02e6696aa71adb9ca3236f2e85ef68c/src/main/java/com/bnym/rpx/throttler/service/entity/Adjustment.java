package com.bnym.rpx.throttler.service.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the T_GVP_THRTL_ADJ database table.
 * 
 */
@Entity
@Table(name = "T_GVP_THRTL_ADJ")
public class Adjustment implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "ADJ_ID")
	private String adjId;
	@Column(name = "BULK_ID")
	private String bulkId;
	@Column(name = "ACCT_BR_CD")
	private String acctBrCd;
	@Column(name = "ACCT_NO")
	private String acctNo;
	@Column(name = "ACCT_SRC_SYS_CD")
	private String acctSrcSysCd;
	@Column(name = "ADJ_IN_OUT_CD")
	private String adjInOutCd;
	@Column(name = "ADJ_RSN_TX")
	private String adjRsnTx;
	@Column(name = "ADT_VRSN_NO", insertable = false, updatable = false)
	private Long adtVrsnNo;
	@Column(name = "APRV_DCSN_CD")
	private String aprvDcsnCd;
	@Column(name = "APRV_TS")
	private Timestamp aprvTs;
	@Column(name = "APRV_USR_ID")
	private String aprvUsrId;
	@Column(name = "CMNT_TX")
	private String cmntTx;
	@Column(name = "CRT_TS")
	private Timestamp crtTs;
	@Column(name = "CRT_USR_ID")
	private String crtUsrId;
	@Column(name = "PROC_STAT")
	private String procStat;
	@Column(name = "PY_AMT")
	private BigDecimal pyAmt;
	@Column(name = "THRTL_GRP_ID")
	private String thrtlGrpId;
	@Column(name = "UPD_TS")
	private Timestamp updTs;
	@Column(name = "UPD_USR_ID")
	private String updUsrId;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "VAL_DT")
	private Date valDt;

	public void setPyAmt(BigDecimal pyAmt) {
		this.pyAmt = pyAmt;
	}

	public String getAdjId() {
		return this.adjId;
	}

	public void setAdjId(String adjId) {
		this.adjId = adjId;
	}

	public String getBulkId() {
		return bulkId;
	}

	public void setBulkId(String bulkId) {
		this.bulkId = bulkId;
	}

	public String getAcctBrCd() {
		return this.acctBrCd;
	}

	public void setAcctBrCd(String acctBrCd) {
		this.acctBrCd = acctBrCd;
	}

	public String getAcctNo() {
		return this.acctNo;
	}

	public void setAcctNo(String acctNo) {
		this.acctNo = acctNo;
	}

	public String getAcctSrcSysCd() {
		return this.acctSrcSysCd;
	}

	public void setAcctSrcSysCd(String acctSrcSysCd) {
		this.acctSrcSysCd = acctSrcSysCd;
	}

	public String getAdjInOutCd() {
		return this.adjInOutCd;
	}

	public void setAdjInOutCd(String adjInOutCd) {
		this.adjInOutCd = adjInOutCd;
	}

	public String getAdjRsnTx() {
		return this.adjRsnTx;
	}

	public void setAdjRsnTx(String adjRsnTx) {
		this.adjRsnTx = adjRsnTx;
	}

	public Long getAdtVrsnNo() {
		return this.adtVrsnNo;
	}

	public void setAdtVrsnNo(Long adtVrsnNo) {
		this.adtVrsnNo = adtVrsnNo;
	}

	public String getAprvDcsnCd() {
		return this.aprvDcsnCd;
	}

	public void setAprvDcsnCd(String aprvDcsnCd) {
		this.aprvDcsnCd = aprvDcsnCd;
	}

	public Timestamp getAprvTs() {
		return this.aprvTs;
	}

	public void setAprvTs(Timestamp aprvTs) {
		this.aprvTs = aprvTs;
	}

	public String getAprvUsrId() {
		return this.aprvUsrId;
	}

	public void setAprvUsrId(String aprvUsrId) {
		this.aprvUsrId = aprvUsrId;
	}

	public String getCmntTx() {
		return this.cmntTx;
	}

	public void setCmntTx(String cmntTx) {
		this.cmntTx = cmntTx;
	}

	public Timestamp getCrtTs() {
		return this.crtTs;
	}

	public void setCrtTs(Timestamp crtTs) {
		this.crtTs = crtTs;
	}

	public String getCrtUsrId() {
		return this.crtUsrId;
	}

	public void setCrtUsrId(String crtUsrId) {
		this.crtUsrId = crtUsrId;
	}

	public String getProcStat() {
		return this.procStat;
	}

	public void setProcStat(String procStat) {
		this.procStat = procStat;
	}

	public BigDecimal getPyAmt() {
		return this.pyAmt;
	}

	public String getThrtlGrpId() {
		return this.thrtlGrpId;
	}

	public void setThrtlGrpId(String thrtlGrpId) {
		this.thrtlGrpId = thrtlGrpId;
	}

	public Timestamp getUpdTs() {
		return this.updTs;
	}

	public void setUpdTs(Timestamp updTs) {
		this.updTs = updTs;
	}

	public String getUpdUsrId() {
		return this.updUsrId;
	}

	public void setUpdUsrId(String updUsrId) {
		this.updUsrId = updUsrId;
	}

	public Date getValDt() {
		return this.valDt;
	}

	public void setValDt(Date valDt) {
		this.valDt = valDt;
	}


	@Override
	public String toString() {
		return "Adjustment [adjId=" + adjId + ", bulkId=" + bulkId + ", acctBrCd=" + acctBrCd + ", acctNo=" + acctNo
				+ ", acctSrcSysCd=" + acctSrcSysCd + ", adjInOutCd=" + adjInOutCd + ", adjRsnTx=" + adjRsnTx
				+ ", adtVrsnNo=" + adtVrsnNo + ", aprvDcsnCd=" + aprvDcsnCd + ", aprvTs=" + aprvTs + ", aprvUsrId="
				+ aprvUsrId + ", cmntTx=" + cmntTx + ", crtTs=" + crtTs + ", crtUsrId=" + crtUsrId + ", procStat="
				+ procStat + ", pyAmt=" + pyAmt + ", thrtlGrpId=" + thrtlGrpId + ", updTs=" + updTs + ", updUsrId="
				+ updUsrId + ", valDt=" + valDt + "]";
	}

}