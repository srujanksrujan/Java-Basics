package com.bnym.rpx.throttler.service.dao;

import java.util.List;

import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.AnalyticAccountBalanceRowMapper;

public interface AnalyticsBalanceDAO {
	
	List<AnalyticAccountBalanceRowMapper> getAnalyticsBalance(String valueDate, String accountNumber)throws DAOException ;

}
