package com.bnym.rpx.throttler.service.model;

import java.util.Date;

public class ThrottlerAccountLiquidityTable {

	private String accountNumber;
	private String accountBranchCode;
	private String accountSourceSystemCode;
	private String throttlerGroupId;
	private String actlBalanceEffectiveTimestamp;
	private Number availableAmount;
	private String bulkId;
	private Date valDate;
	private String updatedUserId;
	private String updatedTimestamp;

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountBranchCode() {
		return accountBranchCode;
	}

	public void setAccountBranchCode(String accountBranchCode) {
		this.accountBranchCode = accountBranchCode;
	}

	public String getAccountSourceSystemCode() {
		return accountSourceSystemCode;
	}

	public void setAccountSourceSystemCode(String accountSourceSystemCode) {
		this.accountSourceSystemCode = accountSourceSystemCode;
	}

	public String getThrottlerGroupId() {
		return throttlerGroupId;
	}

	public void setThrottlerGroupId(String throttlerGroupId) {
		this.throttlerGroupId = throttlerGroupId;
	}

	public String getActlBalanceEffectiveTimestamp() {
		return actlBalanceEffectiveTimestamp;
	}

	public void setActlBalanceEffectiveTimestamp(String actlBalanceEffectiveTimestamp) {
		this.actlBalanceEffectiveTimestamp = actlBalanceEffectiveTimestamp;
	}

	public Number getAvailableAmount() {
		return availableAmount;
	}

	public void setAvailableAmount(Number availableAmount) {
		this.availableAmount = availableAmount;
	}

	public String getBulkId() {
		return bulkId;
	}

	public void setBulkId(String bulkId) {
		this.bulkId = bulkId;
	}

	public Date getValDate() {
		return valDate;
	}

	public void setValDate(Date valDate) {
		this.valDate = valDate;
	}

	public String getUpdatedUserId() {
		return updatedUserId;
	}

	public void setUpdatedUserId(String updatedUserId) {
		this.updatedUserId = updatedUserId;
	}

	public String getUpdatedTimestamp() {
		return updatedTimestamp;
	}

	public void setUpdatedTimestamp(String updatedTimestamp) {
		this.updatedTimestamp = updatedTimestamp;
	}

	@Override
	public String toString() {
		return "ThrottlerAccountLiquidityTable [accountNumber=" + accountNumber + ", accountBranchCode="
				+ accountBranchCode + ", accountSourceSystemCode=" + accountSourceSystemCode + ", throttlerGroupId="
				+ throttlerGroupId + ", actlBalanceEffectiveTimestamp=" + actlBalanceEffectiveTimestamp
				+ ", availableAmount=" + availableAmount + ", bulkId=" + bulkId + ", valDate=" + valDate
				+ ", updatedUserId=" + updatedUserId + ", updatedTimestamp=" + updatedTimestamp + "]";
	}

}
