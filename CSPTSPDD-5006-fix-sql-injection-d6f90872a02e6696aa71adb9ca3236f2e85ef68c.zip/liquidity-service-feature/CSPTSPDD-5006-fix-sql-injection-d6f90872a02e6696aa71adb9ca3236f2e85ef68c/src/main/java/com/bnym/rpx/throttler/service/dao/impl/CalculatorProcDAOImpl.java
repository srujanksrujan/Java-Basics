/**
 * File: CalculatorProcDAOImpl.java
 * Description: 
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").

 * Author: Swati Rashmi
 * Since: Jan 10, 2017
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.dao.impl;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.bnym.rpx.throttler.service.dao.CalculatorProcDAO;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.CalculatorProc;

@Repository
public class CalculatorProcDAOImpl extends GenericDAO  implements CalculatorProcDAO{

	private static final Logger LOGGER = Logger.getLogger(CalculatorProcDAOImpl.class);
	private static final String EXCEPTION = "Exception:" ;
	@Override
	public String getMessageId() throws DAOException {
		try {
			LOGGER.info("getMessageId() called in AdjustmentDAOImpl");
			String sql = "SELECT TO_CHAR(SYSTIMESTAMP,'ddMMRRRRhh24MIssFF6')||DBMS_RANDOM.string('X',5)||DBMS_RANDOM.string('X',5) as dtime FROM DUAL";
			return getJdbcTemplate().queryForObject(sql, String.class);			
		} catch (Exception e) {
			LOGGER.error("Exception whlie calling getMessageId() in AccountLiquidityDAOImpl :"+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
	
	@Override
	public String getCalProcSeqNo()  throws  DAOException{
		try {
			LOGGER.info("getCalProcSeqNo() called in CalculatorProcDAOImpl" );
			String sql = "SELECT TO_CHAR(SYSTIMESTAMP,'ddMMRRRRhh24MIssFF6')||DBMS_RANDOM.string('X',10) as dtime FROM DUAL";
			return getJdbcTemplate().queryForObject(sql, String.class); 

		} catch(Exception e){
			LOGGER.error("Exception whlie calling getAdjustmentId() in AccountLiquidityDAOImpl:"+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
	
	@Override
	public int insertCalProcRecord(CalculatorProc calRec) throws DAOException {
		try {
			LOGGER.info("insertCalProcRecord() called in CalculatorProcDAOImpl" );
			
		

			String sql = " Insert into T_GVP_THRTL_CAL_PROC "
					+ "(SEQ_NO,BULK_ID,THRTL_GRP_ID,SRC_REF_NO,SRC_SYS_CD,REQ_TYP_CD,PROC_STAT,MSG_REF_ID,"
					+ "CRT_TM,CCY_ISO_CD,AMT,VAL_DT,ACCT_NO,IN_OUT_CD,PY_CR_CD,CRT_USR_ID,CRT_TS,"
					+ "UPD_USR_ID,UPD_TS,IS_RQST_UPDT,NET_LIQUIDITY_CHANGE) "
					+ "VALUES (?,?,?,?,? ,?,?,?,?,? ,?,?,?,?,? ,?,?,?,?,? ,?)";

			return getJdbcTemplate().update(sql,  
					calRec.getSeqNo(),
					calRec.getBulkId(),
					calRec.getThrtlGrpId(),
					calRec.getSrcRefNo(),
					calRec.getSrcSysCd(),
					calRec.getReqTypCd(),
					calRec.getProcStat(),
					calRec.getMsgRefId(),
					calRec.getCrtTm(),
					calRec.getCcyIsoCd(),
					calRec.getAmt(),
					calRec.getValDt(),
					calRec.getAcctNo(),
					calRec.getInOutCd(),
					calRec.getPyCrCd(),
					calRec.getCrtUsrId(),
					calRec.getCrtTs(),
					calRec.getUpdUsrId(),
					calRec.getUpdTs(),
					calRec.getIsRqstUpdt(),
					calRec.getNetLiquidityChange()
			);

		} catch (DataAccessException e) {
			LOGGER.error("Exception whlie calling insertCalProcRecord() in CalculatorProcDAOImpl: "+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

}
