/**
* <p>File: DAOException.java 
* Project:	Liquidity Management (LQM)
* 
* Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
* 
* This software is the confidential and proprietary information of BNY Melon
* Corporation ("Confidential Information").
* 
* @author Swati Rashmi
* @version 1.0
*/
package com.bnym.rpx.throttler.service.exception;
/**
* The Class DAOException.
 */
public class DAOException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -1545351779297769157L;

	/**
	 * Instantiates a new dAO exception.
	 */
	public DAOException() {
		super();
	}

	/**
	 * Instantiates a new dAO exception.
	 * 
	 * @param message
	 *            the message
	 */
	public DAOException(final String message) {
		super(message);
	}

	/**
	 * Instantiates a new dAO exception.
	 * 
	 * @param message
	 *            the message
	 * @param throwable
	 *            the throwable
	 */
	public DAOException(final String message, final Throwable throwable) {
		super(message, throwable);
	}

	/**
	 * Instantiates a new dAO exception.
	 * 
	 * @param throwable
	 *            the throwable
	 */
	public DAOException(final Throwable throwable) {
		super(throwable);
	}
}
