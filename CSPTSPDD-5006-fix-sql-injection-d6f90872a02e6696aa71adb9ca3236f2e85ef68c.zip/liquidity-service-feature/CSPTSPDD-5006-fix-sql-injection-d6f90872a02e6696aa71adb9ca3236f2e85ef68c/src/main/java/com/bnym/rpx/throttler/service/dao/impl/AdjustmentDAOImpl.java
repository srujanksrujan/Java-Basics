package com.bnym.rpx.throttler.service.dao.impl;

import java.sql.Timestamp;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Repository;

import com.bnym.rpx.throttler.service.dao.AdjustmentDAO;
import com.bnym.rpx.throttler.service.entity.Adjustment;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.AdjustmentRowMapper;

@Repository
public class AdjustmentDAOImpl extends GenericDAO  implements AdjustmentDAO {

	private static final Logger LOGGER =  LogManager.getLogger(AdjustmentDAOImpl.class.getName());
	private static final String  EXCEPTION = "Exception:";
	
	StringBuilder sqlWhere = null;
	StringBuilder sqlWhereAdjustment= null;
	@Override
	public String getAdjustmentId() throws DAOException {
		try {
			String sql = "SELECT rtp_utility_pkg.get_adj_id_fnc FROM DUAL";
			return getJdbcTemplate().queryForObject(sql, String.class);			
		} catch (Exception e) {
			LOGGER.info("Exception whlie calling getAdjustmentId() in AccountLiquidityDAOImpl: "+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public Adjustment getAdjustmentById(String adjustmentId) throws DAOException {
		try {
			LOGGER.info("AdjustmentId {} ", adjustmentId );

			String sql = " SELECT ADJ_ID,BULK_ID,VAL_DT,ADT_VRSN_NO,PROC_STAT,ACCT_NO,ACCT_BR_CD,ACCT_SRC_SYS_CD,THRTL_GRP_ID,"
					+ " PY_AMT,ADJ_IN_OUT_CD,ADJ_RSN_TX,CMNT_TX,CRT_USR_ID,CRT_TS, CRT_TS AS STR_CRT_TS,"
					+ " UPD_USR_ID,UPD_TS, UPD_TS AS STR_UPD_TS, "
					+ " APRV_USR_ID,APRV_TS, APRV_TS AS STR_APRV_TS, APRV_DCSN_CD "
					+ " FROM T_GVP_THRTL_ADJ WHERE ADJ_ID = ?";

			return   getJdbcTemplate().queryForObject(sql, new AdjustmentRowMapper(), adjustmentId);
		} catch (EmptyResultDataAccessException e) {
			LOGGER.info("No Adjustment found with Adjustmant Id : " + adjustmentId);
			return null;
		}  catch (Exception e) {
			LOGGER.error("Exception whlie calling getAdjustmentById() for adjustmentId="+adjustmentId+"in AdjustmentDAOImpl:"+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}


	@Override
	public int insertAdjustment(Adjustment adjustment) throws DAOException {
		try {
			LOGGER.info("insertAdjustment() called in AdjustmentDAOImpl");

			String sql = "Insert into T_GVP_THRTL_ADJ "
					+ "(ADJ_ID,BULK_ID,VAL_DT,ADT_VRSN_NO,PROC_STAT,ACCT_NO,ACCT_BR_CD,ACCT_SRC_SYS_CD,"
					+ "THRTL_GRP_ID,PY_AMT,ADJ_IN_OUT_CD,ADJ_RSN_TX,CMNT_TX,CRT_USR_ID,CRT_TS,UPD_USR_ID,"
					+ "UPD_TS,APRV_USR_ID,APRV_TS,APRV_DCSN_CD) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

			return getJdbcTemplate().update(
					sql,
					 adjustment.getAdjId(), null,
							adjustment.getValDt(), adjustment.getAdtVrsnNo(),
							adjustment.getProcStat(), adjustment.getAcctNo(),
							adjustment.getAcctBrCd(),
							adjustment.getAcctSrcSysCd(),
							adjustment.getThrtlGrpId(), adjustment.getPyAmt(),
							adjustment.getAdjInOutCd(),
							adjustment.getAdjRsnTx(), adjustment.getCmntTx(),
							adjustment.getCrtUsrId(), adjustment.getCrtTs(),
							adjustment.getUpdUsrId(), adjustment.getUpdTs(),
							adjustment.getAprvUsrId(), adjustment.getAprvTs(),
							adjustment.getAprvDcsnCd());

		}  catch(Exception e){
			LOGGER.error("Exception whlie calling insertAdjustment() in AdjustmentDAOImpl: "+ e.getMessage(),e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public int updateAdjustment(Adjustment adj) throws DAOException {
		try {
			LOGGER.info("updateAdjustment() called in AdjustmentDAOImpl" );
			String sql = "UPDATE T_GVP_THRTL_ADJ SET ADT_VRSN_NO=?,ACCT_NO=?, PY_AMT=?,ADJ_IN_OUT_CD=?,VAL_DT=?,"
					+ "PROC_STAT=?,UPD_USR_ID=?,UPD_TS=?,ADJ_RSN_TX=?, CMNT_TX=?, APRV_USR_ID=?,APRV_TS=?,APRV_DCSN_CD=? WHERE ADJ_ID = ?" ;

			return getJdbcTemplate().update(sql, 
					adj.getAdtVrsnNo(),adj.getAcctNo(),adj.getPyAmt(),adj.getAdjInOutCd(),adj.getValDt(),
					adj.getProcStat(),adj.getUpdUsrId(),adj.getUpdTs(),adj.getAdjRsnTx(),
					adj.getCmntTx(),adj.getAprvUsrId(), adj.getAprvTs(), adj.getAprvDcsnCd(),adj.getAdjId()							
			);
		} 
		catch(Exception e){
			LOGGER.error("Exception whlie calling updateAdjustment() in AdjustmentDAOImpl: " + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}

	@Override
	public Timestamp getSystemTimestamp() throws DAOException{
		try {
			String sql = "SELECT SYSTIMESTAMP FROM DUAL";
			return getJdbcTemplate().queryForObject(sql, Timestamp.class);
		}  catch (Exception e) {
			LOGGER.error("Exception whlie calling getSystemTimestamp() in AdjustmentDAOImpl: "+ e.getMessage(),e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
}
