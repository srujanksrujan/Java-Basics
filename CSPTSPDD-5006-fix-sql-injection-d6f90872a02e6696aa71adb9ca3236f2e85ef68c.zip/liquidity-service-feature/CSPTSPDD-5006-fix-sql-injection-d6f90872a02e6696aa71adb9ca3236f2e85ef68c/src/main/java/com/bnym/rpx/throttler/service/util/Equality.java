package com.bnym.rpx.throttler.service.util;

public enum Equality {        
    LESSER,
    EQUAL,
    GREATER,         
    MISMATCH;        
}