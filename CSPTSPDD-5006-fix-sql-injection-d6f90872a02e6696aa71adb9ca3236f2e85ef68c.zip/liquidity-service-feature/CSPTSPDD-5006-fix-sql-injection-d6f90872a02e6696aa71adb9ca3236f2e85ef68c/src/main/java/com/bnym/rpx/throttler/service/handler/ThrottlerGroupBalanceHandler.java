package com.bnym.rpx.throttler.service.handler;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bnym.rpx.throttler.service.builder.ThrottlerGroupBalanceBuilder;
import com.bnym.rpx.throttler.service.common.AccountBalanceDataPoint;
import com.bnym.rpx.throttler.service.dao.AccountLiquidityDAO;
import com.bnym.rpx.throttler.service.exception.ApplicationException;
import com.bnym.rpx.throttler.service.model.APIResponse;
import com.bnym.rpx.throttler.service.model.Result;
import com.bnym.rpx.throttler.service.model.ThrottlerGroupAccountGraphDataPointResponse;
import com.bnym.rpx.throttler.service.model.ThrottlerGroupBalanceResponse;

@Service
public class ThrottlerGroupBalanceHandler {

	private static final Logger LOGGER = Logger.getLogger(ThrottlerGroupBalanceHandler.class);
	
	private SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy HH:mm");

	@Autowired
	AccountLiquidityDAO accountLiquidityReader;
	
	@Autowired
	private ThrottlerGroupBalanceBuilder throttlerGroupBalanceBuilder;

	public APIResponse getAnalyticsAccountLiquidity(String valueDate) throws ApplicationException {
		ThrottlerGroupBalanceResponse response = null;
		APIResponse apiResponse = new APIResponse();
		List<ThrottlerGroupBalanceResponse> throttlerGroupBalanceResponseList = new ArrayList<>();
		try {
			response = throttlerGroupBalanceBuilder.getAnalyticsAccountLiquidity(valueDate);
			throttlerGroupBalanceResponseList.add(response);
			apiResponse.setResult(new Result<ThrottlerGroupBalanceResponse>(throttlerGroupBalanceResponseList));
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return apiResponse;
	}

	public APIResponse getAnalyticsAccountLiquidityPosition(String accountNumber, String accountBranchCode,
			String accountSourceSystemCode, String valueDate) throws ApplicationException {
		APIResponse apiResponse = new APIResponse();

		List<ThrottlerGroupAccountGraphDataPointResponse> throttlerGroupBalance = new ArrayList<>();
		try {
			AccountBalanceDataPoint lastValue = accountLiquidityReader.getLastLiquidity(accountNumber,
					accountBranchCode, accountSourceSystemCode, valueDate);
			String lastBalance = (String) ((lastValue != null) ? lastValue.getBalance() : 0);
			LOGGER.info("Last Balance:"+ lastValue);
			List<AccountBalanceDataPoint> balanceList = accountLiquidityReader.getLiquidityHistory(accountNumber,
					accountBranchCode, accountSourceSystemCode, valueDate);
			LOGGER.info("Account Balance List:"+ balanceList);
			Map<String, String> map = new HashMap<>();
			for (AccountBalanceDataPoint data : balanceList) {
				map.put(data.getTime(), data.getBalance());
			}
			LOGGER.info("Account Balance Map:"+ map);
			balanceList = buildTimerange(lastBalance, map);
			throttlerGroupBalance.add(new ThrottlerGroupAccountGraphDataPointResponse(
					accountNumber, valueDate, balanceList));
			apiResponse.setResult(new Result<ThrottlerGroupAccountGraphDataPointResponse>(throttlerGroupBalance));
		} catch (Exception e) {
			throw new ApplicationException(e);
		}
		return apiResponse;
	}

	private List<AccountBalanceDataPoint> buildTimerange(String lastBalance, Map<String, String> accountBalance)
			throws ParseException {
		if (accountBalance.isEmpty()) {
			return Collections.emptyList();
		}
		List<AccountBalanceDataPoint> balanceList = new ArrayList<AccountBalanceDataPoint>();

		Date startTime = new DateTime().withTimeAtStartOfDay().toDate();
		Date endTime = new Date();
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(startTime);
		while (calendar.getTime().before(endTime)) {
			calendar.add(Calendar.MINUTE, 1);
			Date dt = calendar.getTime();
			String time = new SimpleDateFormat("hh:mm").format(dt);
			
			lastBalance = (accountBalance.get(time) != null) ? accountBalance.get(time) : lastBalance;
			balanceList.add(new AccountBalanceDataPoint(lastBalance, sdf.format(dt)));
		}
		LOGGER.info("Balance List [Range of Time]:"+ balanceList);
		return balanceList;
	}
}
