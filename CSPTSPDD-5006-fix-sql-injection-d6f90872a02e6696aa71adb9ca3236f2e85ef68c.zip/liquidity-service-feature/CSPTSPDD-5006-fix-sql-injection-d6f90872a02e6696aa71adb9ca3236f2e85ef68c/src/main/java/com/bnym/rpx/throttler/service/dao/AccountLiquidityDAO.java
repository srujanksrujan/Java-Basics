/**
 * File: AccountLiquidityDAO.java
 * Project - Liquidity Management (LQM)
 * 
 * Copyright (c) 2007-2013 THE BANK OF NEW YORK MELLON CORPORATION. ALL RIGHTS RESERVED.
 * 
 * This software is the confidential and proprietary information of BNY Melon
 * Corporation ("Confidential Information").
 * Since: Dec 20, 2016
 * Version: 1.0
 * 
 */
package com.bnym.rpx.throttler.service.dao;

import java.util.List;

import com.bnym.rpx.throttler.service.common.AccountBalanceDataPoint;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.AccountLiquidity;

/**
 * @author adcb3hn
 *
 */
public interface AccountLiquidityDAO {

	Integer findAccountByAccNo( String accountNo) throws  DAOException;	
	List<AccountLiquidity> getAllAccounts() throws DAOException ;
	List<AccountBalanceDataPoint> getLiquidityHistory(String accountNumber, String accountBranchCode,
			String accountSourceSystemCode, String valueDate) throws DAOException;
	AccountBalanceDataPoint getLastLiquidity(String accountNumber, String accountBranchCode,
			String accountSourceSystemCode, String valDate) throws DAOException;


}
