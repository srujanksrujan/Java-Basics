package com.bnym.rpx.throttler.service.dao.impl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.bnym.rpx.throttler.service.dao.ThrottlerGroupBalanceDAO;
import com.bnym.rpx.throttler.service.exception.DAOException;
import com.bnym.rpx.throttler.service.model.ThrottlerGroupModel;

@Repository
public class ThrottlerGroupAccountBalanceDAOImpl extends GenericDAO implements ThrottlerGroupBalanceDAO {

	private static final Logger LOGGER = Logger.getLogger(ThrottlerGroupAccountBalanceDAOImpl.class);
	private static final String  EXCEPTION  =  "Exception:";
	
	@Override
	public List<Map<String, Object>> getAnalyticsAccountLiquidity(String valueDate) throws DAOException {
		try {
			LOGGER.info("getThrottlerGroupAccountBalanceDetails() called in ThrottlerGroupAccountBalanceDAOImpl ");
			String sql = " SELECT   payment_tab.thrtl_grp_id                   AS thrtl_grp_id  "  +
			"         ,payment_tab.thrtl_grp_nm                   AS thrtl_grp_name  "  +
			"         ,payment_tab.acct_no                        AS acct_no  "  +
			"         ,payment_tab.cash_credit                    AS cash_credit  "  +
			"         ,payment_tab.misc_adj_in                    AS misc_adj_in  "  +
			"         ,payment_tab.total_credit_adj_in            AS total_credit_adj_in  "  +
			"         ,payment_tab.cash_payment                   AS cash_payment  "  +
			"         ,payment_tab.misc_adj_out                   AS misc_adj_out  "  +
			"         ,payment_tab.total_payment_adj_out          AS total_payment_adj_out  "  +
			"         ,NVL(payment_adt_tab.available_amount,0)    AS available_amount  "  +
			"         ,payment_tab.currency_code                  AS currency_code  "  +
			"         ,payment_adt_tab.update_timestamp           AS update_timestamp  "  +
			"         ,payment_tab.pending_pymnt_count            AS pending_pymnt_count  "  +
			"         ,payment_tab.pending_crdt_count             AS pending_crdt_count  "  +
			"         ,NVL(payment_tab.is_fund_agent,'X')         AS is_fund_agent  "  +
			" FROM    (  "  +
			"             WITH  "  +
			"             thrtl_grp_acct_dtl AS  "  +
			"             (  "  +
			"                 SELECT   tg.thrtl_grp_id    AS thrtl_grp_id  "  +
			"                         ,tg.thrtl_grp_nm    AS thrtl_grp_nm  "  +
			"                         ,tga.acct_no        AS acct_no  "  +
			"                         ,tg.ccy_cd          AS currency_code  "  +
			"                         ,tga.is_fund_agent  AS is_fund_agent  "  +
			"                 FROM     t_gvp_thrtl_grp        tg  "  +
			"                         ,t_gvp_thrtl_grp_acct   tga  "  +
			"                 WHERE   tg.thrtl_grp_id         =   tga.thrtl_grp_id  "  +
			"             )  "  +
			"             SELECT  cash_credit_tab.thrtl_grp_id            AS thrtl_grp_id,  "  +
			"                     cash_credit_tab.thrtl_grp_nm            AS thrtl_grp_nm,  "  +
			"                     cash_credit_tab.acct_no                 AS acct_no,  "  +
			"                     cash_credit_tab.currency_code           AS currency_code,  "  +
			"                     cash_credit_tab.cash_credit             AS cash_credit,  "  +
			"                     misc_adj_in_tab.misc_adj_in             AS misc_adj_in,  "  +
			"                     (       cash_credit_tab.cash_credit  "  +
			"                         +   misc_adj_in_tab.misc_adj_in  "  +
			"                     )                                       AS total_credit_adj_in,  "  +
			"                     cash_payment_tab.cash_payment           AS cash_payment,  "  +
			"                     misc_adj_out_tab.misc_adj_out           AS misc_adj_out,  "  +
			"                     (       cash_payment_tab.cash_payment  "  +
			"                         +   misc_adj_out_tab.misc_adj_out  "  +
			"                     )                                       AS total_payment_adj_out,  "  +
			"                     pymt_count_tab.pending_pymnt_count      AS pending_pymnt_count,  "  +
			"                     crdt_count_tab.pending_crdt_count       AS pending_crdt_count,  "  +
			"                     cash_credit_tab.is_fund_agent           AS is_fund_agent  "  +
			"             FROM    (  "  +
			"                         SELECT  tgad.thrtl_grp_id       AS thrtl_grp_id,  "  +
			"                                 tgad.thrtl_grp_nm       AS thrtl_grp_nm,  "  +
			"                                 tgad.acct_no            AS acct_no,  "  +
			"                                 tgad.currency_code      AS currency_code,  "  +
			"                                 tgad.is_fund_agent      AS is_fund_agent,  "  +
			"                                 NVL(cct.cash_credit,0)  AS cash_credit  "  +
			"                         FROM    thrtl_grp_acct_dtl      tgad  "  +
			"                                 LEFT OUTER JOIN  "  +
			"                                 (  "  +
			"                                     SELECT      acct_no             AS acct_no,  "  +
			"                                                 SUM(cr_amt)         AS cash_credit  "  +
			"                                     FROM        t_gvp_thrtl_cr_rqst  "  +
			"                                     WHERE       proc_stat       =   'RELD'  "  +
			"                                     AND         req_typ_cd      =   '02'  "  +
			"                                     AND         TRUNC(crt_ts)   =   TRUNC(TO_DATE(:valueDate,'dd-MON-RR'))  "  +
			"                                     GROUP BY    acct_no  "  +
			"                                 )                       cct  "  +
			"                                 ON  (   tgad.acct_no    =   cct.acct_no )  "  +
			"                     )   cash_credit_tab  "  +
			"                     INNER JOIN  "  +
			"                     (  "  +
			"                         SELECT  tgad.thrtl_grp_id       AS thrtl_grp_id,  "  +
			"                                 tgad.thrtl_grp_nm       AS thrtl_grp_nm,  "  +
			"                                 tgad.acct_no            AS acct_no,  "  +
			"                                 tgad.currency_code      AS currency_code,  "  +
			"                                 tgad.is_fund_agent      AS is_fund_agent,  "  +
			"                                 NVL(mai.misc_adj_in,0)  AS misc_adj_in  "  +
			"                         FROM    thrtl_grp_acct_dtl      tgad  "  +
			"                                 LEFT OUTER JOIN  "  +
			"                                 (  "  +
			"                                     SELECT      acct_no             AS acct_no,  "  +
			"                                                 SUM(py_amt)         AS misc_adj_in  "  +
			"                                     FROM        t_gvp_thrtl_adj  "  +
			"                                     WHERE       proc_stat       =   'RELD'  "  +
			"                                     AND         adj_in_out_cd   =   'I'  "  +
			"                                     AND         TRUNC(crt_ts)   =   TRUNC(TO_DATE(:valueDate,'dd-MON-RR'))  "  +
			"                                     GROUP BY    acct_no  "  +
			"                                 )                       mai  "  +
			"                                 ON  (   tgad.acct_no    =   mai.acct_no )  "  +
			"                     )   misc_adj_in_tab  "  +
			"                     ON  (       cash_credit_tab.thrtl_grp_id    =   misc_adj_in_tab.thrtl_grp_id  "  +
			"                             AND cash_credit_tab.acct_no         =   misc_adj_in_tab.acct_no  "  +
			"                         )  "  +
			"                     INNER JOIN  "  +
			"                     (  "  +
			"                         SELECT  tgad.thrtl_grp_id       AS thrtl_grp_id,  "  +
			"                                 tgad.thrtl_grp_nm       AS thrtl_grp_nm,  "  +
			"                                 tgad.acct_no            AS acct_no,  "  +
			"                                 tgad.currency_code      AS currency_code,  "  +
			"                                 tgad.is_fund_agent      AS is_fund_agent,  "  +
			"                                 NVL(cp.cash_payment,0)  AS cash_payment  "  +
			"                         FROM    thrtl_grp_acct_dtl      tgad  "  +
			"                                 LEFT OUTER JOIN  "  +
			"                                 (  "  +
			"                                     SELECT      acct_no             AS acct_no,  "  +
			"                                                 SUM(py_amt)         AS cash_payment  "  +
			"                                     FROM        t_gvp_thrtl_py_rqst  "  +
			"                                     WHERE       proc_stat       =   'RELD'  "  +
			"                                     AND         req_typ_cd      =   '02'  "  +
			"                                     AND         TRUNC(crt_ts)   =   TRUNC(TO_DATE(:valueDate,'dd-MON-RR'))  "  +
			"                                     GROUP BY    acct_no  "  +
			"                                 )                       cp  "  +
			"                                 ON  (   tgad.acct_no    =   cp.acct_no  )  "  +
			"                     )   cash_payment_tab  "  +
			"                     ON  (       cash_payment_tab.thrtl_grp_id   =   misc_adj_in_tab.thrtl_grp_id  "  +
			"                             AND cash_payment_tab.acct_no        =   misc_adj_in_tab.acct_no  "  +
			"                         )  "  +
			"                     INNER JOIN  "  +
			"                     (  "  +
			"                         SELECT  tgad.thrtl_grp_id       AS thrtl_grp_id,  "  +
			"                                 tgad.thrtl_grp_nm       AS thrtl_grp_nm,  "  +
			"                                 tgad.acct_no            AS acct_no,  "  +
			"                                 tgad.currency_code      AS currency_code,  "  +
			"                                 tgad.is_fund_agent      AS is_fund_agent,  "  +
			"                                 NVL(mao.misc_adj_out,0) AS misc_adj_out  "  +
			"                         FROM    thrtl_grp_acct_dtl      tgad  "  +
			"                                 LEFT OUTER JOIN  "  +
			"                                 (  "  +
			"                                     SELECT      acct_no             AS acct_no,  "  +
			"                                                 SUM(py_amt)         AS misc_adj_out  "  +
			"                                     FROM        t_gvp_thrtl_adj  "  +
			"                                     WHERE       proc_stat       =   'RELD'  "  +
			"                                     AND         adj_in_out_cd   =   'O'  "  +
			"                                     AND         TRUNC(crt_ts)   =   TRUNC(TO_DATE(:valueDate,'dd-MON-RR'))  "  +
			"                                     GROUP BY    acct_no  "  +
			"                                 )                       mao  "  +
			"                                 ON  (   tgad.acct_no    =   mao.acct_no )  "  +
			"                     )   misc_adj_out_tab  "  +
			"                     ON  (       cash_payment_tab.thrtl_grp_id   =   misc_adj_out_tab.thrtl_grp_id  "  +
			"                             AND cash_payment_tab.acct_no        =   misc_adj_out_tab.acct_no  "  +
			"                         )  "  +
			"                     INNER JOIN  "  +
			"                     (  "  +
			"                         SELECT  tgad.thrtl_grp_id       AS thrtl_grp_id,  "  +
			"                                 tgad.thrtl_grp_nm       AS thrtl_grp_nm,  "  +
			"                                 tgad.acct_no            AS acct_no,  "  +
			"                                 tgad.currency_code      AS currency_code,  "  +
			"                                 tgad.is_fund_agent      AS is_fund_agent,  "  +
			"                                 NVL(ppc.pymnt_count,0)  AS pending_pymnt_count  "  +
			"                         FROM    thrtl_grp_acct_dtl      tgad  "  +
			"                                 LEFT OUTER JOIN  "  +
			"                                 (  "  +
			"                                     SELECT      acct_no             AS acct_no,  "  +
			"                                                 COUNT(proc_stat)    AS pymnt_count  "  +
			"                                     FROM        t_gvp_thrtl_py_rqst  "  +
			"                                     WHERE       proc_stat       IN  ('NOTIFY','WAIT')  "  +
			"                                     AND         TRUNC(crt_ts)   =   TRUNC(TO_DATE(:valueDate,'dd-MON-RR'))  "  +
			"                                     GROUP BY    acct_no  "  +
			"                                 )                       ppc  "  +
			"                                 ON  (   tgad.acct_no    =   ppc.acct_no )  "  +
			"                     )   pymt_count_tab  "  +
			"                     ON  (       cash_payment_tab.thrtl_grp_id   =   pymt_count_tab.thrtl_grp_id  "  +
			"                             AND cash_payment_tab.acct_no        =   pymt_count_tab.acct_no  "  +
			"                         )  "  +
			"                     INNER JOIN  "  +
			"                     (  "  +
			"                         SELECT  tgad.thrtl_grp_id       AS thrtl_grp_id,  "  +
			"                                 tgad.thrtl_grp_nm       AS thrtl_grp_nm,  "  +
			"                                 tgad.acct_no            AS acct_no,  "  +
			"                                 tgad.currency_code      AS currency_code,  "  +
			"                                 tgad.is_fund_agent      AS is_fund_agent,  "  +
			"                                 NVL(cpc.crdt_count,0)   AS pending_crdt_count  "  +
			"                         FROM    thrtl_grp_acct_dtl      tgad  "  +
			"                                 LEFT OUTER JOIN  "  +
			"                                 (  "  +
			"                                     SELECT      acct_no             AS acct_no,  "  +
			"                                                 COUNT(proc_stat)    AS crdt_count  "  +
			"                                     FROM        t_gvp_thrtl_cr_rqst  "  +
			"                                     WHERE       proc_stat       IN  ('NOTIFY')  "  +
			"                                     AND         TRUNC(crt_ts)   =   TRUNC(TO_DATE(:valueDate,'dd-MON-RR'))  "  +
			"                                     GROUP BY    acct_no  "  +
			"                                 )                       cpc  "  +
			"                                 ON  (   tgad.acct_no    =   cpc.acct_no )  "  +
			"                     )   crdt_count_tab  "  +
			"                     ON  (       cash_payment_tab.thrtl_grp_id   =   crdt_count_tab.thrtl_grp_id  "  +
			"                             AND cash_payment_tab.acct_no        =   crdt_count_tab.acct_no  "  +
			"                         )  "  +
			"         )   payment_tab  "  +
			"         LEFT OUTER JOIN  "  +
			"         (  "  +
			"             SELECT  acct_no AS acct_no,  "  +
			"                     avl_am  AS available_amount,  "  +
			"                     crt_ts  AS update_timestamp  "  +
			"             FROM    (   SELECT  tala.acct_no        AS acct_no,  "  +
			"                                 tala.avl_am         AS avl_am,  "  +
			"                                 tala.crt_ts         AS crt_ts,  "  +
			"                                 ROW_NUMBER() OVER (  "  +
			"                                     PARTITION BY acct_no  "  +
			"                                     ORDER     BY tala.crt_ts DESC  "  +
			"                                 )                   AS rn  "  +
			"                         FROM    t_gvp_thrtl_acct_lqdy_adt   tala  "  +
			"                         WHERE   tala.crt_ts                 <=  TO_TIMESTAMP(:valueDate||' 23:59:59.999999999','dd-MON-RRRR hh24:MI:ss.ff')  "  +
			"                     )  "  +
			"             WHERE   rn  =   1  "  +
			"         )   payment_adt_tab  "  +
			"             ON  (   payment_tab.acct_no =   payment_adt_tab.acct_no )";

			if (LOGGER.isDebugEnabled()) {
				LOGGER.debug("getThrottlerGroupAccountBalanceDetails Tree Grid Query : " + sql);
			}
			SqlParameterSource namedParameters = new MapSqlParameterSource("valueDate", valueDate);
			return getNamedParameterJdbcTemplate().queryForList(sql,  namedParameters);
		} catch (Exception e) {
			LOGGER.error("Exception whlie calling getThrottlerGroupAccountBalanceDetails() in ThrottlerGroupAccountBalanceDAOImpl:" + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
	
	
	@Override
	public String getCurrentDBTimestamp() throws DAOException {
		try {
			String sql = "SELECT TO_CHAR(SYSTIMESTAMP, 'DD-MON-RR HH12:MM:SS.FF AM') FROM DUAL";
			return getJdbcTemplate().queryForObject(sql, String.class);
		} catch (Exception e) {
			LOGGER.error("Exception while getting current timestamp:" + e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
	}
	
	@Override
	public ThrottlerGroupModel getThrottlerGroup(String accountNumber, String accountBranchCode,
			String accountSourceSystemCode) throws DAOException {
		ThrottlerGroupModel throttlerGroupModelObj = new ThrottlerGroupModel();
		try {
			String throttlerGroupIdSql = "select THRTL_GRP_ID  from T_GVP_THRTL_ACCT_LQDY where ACCT_NO=:accountNumber and ACCT_BR_CD=:accountBranchCode and ACCT_SRC_SYS_CD=:accountSourceSystemCode ";
			SqlParameterSource namedParameters = new MapSqlParameterSource("accountNumber", accountNumber).addValue("accountBranchCode", accountBranchCode)
					.addValue("accountSourceSystemCode", accountSourceSystemCode);
			
			String groupId = getNamedParameterJdbcTemplate().queryForObject(throttlerGroupIdSql, namedParameters, String.class);
			throttlerGroupModelObj.setThrottlerGroupId(groupId != null ? groupId : "");
			
			String throttlerGroupNameSql = "select THRTL_GRP_NM frm T_GVP_THRTL_GRP where THRTL_GRP_ID =:throttlerGroupId";
			namedParameters = new MapSqlParameterSource("throttlerGroupId", throttlerGroupModelObj.getThrottlerGroupId());
			String groupName = getNamedParameterJdbcTemplate().queryForObject(throttlerGroupNameSql, namedParameters, String.class);
			throttlerGroupModelObj.setThrottlerGroupName(groupName != null ? groupName : "");
		} catch (Exception e) {
			LOGGER.error("Exception in ThrottlerGroupAccountBalanceDAOImpl:"
					+ e.getMessage(), e);
			throw new DAOException(EXCEPTION + e.getMessage(), e);
		}
		return throttlerGroupModelObj;
	}
}
