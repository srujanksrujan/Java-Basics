package com.inventory;

public class Car extends Vehicle {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String carMake;
	
	public Car(JsonRequest req) {
		this.setChasisNo(req.getChasisNo());
		this.setName(req.getName());
		this.setVehicleType(req.getVehicleType());
		this.carMake = req.getCarMake();
	}
	

}
