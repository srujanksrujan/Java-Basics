package com.inventory;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("restriction")
@XmlRootElement
public class JsonRequest implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private String chasisNo;
	private String vehicleType;
	private String carMake;
	private String truckSize;
	private String pilotId;
	private String droneId;
	private String amphibianId;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getChasisNo() {
		return chasisNo;
	}
	public void setChasisNo(String chasisNo) {
		this.chasisNo = chasisNo;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	public String getCarMake() {
		return carMake;
	}
	public void setCarMake(String carMake) {
		this.carMake = carMake;
	}
	public String getTruckSize() {
		return truckSize;
	}
	public void setTruckSize(String truckSize) {
		this.truckSize = truckSize;
	}
	public String getPilotId() {
		return pilotId;
	}
	public void setPilotId(String pilotId) {
		this.pilotId = pilotId;
	}
	public String getDroneId() {
		return droneId;
	}
	public void setDroneId(String droneId) {
		this.droneId = droneId;
	}
	public String getAmphibianId() {
		return amphibianId;
	}
	public void setAmphibianId(String amphibianId) {
		this.amphibianId = amphibianId;
	}
	public String getBoatId() {
		return boatId;
	}
	public void setBoatId(String boatId) {
		this.boatId = boatId;
	}
	private String boatId;
}
