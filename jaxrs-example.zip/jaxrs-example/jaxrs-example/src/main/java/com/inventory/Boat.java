package com.inventory;

public class Boat extends Vehicle {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String boatId;
	
	public Boat(JsonRequest req) {
		this.setChasisNo(req.getChasisNo());
		this.setName(req.getName());
		this.setVehicleType(req.getVehicleType());
		this.boatId = req.getBoatId();
	}
}
