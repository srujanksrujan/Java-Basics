package com.inventory;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.webapp.WebAppContext;
import org.apache.commons.lang3.StringUtils;

public class Main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		WebAppContext root = new WebAppContext();
        root.setContextPath("/");
        root.setResourceBase("src/main/webapp/");        
        root.setDescriptor(root.getResourceBase() + "/WEB-INF/web.xml");
        root.setParentLoaderPriority(true);

        Server server = new Server(Integer.valueOf(StringUtils.defaultIfEmpty(System.getenv("PORT"), "8080")));
        server.setSendServerVersion(false);
        server.setSendDateHeader(false);
        server.setHandler(root);
        server.start();
        server.join();
	}

}
