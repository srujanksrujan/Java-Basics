package com.inventory;

public class Truck extends Vehicle {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String truckSize;
	
	public Truck(JsonRequest req) {
		this.setChasisNo(req.getChasisNo());
		this.setName(req.getName());
		this.setVehicleType(req.getVehicleType());
		this.truckSize = req.getTruckSize();
	}
}
