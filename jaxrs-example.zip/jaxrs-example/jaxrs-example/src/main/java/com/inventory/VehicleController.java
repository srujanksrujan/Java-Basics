package com.inventory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path(value = "vehicle")
public class VehicleController {
	
static final String CREATE_SQL = "CREATE TABLE vehicle(id bigint auto_increment, chasis_no varchar(255),object_value other)";
	
	static final String WRITE_OBJECT_SQL = "INSERT INTO vehicle(chasis_no,object_value) VALUES (?,?)";
	
	static final String READ_OBJECT_SQL = "SELECT object_value FROM vehicle WHERE chasis_no = ?";
	
	static final String DELETE_OBJECT_SQL = "DELETE FROM vehicle WHERE Id in(SELECT MAX(Id) FROM vehicle)";
	
	public VehicleController() {
		Connection conn = null;
		try {
			conn = getConnection();
			PreparedStatement pstmt = conn.prepareStatement(CREATE_SQL);
			pstmt.executeUpdate();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static Connection getConnection() throws Exception {
	   String driver = "org.h2.Driver";
	   String url = "jdbc:h2:~/test";
	   String username = "root";
	   String password = "root";
	   Class.forName(driver);
	   Connection conn = DriverManager.getConnection(url, username, password);
	   return conn;
	}
	
	@GET
	@Path("{chasisNo}")
	@Produces(MediaType.APPLICATION_JSON)
	public JsonRequest getVehicleDetails(@PathParam("chasisNo") String chasisNo) throws SQLException {
		Connection conn = null;
		try {
			conn = getConnection();
			PreparedStatement pstmt = conn.prepareStatement(READ_OBJECT_SQL);
			pstmt.setString(1,chasisNo);
			ResultSet rs = pstmt.executeQuery();
		    rs.next();
		    JsonRequest res = (JsonRequest) rs.getObject(1);
		    return res;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			conn.close();
		}
		return null;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void putVehicleDetails(JsonRequest req) throws SQLException {
		Connection conn = null;
		Vehicle vehicle = null;
		if(req.getVehicleType().equals("car")) {
			vehicle = new Car(req);
		}else if(req.getVehicleType().equals("truck")) {
			vehicle = new Truck(req);
		}else if(req.getVehicleType().equals("airplane")) {
			vehicle = new Airplane(req);
		}else if(req.getVehicleType().equals("boat")) {
			vehicle = new Boat(req);
		}
		try {
			conn = getConnection();
			PreparedStatement pstmt = conn.prepareStatement(WRITE_OBJECT_SQL);
			pstmt.setString(1,req.getVehicleType());
			pstmt.setObject(2, vehicle);
			pstmt.executeUpdate();
		    pstmt.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			conn.close();
		}
	}
	
	@GET
	@Path("pop")
	public void deleteVehicle() throws SQLException {
		Connection conn = null;
		try {
			conn = getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DELETE_OBJECT_SQL);
			pstmt.executeUpdate();
		    pstmt.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			conn.close();
		}
	}

}
