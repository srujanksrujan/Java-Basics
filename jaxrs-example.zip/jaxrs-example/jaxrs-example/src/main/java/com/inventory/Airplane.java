package com.inventory;

public class Airplane extends Vehicle {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String pilotId;
	
	public Airplane(JsonRequest req) {
		this.setChasisNo(req.getChasisNo());
		this.setName(req.getName());
		this.setVehicleType(req.getVehicleType());
		this.pilotId = req.getPilotId();
	}
}
