package com.bnym.rpx.fraud.service.dao.repository;

import org.springframework.stereotype.Repository;

@Repository
public interface BlacklistedRepository {

}
