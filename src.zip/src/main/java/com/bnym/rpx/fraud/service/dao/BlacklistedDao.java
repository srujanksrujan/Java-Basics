package com.bnym.rpx.fraud.service.dao;

public interface BlacklistedDao {

}
