package com.bnym.rpx.fraud.service.controller;

import org.apache.log4j.Logger;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SampleController {
	private static final Logger logger = Logger.getLogger( SampleController.class );
	
	@RequestMapping(value = "/sample")
	public String healthCheck() {
		
		logger.debug("Sample response============");
		return "Sample response";
	}

}
