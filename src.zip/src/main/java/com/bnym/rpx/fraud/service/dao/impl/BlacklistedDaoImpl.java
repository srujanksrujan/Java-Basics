package com.bnym.rpx.fraud.service.dao.impl;

import org.springframework.stereotype.Repository;

import com.bnym.rpx.fraud.service.dao.BlacklistedDao;

@Repository
public class BlacklistedDaoImpl implements BlacklistedDao {

}
